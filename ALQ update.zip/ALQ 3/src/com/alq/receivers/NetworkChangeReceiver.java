package com.alq.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.alq.sync.SyncService;
import com.alq.utils.LogUtility;
import com.alq.utils.Utility;

public class NetworkChangeReceiver extends BroadcastReceiver {
	
	public static final String TAG = NetworkChangeReceiver.class.getSimpleName();

	@Override
	public void onReceive(Context context, Intent intent) {
		LogUtility.printInfoMessage(TAG + ": NetworkChangeReceiver :: onReceive :: START" );
		
		if (Utility.isNetworkAvailable(context)) {
			context.startService(new Intent(context, SyncService.class));
		}
	}
}