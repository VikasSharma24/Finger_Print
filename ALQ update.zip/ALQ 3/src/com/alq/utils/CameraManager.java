package com.alq.utils;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.Fragment;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.widget.ArrayAdapter;

import com.alq.App;
import com.alq.fragment.BaseFragment;

public class CameraManager {
	private static final String CLASS_TAG = CameraManager.class.getSimpleName();

	public static final int REQUEST_IMAGE_CAPTURE = 100;
	public static final int REQUEST_GALLERY_CONTENT = 103;
	public static final int REQUEST_VIDEO_CAPTURE = 105;
	public static final int SELECT_PICTURE_REQUEST_CODE = 104;

	public static final int MEDIA_TYPE_IMAGE = 1;

	public static final int IMAGE_WIDTH  = 220;
	public static final int IMAGE_HEIGHT  = 240;

	BaseFragment fragment;
	Activity activity;
	private Uri outputUri;
	private String fileName;

	static OpenCameraListener cameraListener;

	public interface OpenCameraListener {
		void openCamera (int requestCode);
	}

	public Uri getOutputUri() {
		return outputUri;
	}
	
	public void setOutputUri(Uri outputUri) {
		this.outputUri = outputUri;
	}

	private static CameraManager uploadFileChooser;

	public CameraManager(Activity activity) {
		this.activity = activity;
	}

	public CameraManager(BaseFragment fragment) {
		this.fragment = fragment;
	}

	private void setContext(BaseFragment context) {
		this.fragment = context;
	}

	@SuppressWarnings("unused")
	private void setContext(Activity context) {
		this.activity = context;
	}

	/**
	 * Get the instance of this class.
	 * @param context
	 * @return
	 */
	public static CameraManager getInstance(BaseFragment context) {
		synchronized (CameraManager.class) {
			if(uploadFileChooser == null) {
				uploadFileChooser = new CameraManager(context);
			} else {
				uploadFileChooser.setContext(context);
			}
		}
		return uploadFileChooser;
	}

	/**
	 * Get the instance of this class.
	 * @param context
	 * @return
	 */
	/*public static CameraManager getInstance(Activity context) {
		synchronized (CameraManager.class) {
			if(uploadFileChooser == null) {
				uploadFileChooser = new CameraManager(context);
			} else {
				uploadFileChooser.setContext(context);
			}
		}
		return uploadFileChooser;
	}*/

	public void launchCameraFromFragment(int type, int requestCode) {
		// create Intent to take a picture and return control to the calling application
		Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

		// create a file to save the image
		outputUri = getOutputMediaFileUri(type); 

		// set the image file name
		takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, outputUri); 

		if (takePictureIntent.resolveActivity(fragment.getActivity().getPackageManager()) != null) {
			// start the image capture Intent
			fragment.startActivityForResult(takePictureIntent, requestCode);
		}
	}

	public void launchVideoFromFragment(int type, int requestCode) {
		// create Intent to take a picture and return control to the calling application
		Intent takePictureIntent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);

		// create a file to save the image
		outputUri = getOutputMediaFileUri(type); 

		// set the image file name
		takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, outputUri); 

		if (takePictureIntent.resolveActivity(fragment.getActivity().getPackageManager()) != null) {
			// start the image capture Intent
			fragment.startActivityForResult(takePictureIntent, requestCode);
		}
	}

	public void launchCameraFromActivity(int type, int requestCode) {
		// create Intent to take a picture and return control to the calling application
		Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

		// create a file to save the image
		outputUri = getOutputMediaFileUri(type); 

		// set the image file name
		takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, outputUri); 
		takePictureIntent.putExtra("return-data", true);

		if (takePictureIntent.resolveActivity(activity.getPackageManager()) != null) {
			// start the image capture Intent
			activity.startActivityForResult(takePictureIntent, requestCode);
		}
	}


	/** Create a file Uri for saving an image*/
	private Uri getOutputMediaFileUri(int type) {
		return Uri.fromFile(getOutputMediaFile(type));
	}

	/** Create a File for saving an image*/
	public File getOutputMediaFile(int type) {
		// To be safe, you should check that the SDCard is mounted
		// using Environment.getExternalStorageState() before doing this.
		/*String path = Utility.getRootFileDir() + File.separator + AppConstant.APP_TAG;
		File mediaStorageDir = new File(path, AppConstant.FOLDER_NAME_MEDIA);*/
		File mediaStorageDir = Utility.getMediaDirPath();

		// This location works best if you want the created images to be shared
		// between applications and persist after your app has been uninstalled.

		// Create the storage directory if it does not exist
		if (!Utility.makeDirectory(mediaStorageDir)) {
			return null;
		}

		// Create a media file name
		//String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());

		File mediaFile = null;
		if (type == MEDIA_TYPE_IMAGE) {
			/*File imageFile = new File(mediaStorageDir, "alq");

			// Create the storage directory if it does not exist
			if (!Utility.makeDirectory(imageFile)) {
				return null;
			}
*/
			mediaFile = new File(mediaStorageDir.getPath() + File.separator +
					fileName + ".jpg");
		} 
		return mediaFile;
	}

	/** Create a File for saving an image*/
	public static File getOutputMediaFile(int type, String extension) {
		// To be safe, you should check that the SDCard is mounted
		// using Environment.getExternalStorageState() before doing this.
		/*String path = Utility.getRootFileDir() + File.separator + AppConstant.APP_TAG;
		File mediaStorageDir = new File(path, AppConstant.FOLDER_NAME_MEDIA);*/
		File mediaStorageDir = Utility.getMediaDirPath();

		// This location works best if you want the created images to be shared
		// between applications and persist after your app has been uninstalled.

		// Create the storage directory if it does not exist
		if (!Utility.makeDirectory(mediaStorageDir)) {
			return null;
		}

		String suffix = TextUtils.isEmpty(extension)? "unknown" : extension;

		// Create a media file name
		String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());

		File mediaFile = null;
		if (type == MEDIA_TYPE_IMAGE) {
			File imageFile = new File(mediaStorageDir, "alq");

			// Create the storage directory if it does not exist
			if (!Utility.makeDirectory(imageFile)) {
				return null;
			}

			mediaFile = new File(imageFile.getPath() + File.separator +
					"IMG_"+ timeStamp + suffix);
		} 		return mediaFile;
	}


	/**
	 * Get the actual file path from Uri
	 * @param contentUri
	 * @param isImage
	 * @return
	 */
	public String getRealPathFromURI(Uri contentUri, boolean isImage) {
		String[] proj = { isImage ? MediaStore.Images.Media.DATA :  MediaStore.Video.Media.DATA};
		Cursor cursor = null;

		try {
			if (activity != null) {
				cursor = activity.getContentResolver().query(contentUri,  proj, null, null, null);
			} else if (fragment != null && fragment.getActivity() != null) {
				cursor = fragment.getActivity().getContentResolver().query(contentUri, proj, null, null, null);
			}
			int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
			cursor.moveToFirst();
			return cursor.getString(column_index);
		} catch (Exception e) {
			Log.e(CLASS_TAG, "getRealPathFromURI : Exception occured " + e.getMessage());
			e.printStackTrace();
			return contentUri.getPath();
		}
	}

	public File getCampturedImage() {
		return new File(UriUtility.getPath(App.getInstance().getApplicationContext(), outputUri));
	}

	//	public void launchImageGalleryIntent() {
	//
	//		if (Build.VERSION.SDK_INT <19){
	//			final Intent galleryIntent = new Intent(Intent.ACTION_GET_CONTENT);
	//			galleryIntent.setType("image/*");
	//			fragment.startActivityForResult(galleryIntent, REQUEST_GALLERY_CONTENT);
	//		} else {
	//			final Intent galleryIntent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
	//		    intent.addCategory(Intent.CATEGORY_OPENABLE);
	//		    intent.setType("image/jpeg");
	//		    fragment.startActivityForResult(galleryIntent, REQUEST_GALLERY_CONTENT);
	//		}
	//	}

	public void launchImageGalleryIntent() {
		final Intent galleryIntent = new Intent(Intent.ACTION_GET_CONTENT);
		galleryIntent.setType("image/*");
		fragment.startActivityForResult(galleryIntent, REQUEST_GALLERY_CONTENT);
	}

	public void launchGalleryIntent() {
		final Intent galleryIntent = new Intent(Intent.ACTION_GET_CONTENT);
		galleryIntent.setType("image/* video/*");
		fragment.startActivityForResult(galleryIntent, REQUEST_GALLERY_CONTENT);
	}

	/**
	 * A selector dialog to display two image source options, from camera
	 * take from camera and from existing files Select from gallery
	 */
	public void captureImageInitialization(final Activity activity, final Fragment fragment) {
		String[] items = new String[] { "Take from camera",
		"Select from gallery" };

		ArrayAdapter<String> adapter = new ArrayAdapter<String>(activity, 
				android.R.layout.select_dialog_item, items);
		AlertDialog.Builder builder = new AlertDialog.Builder(activity);

		builder.setTitle("Select");
		builder.setAdapter(adapter, new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int item) { // pick from
				switch (item) {
				case 0: //camera
					launchCameraFromFragment(CameraManager.MEDIA_TYPE_IMAGE, CameraManager.REQUEST_IMAGE_CAPTURE);
					break;
				case 1: // gallery
					launchImageGalleryIntent();
				default:
					break;
				}
			}
		});

		Dialog dialog = builder.create();
		dialog.show();
	}

	public void setFileName(String name) {
		this.fileName = name;
	}

	public String getFileName() {
		return fileName;
	}
}
