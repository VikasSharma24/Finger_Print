package com.alq.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

import android.os.Build;
import android.text.TextUtils;

import com.alq.services.FileUploader;

/**
 * This utility class provides an abstraction layer for sending multipart HTTP
 * POST requests to a web server. 
 * @author www.codejava.net
 *
 */
public class MultipartUtility {

	private static final String LINE_FEED = "\r\n";
	private static final String POST_METHOD = "POST";

	private final String boundary;
	private HttpURLConnection httpConn;
	private String charset;
	private OutputStream outputStream;
	private PrintWriter writer;

	/**
	 * This constructor initializes a new HTTP POST request with content type
	 * is set to multipart/form-data
	 * @param requestURL
	 * @param charset
	 * @throws IOException
	 */
	public MultipartUtility(String requestURL, String charset, int requestTimeout)
			throws IOException {
		this.charset = charset;

		// creates a unique boundary based on time stamp
		boundary = "===" + System.currentTimeMillis() + "===";

		URL url = new URL(requestURL);
		httpConn = (HttpURLConnection) url.openConnection();

		httpConn.setConnectTimeout(requestTimeout);
		httpConn.setReadTimeout(requestTimeout);

		httpConn.setChunkedStreamingMode(1024);

		httpConn.setRequestMethod(POST_METHOD);
		httpConn.setDoOutput(true); // indicates POST method
		httpConn.setDoInput(true);

		httpConn.setRequestProperty("Content-Type","multipart/form-data; boundary=" + boundary);

		// This is for avoid EOF exception from getResponseCode
		if (Build.VERSION.SDK_INT > 13) { 
			httpConn.setRequestProperty("Connection", "close"); 
			System.setProperty("http.keepAlive", "false");
		}

		outputStream = httpConn.getOutputStream();
		writer = new PrintWriter(new OutputStreamWriter(outputStream, charset), true);
	}

	/**
	 * Adds a form field to the request
	 * @param name field name
	 * @param value field value
	 */
	public void addFormField(String name, String value) {
		writer.append("--" + boundary).append(LINE_FEED);
		writer.append("Content-Disposition: form-data; name=\"" + name + "\"")
		.append(LINE_FEED);
		writer.append("Content-Type: text/plain; charset=" + charset).append(
				LINE_FEED);
		writer.append(LINE_FEED);
		writer.append(value).append(LINE_FEED);
		writer.flush();
	}

	/**
	 * Adds a upload file section to the request 
	 * @param fieldName name attribute in <input type="file" name="..." />
	 * @param uploadFile a File to be uploaded 
	 * @throws IOException
	 */
	public void addFilePart(String fieldName, File uploadFile, FileUploader fileUploader)
			throws IOException {
		String fileName = uploadFile.getName();
		writer.append("--" + boundary).append(LINE_FEED);
		if(!TextUtils.isEmpty(fieldName)) {
			writer.append("Content-Disposition: form-data; name=\"" + fieldName+ "\"; filename=\"" + fileName + "\"")
			.append(LINE_FEED);
		}
		writer.append("Content-Type: "+ URLConnection.guessContentTypeFromName(fileName)).append(LINE_FEED);
		writer.append("Content-Transfer-Encoding: binary").append(LINE_FEED);
		writer.append(LINE_FEED);
		writer.flush();

		FileInputStream inputStream = new FileInputStream(uploadFile);
		byte[] buffer = new byte[1024];
		int bytesRead = -1;
		int totalByteWrite = 0;
		int prevUpdateStatus = 0;
		
		LogUtility.printInfoMessage("MultipartUtility : addFilePart : Total Bytes-" + uploadFile.length());
	
		while ((bytesRead = inputStream.read(buffer)) != -1) {

			if(!fileUploader.isCancelled()) {

				outputStream.write(buffer, 0, bytesRead);
				totalByteWrite += bytesRead; 

				int currentUpdateStatus = getProgressUpdate(totalByteWrite, uploadFile.length());
				
				if(prevUpdateStatus != currentUpdateStatus) {
					prevUpdateStatus = currentUpdateStatus;
					fileUploader.updateProgressFromUIThread(currentUpdateStatus+"");	
				}
			} else {
				break;
			}
		}

		outputStream.flush();
		inputStream.close();

		writer.append(LINE_FEED);
		writer.flush();     
	}

	/**
	 * Completes the request and receives response from the server.
	 * @return a list of Strings as response in case the server returned
	 * status OK, otherwise an exception is thrown.
	 * @throws IOException
	 */
	public String finish() throws Exception {
		//        List<String> response = new ArrayList<String>();

		writer.append(LINE_FEED).flush();
		writer.append("--" + boundary + "--").append(LINE_FEED);
		writer.close();

		StringBuilder builder = new StringBuilder();

		// checks server's status code first

		int status = httpConn.getResponseCode();
		if (status == HttpURLConnection.HTTP_OK) {

			BufferedReader reader = new BufferedReader(new InputStreamReader(
					httpConn.getInputStream()));
			String line = null;
			while ((line = reader.readLine()) != null) {
				//                response.add(line);
				builder.append(line);
			}
			reader.close();
			httpConn.disconnect();
		} else {
			throw new IOException("Server returned non-OK status: " + status);
		}

		return builder.toString();
		//        return response;
	}

	private int getProgressUpdate(long byteUploaded, long fileLength) {
		// circle.
		int per = Math.round(((float)byteUploaded / fileLength) * 100);
		//		return (int)((byteUploaded/fileLength)*100);
		return per;
	}
}
