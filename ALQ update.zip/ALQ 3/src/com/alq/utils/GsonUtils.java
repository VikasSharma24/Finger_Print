package com.alq.utils;

import java.lang.reflect.Type;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import android.annotation.SuppressLint;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

@SuppressLint("SimpleDateFormat")
public class GsonUtils {
	public static String LONG_DATE_FORMAT = "yyyy-MM-dd";
	private static Gson gson = createGson();

	public static Gson createGson() {
		GsonBuilder builder = new GsonBuilder().serializeNulls();

		builder.registerTypeAdapter(Date.class, new JsonDeserializer<Date>() {

			@Override
			public Date deserialize(JsonElement json, Type typeOfT,
					JsonDeserializationContext context)
					throws JsonParseException {

				SimpleDateFormat format = new SimpleDateFormat(LONG_DATE_FORMAT);
				format.setTimeZone(TimeZone.getTimeZone("GMT"));
				String date = json.getAsJsonPrimitive().getAsString();
				try {
					return format.parse(date);
				} catch (ParseException e) {
					throw new RuntimeException(e);
				}
			}
		});

		builder.registerTypeAdapter(Date.class, new JsonSerializer<Date>() {
			public JsonElement serialize(Date src, Type typeOfSrc,
					JsonSerializationContext context) {
				SimpleDateFormat format = new SimpleDateFormat(LONG_DATE_FORMAT);
				format.setTimeZone(TimeZone.getTimeZone("GMT"));
				return new JsonPrimitive(format.format(src));
			}
		});

		builder.registerTypeAdapter(java.sql.Date.class,
				new JsonDeserializer<java.sql.Date>() {

					@Override
					public java.sql.Date deserialize(JsonElement json,
							Type typeOfT, JsonDeserializationContext context)
							throws JsonParseException {

						SimpleDateFormat format = new SimpleDateFormat(
								LONG_DATE_FORMAT);
						String date = json.getAsJsonPrimitive().getAsString();
						try {
							Date d = format.parse(date);
							return new java.sql.Date(d.getTime());
						} catch (ParseException e) {
							throw new RuntimeException(e);
						}
					}
				});
		builder.registerTypeAdapter(java.sql.Date.class,
				new JsonSerializer<java.sql.Date>() {
					public JsonElement serialize(java.sql.Date src,
							Type typeOfSrc, JsonSerializationContext context) {
						SimpleDateFormat format = new SimpleDateFormat(
								LONG_DATE_FORMAT);
						return new JsonPrimitive(format.format(src));
					}
				});

		builder.registerTypeAdapter(java.sql.Timestamp.class,
				new JsonDeserializer<java.sql.Timestamp>() {

					@Override
					public java.sql.Timestamp deserialize(JsonElement json,
							Type typeOfT, JsonDeserializationContext context)
							throws JsonParseException {

						SimpleDateFormat format = new SimpleDateFormat(
								LONG_DATE_FORMAT);
						String date = json.getAsJsonPrimitive().getAsString();
						try {
							Date d = format.parse(date);
							return new java.sql.Timestamp(d.getTime());
						} catch (ParseException e) {
							throw new RuntimeException(e);
						}
					}
				});
		builder.registerTypeAdapter(java.sql.Timestamp.class,
				new JsonSerializer<java.sql.Timestamp>() {
					public JsonElement serialize(java.sql.Timestamp src,
							Type typeOfSrc, JsonSerializationContext context) {
						SimpleDateFormat format = new SimpleDateFormat(
								LONG_DATE_FORMAT);
						return new JsonPrimitive(format.format(src));
					}
				});

		return builder.create();
	}

	public static String toJson(Object obj, Class calzz) {
		return gson.toJson(obj, calzz);
	}

}
