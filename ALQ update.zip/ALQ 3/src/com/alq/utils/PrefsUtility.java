package com.alq.utils;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock.ReadLock;
import java.util.concurrent.locks.ReentrantReadWriteLock.WriteLock;

import android.content.Context;
import android.content.SharedPreferences;

import com.alq.App;
import com.alq.R;


public class PrefsUtility  {

	// class members
	private SharedPreferences preferences;
	private ReentrantReadWriteLock reentrantReadWriteLock;
	private Context context;

	static PrefsUtility prefsUtility;
	
	/**
	 * Initialize object
	 * @param context
	 */
	private PrefsUtility(Context context) {
		this.context = context;
		reentrantReadWriteLock = new ReentrantReadWriteLock();
		preferences = context.getSharedPreferences(context.getString(R.string.pref_name), Context.MODE_PRIVATE);
	}
	
	
	public static PrefsUtility getInstance() {
		if (prefsUtility == null) {
			prefsUtility  = new PrefsUtility(App.getInstance().getApplicationContext());
		}
		
		return prefsUtility;
	}
	
	
	private String getStringPref(String key) {
		ReadLock readLock = reentrantReadWriteLock.readLock();
		readLock.lock();
		String  str =  preferences.getString(key, "");
		readLock.unlock();
		return str; 
	}
	
	private void setStringPref(String key, String value) {
		WriteLock writeLock = reentrantReadWriteLock.writeLock();
		writeLock.lock();
		preferences.edit().putString(key, value).commit();
		writeLock.unlock();
	}
	
	public void setUsername(String name) {
		setStringPref(context.getString(R.string.pref_user), name);
	}
	
	public String getUsername() {
		return getStringPref(context.getString(R.string.pref_user));
	}
	
	public void setPassword(String pwd) {
		setStringPref(context.getString(R.string.pref_pwd), pwd);
	}
	
	public String getPassword() {
		return getStringPref(context.getString(R.string.pref_pwd));
	}
	
	public void setSyncData(long value) {
		WriteLock writeLock = reentrantReadWriteLock.writeLock();
		writeLock.lock();
		preferences.edit().putLong(context.getString(R.string.pref_sync_date), value).commit();
		writeLock.unlock();
	}
	
	public long getSyncDate() {
		ReadLock readLock = reentrantReadWriteLock.readLock();
		readLock.lock();
		long  syncDate =  preferences.getLong(context.getString(R.string.pref_sync_date), 0);
		readLock.unlock();
		return syncDate;
	}
	
	public void setSyncStockValue(int value) {
		WriteLock writeLock = reentrantReadWriteLock.writeLock();
		writeLock.lock();
		preferences.edit().putInt(context.getString(R.string.pref_sync_stock_value), value).commit();
		writeLock.unlock();
	}
	
	public int getSyncStockValue() {
		ReadLock readLock = reentrantReadWriteLock.readLock();
		readLock.lock();
		int  syncStockValue =  preferences.getInt(context.getString(R.string.pref_sync_stock_value), 0);
		readLock.unlock();
		return syncStockValue;
	}
	
	public void setStockDownloaded(boolean value) {
		WriteLock writeLock = reentrantReadWriteLock.writeLock();
		writeLock.lock();
		preferences.edit().putBoolean(context.getString(R.string.pref_stock_downloaded), value).commit();
		writeLock.unlock();
	}
	
	public boolean isStockDownloaded() {
		ReadLock readLock = reentrantReadWriteLock.readLock();
		readLock.lock();
		boolean  stockDownloaded =  preferences.getBoolean(context.getString(R.string.pref_stock_downloaded), false);
		readLock.unlock();
		return stockDownloaded;
	}
	
	public void setSyncDownloadImagesDate(String value) {
		WriteLock writeLock = reentrantReadWriteLock.writeLock();
		writeLock.lock();
		preferences.edit().putString(context.getString(R.string.pref_sync_download_images_date), value).commit();
		writeLock.unlock();
	}
	
	public String getSyncDownloadImagesDate() {
		ReadLock readLock = reentrantReadWriteLock.readLock();
		readLock.lock();
		String  syncDate =  preferences.getString(context.getString(R.string.pref_sync_download_images_date), Utility.getFormattedDate("MM/dd/yyyy", Utility.getCurTime()));
		readLock.unlock();
		return syncDate;
	}
	
	public void setLastSyncStockDate(long value) {
		WriteLock writeLock = reentrantReadWriteLock.writeLock();
		writeLock.lock();
		preferences.edit().putLong(context.getString(R.string.pref_last_sync_stock_date), value).commit();
		writeLock.unlock();
	}
	
	public long getLastSyncStockDate() {
		ReadLock readLock = reentrantReadWriteLock.readLock();
		readLock.lock();
		long  syncDate =  preferences.getLong(context.getString(R.string.pref_last_sync_stock_date), 0);
		readLock.unlock();
		return syncDate;
	}
	
	public void setLastSyncCustDate(long value) {
		WriteLock writeLock = reentrantReadWriteLock.writeLock();
		writeLock.lock();
		preferences.edit().putLong(context.getString(R.string.pref_last_sync_cust_date), value).commit();
		writeLock.unlock();
	}
	
	public long getLastSyncCustDate() {
		ReadLock readLock = reentrantReadWriteLock.readLock();
		readLock.lock();
		long  syncDate =  preferences.getLong(context.getString(R.string.pref_last_sync_cust_date), 0);
		readLock.unlock();
		return syncDate;
	}
	
	public void setLastDownloadImageDate(long value) {
		WriteLock writeLock = reentrantReadWriteLock.writeLock();
		writeLock.lock();
		preferences.edit().putLong(context.getString(R.string.pref_last_download_image_date), value).commit();
		writeLock.unlock();
	}
	
	public long getLastDownloadImageDate() {
		ReadLock readLock = reentrantReadWriteLock.readLock();
		readLock.lock();
		long  syncDate =  preferences.getLong(context.getString(R.string.pref_last_download_image_date), 0);
		readLock.unlock();
		return syncDate;
	}
}
