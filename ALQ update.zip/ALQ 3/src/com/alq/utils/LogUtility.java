package com.alq.utils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.annotation.SuppressLint;
import android.os.Environment;
import android.text.TextUtils;
import android.util.Log;

import com.alq.constant.Constants;

public class LogUtility {
	public static final String GPS_LOG_DATE_PATTERN = "MM-dd-yyyy hh:mm:ss";
	@SuppressLint("SimpleDateFormat")
	private static final SimpleDateFormat dateFormat = new SimpleDateFormat(LogUtility.GPS_LOG_DATE_PATTERN);
	
	public final static int DEBUG = 1;
	public final static int VERBOSE= 2;
	public final static int ERROR = 3;
	public final static int WARNING = 4;
	public final static int INFO = 5;

	private static Object lockObject  = new Object(); 
	private static boolean isLogEnable = true;

	/**
	 * Print given message as a Log.i 
	 * @param msg
	 */
	public static void printInfoMessage(String msg) {
		synchronized (lockObject) {
			if(!isLogEnable && TextUtils.isEmpty(msg)) return;
			Log.i(Constants.APP_TAG, msg);
			//writeLogInFile(appendTagWithMsg(INFO, msg));	
		}
	}

	/**
	 * Print given message as a Log.w 
	 * @param msg
	 */
	public static void printDebugMessage(String msg) {
		synchronized (lockObject) {
			if(!isLogEnable && TextUtils.isEmpty(msg)) return;
			Log.d(Constants.APP_TAG, msg);
			//writeLogInFile(appendTagWithMsg(DEBUG, msg));
		}
	}

	/**
	 * Print given message as a Log.e 
	 * @param msg
	 */
	public static void printErrorMessage(String msg) {
		synchronized (lockObject) {
			if(!isLogEnable && TextUtils.isEmpty(msg)) return;
			Log.e(Constants.APP_TAG, msg);
			//writeLogInFile(appendTagWithMsg(ERROR, msg));
		}
	}

	/**
	 * Print given message as a Log.e 
	 * @param classTAG
	 * @param e
	 */
	public static void printErrorMessage(final String classTAG ,Throwable e) {
		synchronized (lockObject) {
			if(!isLogEnable || e == null) return;
			Log.e(Constants.APP_TAG, classTAG+":"+Log.getStackTraceString(e));
			//writeLogInFile(appendTagWithMsg(ERROR, Log.getStackTraceString(e)));
		}
	}


	@SuppressWarnings("unused")
	private static void writeLogInFile(StringBuilder logstr) {

		final long MAX_FILE_LIMIT = 20480; //20971520 B//20 MB

		FileWriter fw = null;
		BufferedWriter bw = null;

		try {

			String filePath = Environment.getExternalStorageDirectory()+File.separator+Constants.APP_TAG;

			File dirFile = new File(filePath);
			dirFile.mkdirs();

			File newFile = new File(filePath, Constants.APP_TAG+"_log.txt");
			long  filebytes = newFile.length();
			long kbytes = (filebytes / 1024);

			if (kbytes > MAX_FILE_LIMIT) {
				final File to = new File(newFile.getAbsolutePath() + System.currentTimeMillis());
				newFile.renameTo(to);
				to.delete();
			}

			if (!newFile.exists()) {
				newFile.createNewFile();
			}
			fw = new FileWriter(newFile, true);
			bw = new BufferedWriter(fw);

			//append data into file
			bw.append(logstr.toString());
			bw.newLine();
			bw.flush();

			bw.close();
			fw.close();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	public static void writeGPSLogFile(String logstr) {
		final long MAX_FILE_LIMIT = 20480; //20971520 B//20 MB

		FileWriter fw = null;
		BufferedWriter bw = null;

		try {

			String filePath = Environment.getExternalStorageDirectory()+File.separator+Constants.APP_TAG;

			File dirFile = new File(filePath);
			dirFile.mkdirs();

			File newFile = new File(filePath, Constants.APP_TAG+"gps_log.txt");
			long  filebytes = newFile.length();
			long kbytes = (filebytes / 1024);

			if (kbytes > MAX_FILE_LIMIT) {
				final File to = new File(newFile.getAbsolutePath() + System.currentTimeMillis());
				newFile.renameTo(to);
				to.delete();
			}

			if (!newFile.exists()) {
				newFile.createNewFile();
			}
			fw = new FileWriter(newFile, true);
			bw = new BufferedWriter(fw);

			//append data into file
			bw.append(dateFormat.format(new Date()));
			bw.append(logstr.toString());
			bw.newLine();
			bw.flush();

			bw.close();
			fw.close();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@SuppressWarnings("unused")
	private static StringBuilder appendTagWithMsg(int mode, String msg) {

		StringBuilder strBuilder  = new StringBuilder();
		switch (mode) {
		case DEBUG :
			strBuilder.append("D/");
			break;
		case VERBOSE :
			strBuilder.append("V/");
			break;
		case ERROR :
			strBuilder.append("E/");
			break;
		case WARNING :
			strBuilder.append("W/");
			break;
		case INFO :
			strBuilder.append("I/");
			break;
		default:
			break;
		}

		strBuilder.append(Constants.APP_TAG);
		strBuilder.append("   ");
		strBuilder.append(":");
		strBuilder.append("   ");
		strBuilder.append(msg);

		return strBuilder;
	}

	// for avoid creating object
	private LogUtility() {}

}
