package com.alq.utils;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock.ReadLock;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.ActivityManager.RunningServiceInfo;
import android.app.ActivityManager.RunningTaskInfo;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.Dialog;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.media.ThumbnailUtils;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Build.VERSION_CODES;
import android.os.Environment;
import android.os.IBinder;
import android.os.StatFs;
import android.os.Vibrator;
import android.preference.PreferenceFragment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.NotificationCompat;
import android.telephony.TelephonyManager;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.BackgroundColorSpan;
import android.text.util.Linkify;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup.LayoutParams;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.webkit.MimeTypeMap;
import android.widget.TextView;
import android.widget.Toast;

import com.alq.App;
import com.alq.constant.Constants;

@TargetApi(Build.VERSION_CODES.HONEYCOMB)
public class Utility {

	private static final String TAG = "Utility";
	public static final ReentrantReadWriteLock REENTRANT_READ_WRITE_LOCK = new ReentrantReadWriteLock();

	public static int TYPE_WIFI = 1;
	public static int TYPE_MOBILE = 2;
	public static int TYPE_NOT_CONNECTED = 0;

	public static final int IO_BUFFER_SIZE = 8 * 1024;

	// for avoid creating object
	private Utility() {}

	/**
	 * Show toast message to user
	 * @param context
	 * @param msg
	 */
	public static void showMessage(Context context, String msg) {
		if(context != null && !TextUtils.isEmpty(msg))
			Toast.makeText(context, msg, Toast.LENGTH_LONG).show();
	}


	/**
	 * Show toast message to user
	 * @param context
	 * @param msg
	 */
	public static void showMessage(Context context, int id) {
		Toast.makeText(context, id, Toast.LENGTH_LONG).show();
	}

	public static boolean isExternalStorageRemovable() {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.GINGERBREAD) {
			return Environment.isExternalStorageRemovable();
		}
		return true;
	}

	public static File getExternalCacheDir(Context context) {
		File file = null;
		if (hasExternalCacheDir()) {
			file = context.getExternalCacheDir();
		}

		if(file == null) {
			final String cacheDir = "/Android/data/" + context.getPackageName() + "/cache/";
			file = new File(Environment.getExternalStorageDirectory().getPath() + cacheDir);	
		}
		return file;
	}

	public static boolean hasExternalCacheDir() {
		return Build.VERSION.SDK_INT >= Build.VERSION_CODES.FROYO;
	}

	/**
	 * Gets the version code of app.
	 * @param context
	 * @return
	 */
	public static int getVersionCode(Context context) {

		int versionCode = 0;
		try {
			versionCode = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode;
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}		
		return versionCode;
	}


	/**
	 * Gets the version code of app.
	 * @param context
	 * @return
	 */
	public static String getVersionName(Context context) {

		String versionName = null;
		try {
			versionName = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName;
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}		
		return versionName;
	}

	/**
	 * Check Internet connection availability.
	 * @param context
	 * @return 
	 */
	public static  boolean isNetworkAvailable(Context context) {

		if(context == null) { return false; }

		ReadLock readLock = REENTRANT_READ_WRITE_LOCK.readLock();
		readLock.lock();
		ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
		// if no network is available networkInfo will be null, otherwise check if we are connected
		try {
			NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
			if(activeNetworkInfo.getDetailedState() == NetworkInfo.DetailedState.CONNECTED) {
				return true;
			}
		} catch (Exception e) {
			Log.e(Constants.APP_TAG, TAG + ":: isNetworkAvailable Exception : " + e.getMessage());
		} finally {
			readLock.unlock();
		}
		return false;
	}

	/**
	 * Check Internet connection availability.
	 * @param context
	 * @return 
	 */
	public static  boolean isWiFiAvailable(Context context) {
		if(context == null) { return false; }
		ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
		// if no network is available networkInfo will be null, otherwise check if we are connected
		try {
			NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
			if(activeNetworkInfo.getDetailedState() == NetworkInfo.DetailedState.CONNECTED && activeNetworkInfo.getType() == ConnectivityManager.TYPE_WIFI) {
				return true;
			}
		} catch (Exception e) {
			Log.e(Constants.APP_TAG, TAG + ":: isWiFiAvailable");
		}
		return false;
	}
	/**
	 * Get the device's unique ID that is provided by
	 * {@link TelephonyManager}
	 * @param context
	 * @return
	 */
	public static String getDeviceId(Context context) {
		//		String strDeviceId = "356150059241565";
		TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
		if(telephonyManager  == null ) return "";
		String strDeviceId = telephonyManager.getDeviceId();
		return strDeviceId;
	}

	/**
	 * Check string is null or empty by trim 
	 * @param string
	 * @return status
	 */
	public static boolean isEmpty(String string) {
		if(string != null) {
			string = string.trim();
		}
		return TextUtils.isEmpty(string);
	}

	/**
	 * Calculate device's internal available memory
	 * @return
	 */
	@SuppressWarnings("deprecation")
	public static long getAvailableMemory() {

		File path = Environment.getDataDirectory();

		StatFs stat = new StatFs(path.getPath());

		//The size, in bytes, of a block on the file system.
		long blockSize = stat.getBlockSize();

		//The number of blocks that are free on the file system and available to applications. 
		long availableBlocks = stat.getAvailableBlocks();

		// Return the total memory available in bytes
		return (availableBlocks * blockSize);
	}

	/**
	 * Check is wifi network is available
	 * @param context
	 * @return status
	 */
	public static boolean isWifiNetworkConnected(Context context) {
		try {
			ConnectivityManager connManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
			NetworkInfo mWifi = connManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
			if (mWifi.isConnected()) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * return no of occurrences of content in target string
	 * @param target
	 * @param content
	 * @return count
	 */
	public static int countOccurrences(String find, String string)	{

		int count = 0;
		int indexOf = 0;

		while (indexOf > -1) {
			indexOf = string.indexOf(find, indexOf + 1);
			if (indexOf > -1)
				count++;
		}

		return count;
	}

	/**
	 *  Remove browser Session cookie data
	 */
	public static void clearWebBrowseSessionCookieData(Context context) {
		try {
			CookieSyncManager.createInstance(context);
			CookieManager cookieManager = CookieManager.getInstance();
			cookieManager.removeSessionCookie();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	/**
	 * Convert specified string date into particular format
	 * @param strDate
	 * @param format
	 * @param timeZone 
	 * @return Date
	 */
	@SuppressLint("SimpleDateFormat")
	public static Date getDateFromString(String strDate, String format, TimeZone timeZone) {
		SimpleDateFormat formatter;
		formatter = new SimpleDateFormat(format);
		formatter.setTimeZone(timeZone);
		Date date = null;
		try {
			if(strDate != null)
				date = formatter.parse(strDate);
		} catch (ParseException e) {
			date = null;
		}
		return date;
	}

	/**
	 * Convert specified string date into particular format
	 * @param strDate
	 * @param format
	 * @param timeZone 
	 * @return Date
	 */
	@SuppressLint("SimpleDateFormat")
	public static Date convertStringDateToDateFormat(String strDate, String format) {
		SimpleDateFormat formatter;
		formatter = new SimpleDateFormat(format, Locale.getDefault());
		Date date = null;
		try {
			if(strDate != null)
				date = formatter.parse(strDate);
		} catch (ParseException e) {
			date = null;
		}
		return date;
	}
	
	@SuppressLint("SimpleDateFormat")
	public static Date convertStringDateToDateFormat(String dateString) {
		Date value = null;
		
		if (TextUtils.isEmpty(dateString)) return value;
		DateFormat format = new SimpleDateFormat ("dd-MMM-yyyy");
		format.setTimeZone(TimeZone.getDefault());
		
		try {
			Date date = format.parse(dateString);
			SimpleDateFormat dateFormatter = new SimpleDateFormat(Constants.LOCAL_DATE_PATTERN);
			dateFormatter.setTimeZone(TimeZone.getDefault());
			String dt = dateFormatter.format(date);
			value = dateFormatter.parse(dt);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return value;
	}


	@SuppressLint("SimpleDateFormat")
	public static Date getUTCFormatedDate(long timeMs, String format) {
		DateFormat formatter = new SimpleDateFormat(format);
		formatter.setTimeZone(TimeZone.getTimeZone("UTC"));
		Date date= new Date(timeMs);  
		return date;
	}

	@SuppressLint("SimpleDateFormat")
	public static String getUTCFormatedDate(Date date, String format) {
		DateFormat formatter = new SimpleDateFormat(format);
		String utcDate = formatter.format(date);
		return utcDate;
	}


	/**
	 * Get mime type of specified url
	 * @param url
	 * @return mimeType
	 */
	public static String getMimeType(String url) {
		String type = null;
		String extension = MimeTypeMap.getFileExtensionFromUrl(url);
		if (extension != null) {
			MimeTypeMap mime = MimeTypeMap.getSingleton();
			type = mime.getMimeTypeFromExtension(extension);
		}
		return type;
	}


	/**
	 * Get extension of provided file name
	 * @param fileName
	 * @return extension
	 */
	public static String getFileExtension(String fileName) {
		return MimeTypeMap.getFileExtensionFromUrl(fileName);
	}


	/**
	 * Delete directory contents
	 * @param dir
	 */
	public static void deleteDirectoryContent(File dir) {
		if(dir == null) {
			return;
		}

		try {
			if (dir.isDirectory())
				for (File child : dir.listFiles())
					deleteDirectoryContent(child);
			dir.delete();
			LogUtility.printDebugMessage(TAG+" deleteDirectoryContent = content are removed..!!");
		} catch (Exception e) {
			e.printStackTrace();
		}	
	}


	/**
	 * Create and Send Notification
	 * @param appContext
	 * @param icon
	 * @param role
	 * @param msg
	 * @param when
	 */
	public static void sendNotification(Context appContext, int icon, String title, String msg, long when,  Class<? extends Context> classToLaunch, long processId) {

		NotificationManager notificationManager = (NotificationManager) appContext.getSystemService(Context.NOTIFICATION_SERVICE);

		//Instantiate the notification
		NotificationCompat.Builder builder = new NotificationCompat.Builder(appContext);
		builder.setAutoCancel(true);
		builder.setContentTitle(title);
		builder.setContentText(msg);
		builder.setDefaults(Notification.DEFAULT_ALL);
		builder.setSmallIcon(icon);

		//Define notification msg
		Intent launchIntent = null;

		if(classToLaunch != null) {
			launchIntent = new Intent(appContext, classToLaunch);
		} else {
			launchIntent = new Intent();
		}

		// This is dummy data for just differentiate Pending intent
		// only set value that is check IntentFilter
		launchIntent.addCategory("CATEGOARY"+new Date(System.currentTimeMillis()));
		launchIntent.addFlags((int)System.currentTimeMillis());
		launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		launchIntent.setAction("ACTION"+new Date(System.currentTimeMillis()));

		// intent to be launched when click on notification
		PendingIntent pendingIntent = PendingIntent.getActivity(appContext, 0, launchIntent, PendingIntent.FLAG_UPDATE_CURRENT);

		// will be display in notification list i.e when we pull down notification bar
		builder.setContentIntent(pendingIntent);

		notificationManager.notify((int)processId, builder.build());
	}


	/**
	 * Arrange dialog position
	 * @param dialog
	 * @param gravity
	 */
	public static void setDialogPosition(Dialog dialog, int gravity) {
		WindowManager.LayoutParams layoutParams = dialog.getWindow().getAttributes();
		layoutParams.y = 55;
		if(dialog.getContext() != null) {
			layoutParams.width = android.view.ViewGroup.LayoutParams.MATCH_PARENT;
		} else {
			layoutParams.width = android.view.ViewGroup.LayoutParams.MATCH_PARENT;
		}

		if(dialog.getContext() != null) {
			layoutParams.height = android.view.ViewGroup.LayoutParams.WRAP_CONTENT;
		} else {
			layoutParams.height = android.view.ViewGroup.LayoutParams.WRAP_CONTENT;
		}

		layoutParams.gravity = gravity;

		// very critical if commented won't work on 4.0
		//layoutParams.flags = LayoutParams.FLAG_LAYOUT_NO_LIMITS; // | LayoutParams.FLAG_NOT_TOUCH_MODAL ;

		dialog.getWindow().setAttributes(layoutParams);
		dialog.setCanceledOnTouchOutside(false);
	}


	/**
	 * Change JPG to JPEG extension
	 * @param displayName
	 * @return
	 */
	public static String changeJPGtoJPEG(String displayName) {
		String extension = "";
		String fileName = "";
		if(displayName.contains(".")) {
			extension = displayName.substring(displayName.lastIndexOf(".") + 1);
			fileName = displayName.substring(0, displayName.lastIndexOf("."));
		}

		if(!extension.equalsIgnoreCase("jpg")) {
			return displayName;
		}

		extension = "jpeg";
		return fileName + "." + extension;

	}


	/**
	 * Convert given provided date into provided pattern
	 * @param pattern
	 * @param date
	 * @return {@link String}
	 */
	@SuppressLint("SimpleDateFormat")
	public static String getFormattedDate(String pattern, long millisec) {
		String formattedDate = "";
		try {
			SimpleDateFormat formatter = new SimpleDateFormat(pattern);
			formattedDate = formatter.format(new Date(millisec));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return formattedDate;
	}

	@SuppressLint("SimpleDateFormat")
	public static String getLocalTimezoneDate(long miliseconds) {
		String formattedDate = "";
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
			sdf.setTimeZone(TimeZone.getDefault());
			formattedDate = sdf.format(new Date(miliseconds));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return formattedDate;
	}


	/**
	 * Retrieve the String with provided time zone
	 * @param pattern
	 * @param millisec
	 * @param timeZone
	 * @return {@link String}
	 */
	@SuppressLint("SimpleDateFormat")
	public static String getFormattedDate(String pattern, long millisec, TimeZone timeZone) {
		String gmtString = "";

		try {
			DateFormat gmtFormat = new SimpleDateFormat(pattern);
			gmtFormat.setTimeZone(timeZone);

			gmtString = gmtFormat.format(new Date(millisec)); 
		} catch (Exception e) {
			LogUtility.printErrorMessage(TAG+":getGMTZoneString - "+e.getMessage());
			e.printStackTrace();
		}

		return gmtString;
	}

	/**
	 * Rotate bitmap with provided degree
	 * @param bitmp
	 * @param degree
	 * @return Bitmap
	 */
	public static Bitmap rotateBitmap(Bitmap bm, File path) {
		try {
			int degree = getOrientation(path);
			int width_tmp = bm.getWidth();
			int height_tmp = bm.getHeight();

			// preserve the aspect ratio - scale down when reading in
			float scaleWidth = 1;//scale;
			float scaleHeight = 1;//scale;

			// create a matrix for the manipulation
			Matrix matrix = new Matrix();

			// resize the bit map
			matrix.preScale(scaleWidth, scaleHeight);
			matrix.setRotate(degree);

			// recreate the new Bitmap
			Bitmap rotatedBitmap = Bitmap.createBitmap(bm, 0, 0, width_tmp, height_tmp, matrix, true); 
			return rotatedBitmap;
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bm;
	}

	public static InputStream stringToInputStream(String text)  {
		try {
			return new ByteArrayInputStream(text.getBytes("UTF-8"));
		} catch(UnsupportedEncodingException unsupportedException) {
			return null;
		} catch(Exception exception){
			return null;
		}
	}

	public static boolean isIntentHandlerExist(Context context, Intent intent) {
		if(intent.resolveActivity(context.getPackageManager()) != null) {
			return true;
		}
		return false;
	}

	public static void performActivityInAnimation(Activity activity) {
		// override default activity transition
		//activity.overridePendingTransition(R.anim.start_in_animation, R.anim.start_out_animation);
	}

	public static void performActivityOutAnimation(Activity activity) {
		// override default activity transition
		//activity.overridePendingTransition(R.anim.end_in_animation, R.anim.end_out_animation);
	}

	/**
	 * Build uri to store photo
	 * @param context
	 * @return Uri
	 */
	@SuppressLint("SimpleDateFormat")
	public static Uri getAudioOutputMediaFileUri(Context context) {

		Uri uri = null;

		try {

			StringBuilder stringBuilder = new StringBuilder(); 

			String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(System.currentTimeMillis());
			stringBuilder.append("VOICE_");
			stringBuilder.append(timeStamp);
			stringBuilder.append(".mp4");

			uri = createFileOnSDCard(stringBuilder.toString());
		} catch (Exception e) {

			LogUtility.printErrorMessage(TAG+":getPhotoOutputMediaFileUri - "+e.getMessage());
			e.printStackTrace();
		}
		return uri;
	}

	/**
	 * Create temp file on SD card with provided role in application name directory
	 * @param role
	 * @return {@link Uri}
	 * @throws Exception
	 */
	public static Uri createFileOnSDCard(String title) throws Exception {
		File tempDir = Environment.getExternalStorageDirectory();
		tempDir = new File(tempDir.getAbsolutePath()+File.separator+Constants.APP_TAG);
		if(!tempDir.exists()) {
			tempDir.mkdir();
		}

		File file = new File(tempDir +File.separator+title);
		if(!file.exists()) {
			file.createNewFile();
		}

		return Uri.fromFile(file);
	}

	/**
	 * Create temp file path with provided role 
	 * @param role
	 * @param path
	 * @return {@link Uri}
	 * @throws IOException 
	 */
	public static Uri createFile(String path, String title) throws IOException {
		Uri uri = null;
		File tempDir = new File(path);
		if(!tempDir.exists()) {
			tempDir.mkdir();
		}

		File file = new File(tempDir +File.separator+title);
		if(!file.exists()) {
			file.createNewFile();
		}

		uri = Uri.fromFile(file);
		return uri;
	}

	/**
	 * Build byte array from provided input stream
	 * @param inputStream
	 * @return byte[]
	 * @throws IOException
	 */
	public static byte[] getBytes(InputStream inputStream) throws IOException {
		ByteArrayOutputStream byteBuffer = new ByteArrayOutputStream();
		int bufferSize = 1024;
		byte[] buffer = new byte[bufferSize];

		int len = 0;
		while ((len = inputStream.read(buffer)) != -1) {
			byteBuffer.write(buffer, 0, len);
		}
		return byteBuffer.toByteArray();
	}

	/**
	 * Build base64 string of provided bitmap
	 * @param bitmap
	 * @return {@link String}
	 */
	public static String convertToBase64String(Bitmap bitmap) {
		String base64String = null;
		if(bitmap == null) {
			return base64String;
		}

		try {	
			final int QUALITY = 75;
			ByteArrayOutputStream baos = new ByteArrayOutputStream();  
			bitmap.compress(Bitmap.CompressFormat.JPEG, QUALITY, baos);    
			byte[] b = baos.toByteArray();
			base64String = Base64.encodeToString(b, Base64.DEFAULT);
		} catch (Exception e) {
			LogUtility.printDebugMessage(TAG+" convertToBase64String - "+ e.getMessage());
			e.printStackTrace();
		}
		return base64String;
	}



	/**
	 * Convert innput stream data to string
	 * @param is
	 * @return {@link String}
	 */
	public static String convertStreamToString(InputStream is) {

		if(is == null) {
			return "";
		}

		BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		StringBuilder sb = new StringBuilder();

		String line = null;
		try {
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
		} catch (IOException e) {
			LogUtility.printErrorMessage(TAG+":convertStreamToString - "+e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				LogUtility.printErrorMessage(TAG+":convertStreamToString - "+e.getMessage());
				e.printStackTrace();
			}
		}
		return sb.toString();
	}


	@SuppressLint("SimpleDateFormat")
	public static String getUTCString(long milliseconds) {

		String utcString = "";

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("DD/MM/yyyy hh:mm:ss");
		utcString = simpleDateFormat.format(new Date(milliseconds));

		return utcString;
	}


	/**
	 * Check application is running in foreground or background
	 * @param context
	 * @return boolean
	 */
	public static boolean isAppOnForeground(Context context) {

		ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
		List<RunningAppProcessInfo> appProcesses = activityManager.getRunningAppProcesses();
		if (appProcesses == null) {
			return false;
		}
		final String PKG_NAME = context.getPackageName();
		for (RunningAppProcessInfo appProcess : appProcesses) {
			if (appProcess.importance == RunningAppProcessInfo.IMPORTANCE_FOREGROUND && appProcess.processName.equals(PKG_NAME)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Hide soft input keyboard
	 * @param context
	 * @param windowToken
	 */
	public static void hideSoftKeyboard(Context context, IBinder windowToken) {
		try {
			InputMethodManager inputMethodManager = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
			inputMethodManager.hideSoftInputFromWindow(windowToken, InputMethodManager.RESULT_UNCHANGED_SHOWN);
		} catch (Exception e) {
			LogUtility.printInfoMessage(TAG+":hideSoftKeyboard - "+e.getMessage());
			e.printStackTrace();
		}
	}


	/**
	 * Show soft input keyboard
	 * @param context
	 * @param windowToken
	 */
	public static void showSoftKeyboard(Context context, IBinder windowToken) {
		try {
			InputMethodManager inputMethodManager = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
			inputMethodManager.showSoftInputFromInputMethod(windowToken, InputMethodManager.RESULT_UNCHANGED_SHOWN);
		} catch (Exception e) {
			LogUtility.printInfoMessage(TAG+":showSoftKeyboard - "+e.getMessage());
			e.printStackTrace();
		}
	}


	/**
	 * Get real path from URI
	 * @param context
	 * @param contentURI
	 * @return
	 */
	public static String getRealPathFromURI(Context context, Uri contentURI) {
		Cursor cursor = context.getContentResolver().query(contentURI, null, null, null, null);
		if (cursor == null) { 
			return contentURI.getPath();
		} else { 
			if(cursor.moveToFirst()) { 
				int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA); 
				return cursor.getString(idx);
			} else {
				return contentURI.getPath();
			}
		}
	}

	/**
	 * Check whether the email is a valid email address or not.
	 * It verifies the email with regular expression.
	 * @param email
	 * @return
	 */
	public static boolean isValidEmail(String email) {

		if(email == null || email.length() == 0) return false;

		String regExpn =
				"^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]{1}|[\\w-]{2,}))@"
						+"((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
						+"[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
						+"([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
						+"[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
						+"([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$";

		Pattern patternObj = Pattern.compile(regExpn);

		Matcher matcherObj = patternObj.matcher(email/*May be fetched from  EditText. This string is the one which you wanna validate for email*/);

		if(matcherObj.matches()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Show Date picker dialog
	 * @param activity
	 * @param callback
	 */
	public static void showDatePicker(Activity activity, OnDateSetListener callback) {

		final Calendar c = Calendar.getInstance();
		int year = c.get(Calendar.YEAR);
		int month = c.get(Calendar.MONTH);
		int day = c.get(Calendar.DAY_OF_MONTH);

		DatePickerDialog datePickerDialog = new DatePickerDialog(activity, callback, year, month, day);
		datePickerDialog.show();
	}

	/**
	 * Show time picker dialog
	 * @param activity
	 * @param callback
	 */
	public static void showTimePicker(Activity activity, OnTimeSetListener callback) {

		final Calendar c = Calendar.getInstance();
		int hourOfDay = c.get(Calendar.HOUR_OF_DAY);
		int minute = c.get(Calendar.MINUTE);

		TimePickerDialog timePickerDialog = new TimePickerDialog(activity, callback, hourOfDay, minute, true);
		timePickerDialog.show();
	}

	public static View buildSeperator(Context context, int color) {
		View view = new View(context);
		view.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, 1));
		view.setBackgroundColor(context.getResources().getColor(color));
		return view;
	}


	/**
	 * Launch GPS configure settings activity
	 * @param context
	 */
	public static void launchConfigureGPSSettingActivity(Context context) {
		Intent intent = new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		context.startActivity(intent);
	}

	/**
	 * Convert provided time to UTC data
	 * @param date
	 * @return {@link String}
	 */
	@SuppressLint("SimpleDateFormat")
	public static String convertToUTCTimeZone(long milliseconds, String dateFormat) {
		String utcDateString = null;
		try {
			SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
			formatter.setTimeZone(TimeZone.getTimeZone("UTC"));
			utcDateString = formatter.format(new Date(milliseconds));
		} catch (Exception e) {
			LogUtility.printErrorMessage(TAG+":convertToUTCTimeZone - "+e.getMessage());
			e.printStackTrace();
		}
		//				LogUtility.printInfoMessage(TAG+":convertToUTCTimeZone - "+utcDateString);
		return utcDateString;
	}


	/**
	 * Check provided date is less than current date
	 * @param date
	 * @return status
	 */
	@SuppressLint("SimpleDateFormat")
	public static boolean isDateLessThanCurrentDate(String date) {
		if(date != null) {
			try{
				SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");

				String currentDateString = sdf.format(new Date(System.currentTimeMillis()));

				Date date1 = sdf.parse(currentDateString);
				Date date2 = sdf.parse(date);

				int compResult = date2.compareTo(date1);

				// equal = 0 or greater > 0
				if(compResult < 0) {
					return true;
				}
			}catch(ParseException ex){
				ex.printStackTrace();
			}
		}
		return false;
	}
	/**
	 * Remove (, ) and ' ' char from phone number
	 * @param phoneNumber
	 * @return phoneNumber
	 */
	public static String removeSpecialCharsFromPhoneNumber(String phoneNumber) {
		if(TextUtils.isEmpty(phoneNumber)) return phoneNumber;
		phoneNumber = phoneNumber.replace("(", "").replace(")", "").replace(" ", "");
		return phoneNumber;
	}

	public static String getApplicationDir() {
		String sdCardDir = Environment.getExternalStorageDirectory().getAbsolutePath();
		String appDir = sdCardDir.endsWith("/") ? sdCardDir + ""+Constants.APP_TAG + "/" : sdCardDir + "/"+ Constants.APP_TAG;

		return appDir;
	}

	public static double convertToMilesPerHours(double meterPerSec) {
		// 1 m/s = 2.236936292 miles/hours
		return (2.236936292 * meterPerSec);
	}

	/**
	 * Check provided service name service is running or not
	 * @param serviceClassName
	 * @param appContext
	 * @return status
	 */
	public static boolean isServiceRunning(String serviceClassName, Context appContext) {

		if(TextUtils.isEmpty(serviceClassName) || appContext == null) return false;

		ActivityManager manager = (ActivityManager) appContext.getSystemService(Context.ACTIVITY_SERVICE);
		for (RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
			if (serviceClassName.equals(service.service.getClassName())) {
				return true;
			}
		}

		return false;
	}


	/**
	 * Check provided pkg application is running or not
	 * @param serviceClassName
	 * @param appContext
	 * @return
	 */
	public static boolean isApplicationRunning(String pkgName, Context appContext) {

		if(TextUtils.isEmpty(pkgName) || appContext == null) return false;

		ActivityManager manager = (ActivityManager) appContext.getSystemService(Context.ACTIVITY_SERVICE);
		//		for (RunningAppProcessInfo procInfo : manager.getRunningAppProcesses()) {
		//			if (pkgName.equals(procInfo.processName)) {
		//				return true;
		//			}
		//		}

		for (RunningTaskInfo procInfo : manager.getRunningTasks(Integer.MAX_VALUE)) {
			if (pkgName.equals(procInfo.topActivity.getClassName())) {
				return true;
			}
		}

		return false;
	}


	/**
	 * Check is activity is running 
	 * @param activityClassName (with package)
	 * @param appContext
	 * @return status
	 */
	public static boolean isActivityRunning(String activityClassName, Context appContext) { 

		ActivityManager manager = (ActivityManager) appContext.getSystemService(Context.ACTIVITY_SERVICE);
		for (RunningTaskInfo procInfo : manager.getRunningTasks(Integer.MAX_VALUE)) {
			if (activityClassName.equals(procInfo.topActivity.getClassName())) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Check provided tag fragment is visible or not
	 * @param activity
	 * @param tag
	 * @return status
	 */
	public static Fragment isFragmentVisible(Activity activity, String tag) {
		if(TextUtils.isEmpty(tag)) return null;

		android.app.FragmentManager manager = activity.getFragmentManager();
		return manager.findFragmentByTag(tag);
	}

	/**
	 * Check is camera support by device
	 * @param appContext
	 * @return status
	 */
	public static final boolean isCameraAvailable(Context appContext) {
		if(appContext == null) {
			LogUtility.printErrorMessage(TAG+":isCameraAvailable - app context is null");
			return false;
		}

		PackageManager packageManager = appContext.getPackageManager();
		if(packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA)) {
			return true;
		}

		return false;
	}

	/**
	 * Check is vibrator support by device
	 * @param appContext
	 * @return status
	 */
	public static final boolean isVibratorAvailable(Context appContext) {
		if(appContext == null) {
			LogUtility.printErrorMessage(TAG+":isVibratorAvailable - app context is null");
			return false;
		}

		Vibrator vibrator = (Vibrator) appContext.getSystemService(Context.VIBRATOR_SERVICE);
		if(android.os.Build.VERSION.SDK_INT < VERSION_CODES.HONEYCOMB &&
				vibrator != null) {
			return true;
		} else if(vibrator != null && vibrator.hasVibrator()){
			return true;
		}

		return false;
	}

	/**
	 * Vibrate device till provided time is up
	 * @param context
	 * @param time
	 */
	public static void vibrateDevice(Context context, long time) {
		Vibrator vibrator = (Vibrator)context.getSystemService(Context.VIBRATOR_SERVICE);
		if(!Utility.isVibratorAvailable(context)) return;
		vibrator.vibrate(time);
	}

	/**
	 * Calculate progress out of 100
	 * @param byteUploaded
	 * @param fileLength
	 * @return progress
	 */
	public static  int getProgressUpdate(long byteUploaded, long fileLength) {
		// circle.
		int per = Math.round(((float)byteUploaded / fileLength) * 100);
		//		return (int)((byteUploaded/fileLength)*100);
		return per;
	}

	/**
	 * Delete provided path file if it is directory then recursively contents are deleted
	 * @param path
	 * @return status
	 */
	public static void deleteFile(String path) {
		if(TextUtils.isEmpty(path)) return ;
		File file = new File(path);
		if(file == null || !file.exists()) return ;
		try {
			if(file.isFile()) {
				file.delete();
			} else {
				deleteDirectoryContent(file);
			}
		} catch (Exception exception) {
			LogUtility.printErrorMessage(TAG, exception);
		}
	}

	/**
	 * Add link for provided 
	 * @param textView
	 * @param patternToMatch
	 * @param link
	 */
	public static void addLink(TextView textView, String patternToMatch, final String link) {
		Linkify.TransformFilter filter = new Linkify.TransformFilter() {
			@Override public String transformUrl(Matcher match, String url) {
				return link;
			}
		};
		Linkify.addLinks(textView, Pattern.compile(patternToMatch), null, null, filter);
	}

	/**
	 * Show alert message to user
	 * @param context
	 * @param id
	 */
	public static void showAlertMessage(Context context, int id) {
		if (context == null) {
			return;
		}
		//Instantiate an AlertDialog.Builder with its constructor
		new AlertDialog.Builder(context)
		.setMessage(id)
		.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		})
		.show();
	}

	/**
	 * Show alert message to user
	 * @param context
	 * @param id
	 */
	public static void showAlertMessage(Context context, int id, DialogInterface.OnClickListener listener) {
		if (context == null) {
			return;
		}
		//Instantiate an AlertDialog.Builder with its constructor
		new AlertDialog.Builder(context)
		.setMessage(id)
		.setPositiveButton(android.R.string.ok, listener)
		.show();
	}

	/**
	 * Show alert message to user
	 * @param context
	 * @param msg
	 */
	public static void showAlertMessage(Context context, String msg) {
		if (context == null) {
			return;
		}
		//Instantiate an AlertDialog.Builder with its constructor
		new AlertDialog.Builder(context)
		.setMessage(msg)
		.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		})
		.show();
	}

	public static long getCurTime() {
		return Calendar.getInstance().getTimeInMillis();
	}

	@SuppressLint("SimpleDateFormat")
	public static String getUTCDateTime() {
		String utcString = "";
		final String pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
		utcString = sdf.format(new Date(getCurTime()));

		return utcString;
	}

	@SuppressLint("SimpleDateFormat")
	public static long getParseDateTime(String strDate) {
		String dateStr;
		final String pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
		final String localDatePattern = "yyyy-MM-dd HH:mm:ss";
		Date date = getDateFromString(strDate, pattern, TimeZone.getTimeZone("UTC"));
		if (date != null) {
			SimpleDateFormat sdf = new SimpleDateFormat(localDatePattern);
			sdf.setTimeZone(TimeZone.getDefault());
			dateStr = sdf.format(date);
			date = getDateFromString(dateStr,localDatePattern, TimeZone.getDefault());
		}

		return date.getTime();
	}
	public static void makeCall(Context context, String phoneNumber) {
		String call = "tel:" + phoneNumber;
		Intent phoneIntent = new Intent(Intent.ACTION_CALL);
		phoneIntent.setData(Uri.parse(call));
		try {
			context.startActivity(phoneIntent);
		} catch (android.content.ActivityNotFoundException ex) {
			LogUtility.printErrorMessage(TAG + ": Call failed, please try again later.", ex);
		}
	}

	public static File getRootDir() {
		return Environment.getExternalStorageDirectory();
	}

	public static String getRootDirPath() {
		return getRootDir() + File.separator + Constants.APP_TAG;
	}

	/**
	 * Create the storage directory if it does not exist
	 * @param mediaStorageDir
	 * @return
	 */
	public static boolean makeDirectory(File mediaStorageDir) {
		if (! mediaStorageDir.exists()) {
			if (! mediaStorageDir.mkdirs()){
				Log.d(TAG, "failed to create directory");
				return false;
			}
		}
		return true;
	}

	public static void showAlertMessageDialog(Context context, int resId , DialogInterface.OnClickListener listener) {
		AlertDialog.Builder builder = createAlertDialog(context, 0, listener);
		builder.setMessage(resId);
		builder.show();
	}

	public static void showAlertMessageDialog(Context context, String msg , DialogInterface.OnClickListener listener) {
		AlertDialog.Builder builder = createAlertDialog(context, 0, listener);
		builder.setMessage(msg);
		builder.show();
	}

	public static void showAlertMessageDialog(Context context, int resId, int theme, DialogInterface.OnClickListener listener) {
		AlertDialog.Builder builder = createAlertDialog(context, theme, listener);
		builder.setMessage(resId);
		builder.show();
	}

	private static AlertDialog.Builder createAlertDialog(Context context, int theme, DialogInterface.OnClickListener listener) {
		AlertDialog.Builder builder = new AlertDialog.Builder(context, theme);
		builder.setCancelable(true);

		builder.setPositiveButton(android.R.string.ok, listener);
		builder.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		});
		return builder;
	}

	public static AlertDialog.Builder createAlertDialog(Context context, String buttonText, DialogInterface.OnClickListener listener) {
		AlertDialog.Builder builder = new AlertDialog.Builder(context, 0);
		builder.setCancelable(true);

		builder.setPositiveButton(buttonText, listener);
		builder.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		});
		return builder;
	}

	public static File createTempFile(String path, String title) throws IOException {
		File tempDir = new File(path);
		if(!tempDir.exists()) {
			tempDir.mkdir();
		}

		File file = new File(tempDir +File.separator+title);

		if (file.exists()) {
			file.delete();
		}

		file.createNewFile();

		return file;
	}

	/**
	 * This settings is performed for showing actionbar options menus
	 * on ICS
	 * @param context
	 */
	public static void performActionBarMenuSettingForICS(Context context) {
		try {
			ViewConfiguration config = ViewConfiguration.get(context);
			Field menuKeyField = ViewConfiguration.class.getDeclaredField("sHasPermanentMenuKey");
			if(menuKeyField != null) {
				menuKeyField.setAccessible(true);
				menuKeyField.setBoolean(config, false);
			}
		} catch (Exception ex) {
			LogUtility.printErrorMessage(TAG+":performActionBarMenuSettingForICS - "+ex.getMessage());
			ex.printStackTrace();
		}
	}

	private static int getOrientation(File path) throws IOException {
		ExifInterface exif = new ExifInterface(path.getAbsolutePath());
		int orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
		int rotate = 0;
		switch (orientation) {
		case ExifInterface.ORIENTATION_ROTATE_270 :
			rotate = 270;
			break;
		case ExifInterface.ORIENTATION_ROTATE_180 :
			rotate = 180;
			break;
		case ExifInterface.ORIENTATION_ROTATE_90 :
			rotate = 90;
			break;
		}
		return rotate;
	}

	public static byte[] convertBitmapToByteArray(Bitmap bitmap) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		bitmap.compress(CompressFormat.JPEG, 90, baos);
		byte[] photoBytes  = baos.toByteArray();

		return photoBytes;
	}

	public static String getPhoneNumberWithCountryCode(String countryCode,
			String phoneNumber) {
		return	String.format("+%s%s", countryCode, phoneNumber);
	}

	public static String appendPlusPrefix(String countryCode) {
		return String.format("+%s",countryCode);
	}

	@SuppressLint("SimpleDateFormat")
	public static long convertUTCDateToLocalDate(String dateString) {
		if (TextUtils.isEmpty(dateString)) return 0;
		DateFormat format = new SimpleDateFormat ("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		format.setTimeZone(TimeZone.getTimeZone("UTC"));
		long value = 0;
		try {
			Date date = format.parse(dateString);
			SimpleDateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy hh:mmaa");
			dateFormatter.setTimeZone(TimeZone.getDefault());

			Calendar calendar = Calendar.getInstance();
			calendar.setTime(date);
			value = calendar.getTimeInMillis();
			System.out.println("Long Value :: "+ value);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return value;
	}

	@SuppressLint("SimpleDateFormat")
	public static Date convertUTCDateToLocalDateTime(String dateString) {
		if (TextUtils.isEmpty(dateString) || dateString.equals("0")) return null;
		DateFormat format = new SimpleDateFormat ("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		format.setTimeZone(TimeZone.getTimeZone("UTC"));
		try {
			Date date = format.parse(dateString);
			SimpleDateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
			dateFormatter.setTimeZone(TimeZone.getDefault());
			String dt = dateFormatter.format(date);
			return dateFormatter.parse(dt);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static Object getJsonObjectValue(JSONObject obj, String fieldName) throws JSONException {
		if (obj == null) return null;
		if (obj.has(fieldName)) {
			return obj.get(fieldName);
			//return obj.getString(fieldName);
		}
		return null;
	}

	public static boolean getJsonObjectBooleanValue(JSONObject obj, String fieldName) throws JSONException {
		if (obj.has(fieldName)) {
			return obj.getBoolean(fieldName);
		}
		return false;
	}

	public static File getMediaDirPath() {
		String path = Utility.getRootDir() + File.separator + Constants.APP_TAG;
		File mediaStorageDir = new File(path, Constants.FOLDER_NAME_MEDIA);
		return mediaStorageDir;
	}

	public static File getExportDirPath() {
		String path = Utility.getRootDir() + File.separator + Constants.APP_TAG;
		File mediaStorageDir = new File(path, Constants.FOLDER_NAME_EXPORT);
		return mediaStorageDir;
	}

	public static File createCatlogDir() {
		String path = Utility.getRootDir() + File.separator + Constants.APP_TAG;
		File catlogDir = new File(path, Constants.FOLDER_NAME_CATLOG);

		// Create the storage directory if it does not exist
		if (!Utility.makeDirectory(catlogDir)) {
			return null;
		}

		return catlogDir;
	}

	public static boolean isCursorEmpty(Cursor cursor) {
		if(cursor != null) {
			if(cursor.getCount() > 0) {
				return false;
			}
			cursor.close();
		}
		return true;
	}

	/**
	 * This method converts dp unit to equivalent pixels, depending on device density. 
	 * 
	 * @param dp A value in dp (density independent pixels) unit. Which we need to convert into pixels
	 * @param context Context to get resources and device specific display metrics
	 * @return A float value to represent px equivalent to dp depending on device density
	 */
	public static float convertDpToPixel(float dp, Context context) {
		Resources resources = context.getResources();
		DisplayMetrics metrics = resources.getDisplayMetrics();
		float px = dp * (metrics.densityDpi / 160f);
		return px;
	}

	/**
	 * This method converts device specific pixels to density independent pixels.
	 * 
	 * @param px A value in px (pixels) unit. Which we need to convert into db
	 * @param context Context to get resources and device specific display metrics
	 * @return A float value to represent dp equivalent to px value
	 */
	public static float convertPixelsToDp(float px, Context context) {
		Resources resources = context.getResources();
		DisplayMetrics metrics = resources.getDisplayMetrics();
		float dp = px / (metrics.densityDpi / 160f);
		return dp;
	}

	public static void compressImage(File file) {
		try {
			Bitmap scaledBitmap = null;

			if (file == null) return;
			String filePath  = file.getAbsolutePath();

			Bitmap bmp = ScalingUtilities.decodeFile(filePath);
			scaledBitmap = Utility.rotateBitmap(bmp, file);

			FileOutputStream out = null;
			try {
				out = new FileOutputStream(file);
				// write the compressed bitmap at the destination specified by filename.
				scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 85, out);

			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	/**
	 * convert duration from milliseconds to hours, minute and seconds
	 * @param duration
	 * @return
	 */
	public static String getDuration(long milliseconds) {

		int seconds = (int) (milliseconds / 1000) % 60;
		int minutes = (int) ((milliseconds / (1000*60)) % 60);
		int hours   = (int) ((milliseconds / (1000*60*60)) % 24);

		String sec = String.valueOf(seconds);
		String min = String.valueOf(minutes);

		//if seconds in single digit add one more digit
		if(sec.length()<2){
			sec = "0"+sec;
		}

		//if minute in single digit add one more digit
		if(min.length()<2){
			min="0"+min;
		}

		if(hours>0) {			
			String hr = String.valueOf(hours);

			//if hours in single digit add one more digit
			if(hr.length()<2){
				hr = "0"+hr;
			}
			return (hr+":"+min+":"+sec);
		} else if(minutes>0) {
			return (min+":"+sec);
		}
		return String.valueOf("00:"+sec);
	}

	public static void highlitText(String highlightedText, String withInText, TextView textView) {
		if(TextUtils.isEmpty(highlightedText) || TextUtils.isEmpty(withInText)) return;

		highlightedText = highlightedText.trim();
		withInText = withInText.trim();

		Spannable raw=new SpannableString(withInText);
		BackgroundColorSpan[] spans=raw.getSpans(0,
				raw.length(),
				BackgroundColorSpan.class);

		for (BackgroundColorSpan span : spans) {
			raw.removeSpan(span);
		}

		int index = TextUtils.indexOf(raw, highlightedText);

		while (index >= 0) {
			raw.setSpan(new BackgroundColorSpan(0xFFFFFF00), index, index
					+ highlightedText.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
			index=TextUtils.indexOf(raw, highlightedText, index + highlightedText.length());
		}
		textView.setText(raw);
	}

	public static void showKeyboard(Context context) {
		((InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE)).
		toggleSoftInput(InputMethodManager.SHOW_FORCED,
				InputMethodManager.HIDE_IMPLICIT_ONLY);
	}

	public static Bitmap getBitmapThumbnailFromFilePath(String filepath, int type) {
		switch (type) {
		case CameraManager.MEDIA_TYPE_IMAGE:
			//get extract thumbnail bitmap from image path
			return ThumbnailUtils.extractThumbnail(BitmapFactory.decodeFile(filepath), 96, 96);
		default:
			break;
		}
		return null;
	}

	public static void showChooseVideoMediaIntent(Context activity, String filePath) {
		Uri fileUri = Uri.fromFile(new File(filePath));
		Intent videoIntent = new Intent(Intent.ACTION_VIEW);
		videoIntent.setDataAndType(fileUri,               
				URLConnection.guessContentTypeFromName(fileUri.toString()));

		// Verify it resolves
		PackageManager packageManager = App.getInstance().getApplicationContext().getPackageManager();

		// Start an activity if it's safe
		if (videoIntent.resolveActivity(packageManager) != null) {
			activity.startActivity(videoIntent);
		} 
	}

	public static void fragmentTransaction(String tag, int newFragmentId, Fragment fragment, Context activity, boolean addToBackStack) {
		FragmentManager fragmentManager = ((Activity) activity).getFragmentManager();
		FragmentTransaction ft = fragmentManager.beginTransaction();

		if(TextUtils.isEmpty(tag)) {
			ft.replace(newFragmentId, fragment);
		} else {
			ft.replace(newFragmentId, fragment, tag);
		}
		if(addToBackStack) ft.addToBackStack(null);
		ft.commit();          
	}

	public static void fragmentTransaction(String tag, int newFragmentId, android.support.v4.app.Fragment fragment, Context activity, boolean addToBackStack) {
		android.support.v4.app.FragmentManager fragmentManager = ((FragmentActivity) activity).getSupportFragmentManager();
		android.support.v4.app.FragmentTransaction ft = fragmentManager.beginTransaction();

		if(TextUtils.isEmpty(tag)) {
			ft.replace(newFragmentId, fragment);
		} else {
			ft.replace(newFragmentId, fragment, tag);
		}
		if(addToBackStack) ft.addToBackStack(null);
		ft.commit();          
	}


	public static void fragmentTransaction(String tag, int newFragmentId, PreferenceFragment fragment, Context activity, boolean addToBackStack) {
		FragmentManager fragmentManager = ((Activity) activity).getFragmentManager();
		FragmentTransaction ft = fragmentManager.beginTransaction();

		if(TextUtils.isEmpty(tag)) {
			ft.replace(newFragmentId, fragment);
		} else {
			ft.replace(newFragmentId, fragment, tag);
		}
		if(addToBackStack) ft.addToBackStack(null);
		ft.commit();          
	}

	/**
	 * @param context
	 * this function check Mobile data or wifi is connected or not.
	 * @return
	 */
	public static int getConnectivityStatus(Context context) {
		ConnectivityManager cm = (ConnectivityManager) context
				.getSystemService(Context.CONNECTIVITY_SERVICE);

		NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
		if (null != activeNetwork) {
			if(activeNetwork.getType() == ConnectivityManager.TYPE_WIFI)
				return TYPE_WIFI;

			if(activeNetwork.getType() == ConnectivityManager.TYPE_MOBILE)
				return TYPE_MOBILE;
		}
		return TYPE_NOT_CONNECTED;
	}

	/**
	 * Get date format that set from prefernce setting
	 *
	 * @param appContext
	 * @return {@link DateFormat}
	 */
	public static DateFormat getPreferedDateFormat(Context appContext) {
		DateFormat dateFormat = null;
		final String format = Settings.System.getString(appContext.getContentResolver(), Constants.LOCAL_DATE_PATTERN);
		if (TextUtils.isEmpty(format)) {
			dateFormat = android.text.format.DateFormat.getMediumDateFormat(appContext);
		} else {
			dateFormat = new SimpleDateFormat(format, Locale.getDefault());
		}
		return dateFormat;
	}

	/**
	 * Get time format that set from preference setting
	 *
	 * @param appContext
	 * @return {@link DateFormat}
	 */
	public static DateFormat getPreferedTimeFormat(Context appContext) {
		DateFormat dateFormat = null;
		final String format = Settings.System.getString(appContext.getContentResolver(), Settings.System.TIME_12_24);
		if (TextUtils.isEmpty(format)) {
			dateFormat = android.text.format.DateFormat.getMediumDateFormat(appContext);
		} else {
			dateFormat = new SimpleDateFormat(format, Locale.getDefault());
		}
		return dateFormat;
	}
	
	public static boolean isAdminUser(Context context) {
		if ("Admin".contains(PrefsUtility.getInstance().getUsername())) {
			return true;
		}
		return false;
	}

}
