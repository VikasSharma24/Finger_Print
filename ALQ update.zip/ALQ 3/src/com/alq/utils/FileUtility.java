package com.alq.utils;

import java.io.File;
import java.text.DecimalFormat;

import android.content.Context;
import android.text.TextUtils;

/**
 * File Utility implements methods to perform file operations. 
 * @author Aloha
 */
public class FileUtility {

	private static final String TAG = "FileUtility";

	/**
	 *  Check if  file is exist at given file location.
	 * @param path
	 * @return
	 */
	public static boolean isFileExist(String path) {

		boolean toReturn = false;

		if(path == null || path.length() == 0) return toReturn;

		try {
			File file = new File(path);
			if(file.exists()) toReturn = true;
		} catch(Exception ex) {
			LogUtility.printErrorMessage(TAG + "isFileExist : Exception occured " + ex.getMessage());
		}

		return toReturn;
	}

	/**
	 * Delete file from given path if exist.
	 * @param path
	 */
	public static boolean deleteFileFromPath(String path) {
		
		//check file path is null or empty
		if(TextUtils.isEmpty(path)) return false;

		try {
			File file = new File(path);
			
			//check file is exist on storage
			if(file.exists()) {
				return file.delete();
			}
		} catch(Exception ex) {
			LogUtility.printErrorMessage(TAG + "deleteFileFromPath : Exception occured " + ex.getMessage());
		}
		return false;
	}

	/**
	 * Delete file from given path if exist.
	 * @param path
	 */
	public static void deleteFilesFromDirectory(String directoryPath) {

		if(directoryPath == null || directoryPath.length() == 0) return;

		try {
			File file = new File(directoryPath);
			if(file.exists()) {
				clearData(file);
			}
		} catch(Exception ex) {
			LogUtility.printErrorMessage(TAG + "deleteFileFromPath : Exception occured " + ex.getMessage());
		}
	}



	/**
	 * Clear the application's data files.
	 * @param context
	 */
	public static void deleteAllFiles(Context context) {
		try {
			File file = context.getFilesDir();
			if(file.exists() && file.isDirectory()) {
				clearData(file);
			}
		} catch(Exception ex) {
			LogUtility.printErrorMessage(TAG + "deleteAllFiles : Exception occured " + ex.getMessage()); 
		}
	}

	/**
	 * Recursively delete all files present in data directory
	 * @param rootDirectory
	 */
	private static void clearData(File rootDirectory) {
		File[] fileList = rootDirectory.listFiles();

		for(int i = 0; i < fileList.length; i++) {
			// Recursive call if it's a directory
			if(fileList[i].isDirectory()) {
				clearData(fileList [i]);
			} else {
				fileList[i].delete();
			}
		}
	}


	public static String getFileName(String filePath) {

		if(!isFileExist(filePath)) return "";

		File file = new File(filePath);

		return file.getName();
	}

	public static String getExtensionWithDot(String name) {
		String ext;
		
		if(name.lastIndexOf(".")==-1){
			ext="";

		} else{
			int index=name.lastIndexOf(".");
			ext = name.substring(index);
		}
		return ext;
	}

	/**
	 * Checks is file having supported image extension 
	 * @param fileName
	 * @return
	 */
	public static boolean havingSupportedImageFormat(String fileName) {
		if(fileName.endsWith(".jpg")   || fileName.endsWith(".JPG")  || 
				fileName.endsWith(".gif")  || fileName.endsWith(".GIF")  || 
				fileName.endsWith(".png")  || fileName.endsWith(".PNG")  || 
				fileName.endsWith(".bmp")  || fileName.endsWith(".bmp")  ||
				fileName.endsWith(".webp") || fileName.endsWith(".WEBP") ||
				fileName.endsWith(".jpeg") || fileName.endsWith(".JPEG")) {
			return true;
		}
		return false;
	}

	/**
	 * Checks is file having supported audio extension 
	 * @param fileName
	 * @return
	 */
	public static boolean havingSupportedVideoFormat(String fileName) {
		if(fileName.endsWith(".3gp")   || fileName.endsWith(".3GP")  || 
				fileName.endsWith(".mp4")  || fileName.endsWith(".MP4")  ||
				fileName.endsWith(".ts")   || fileName.endsWith(".TS")   || 
				fileName.endsWith(".webm") || fileName.endsWith(".WEBM") ||
				fileName.endsWith(".mkv")  || fileName.endsWith(".MVK") ||
				fileName.endsWith(".flv")  || fileName.endsWith(".FLV") ||
				fileName.endsWith(".wmv")  || fileName.endsWith(".WMV"))  {
			return true;
		}
		return false;
	}

	// Avoid creation of object
	private FileUtility() {}

	public static long getFileSize(String filepath) {
		long fileSize = 0;
		try {
			File file = new File(filepath);
			if (file.exists()) {
				long bytes = file.length();
				//long kilobytes = (bytes / 1024);
				//long megabytes = (kilobytes / 1024);
				fileSize = bytes;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return fileSize;
	}
	
	public static String readableFileSize(long size) {
	    if(size <= 0) return "0";
	    final String[] units = new String[] { "B", "kB", "MB", "GB", "TB" };
	    int digitGroups = (int) (Math.log10(size)/Math.log10(1024));
	    return new DecimalFormat("#0.00").format(size/Math.pow(1024, digitGroups)) + " " + units[digitGroups];
	}

}
