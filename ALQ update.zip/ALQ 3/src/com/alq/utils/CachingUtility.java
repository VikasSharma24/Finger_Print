package com.alq.utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import android.content.Context;

public class CachingUtility {
	
	private static final String DIR_NAME = "AlqDir";
	private static File iAlqDir;
	
	private CachingUtility() {}
	
	public static void createDirectory(Context context) {
		iAlqDir = context.getDir(DIR_NAME, Context.MODE_PRIVATE); //Creating an internal dir;
	}
	
	public static void createFileInDirectory(String fileName, byte[] imageData) {
		try {
			File fileWithinMyDir = new File(iAlqDir, fileName); //Getting a file within the dir.
			FileOutputStream out = new FileOutputStream(fileWithinMyDir);//Use the stream as usual to write into the file.
			out.write(imageData);
			out.flush();
			out.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} 
	}
}
