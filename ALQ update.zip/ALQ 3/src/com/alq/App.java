package com.alq;

import android.app.Application;
import android.content.Context;
import android.graphics.Bitmap;
import android.support.v4.util.LruCache;

import com.alq.utils.Utility;
import com.nostra13.universalimageloader.cache.disc.naming.Md5FileNameGenerator;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.QueueProcessingType;

public class App extends Application {
	public static final String TAG = App.class.getSimpleName();

	public static final int APP_ID = 200;
	private static App singleTon;
	private Context mApplicationContext;
	private LruCache<String, Bitmap> mImageMemoryCache;
	private boolean isAppForground;

	public App() {
		super();
		mApplicationContext = this;
		singleTon = this;
	}

	@Override
	public void onCreate() {
		super.onCreate();
		singleTon = this;

		if(mImageMemoryCache == null) configureLRUCache();
		
		initImageLoader(this);
		Utility.createCatlogDir();
	}

	@Override
	public void onTrimMemory(int level) {
		super.onTrimMemory(level);
	}

	/**
	 * Configure LRU memory cache
	 */
	private void configureLRUCache() {
		// Get max available VM memory, exceeding this amount will throw an
		// OutOfMemory exception. Stored in kilobytes as LruCache takes an
		// int in its constructor.
		final int maxMemory = (int) (Runtime.getRuntime().maxMemory() / 1024);

		// Use 1/8th of the available memory for this memory cache.
		final int cacheSize = maxMemory / 8;

		mImageMemoryCache = new LruCache<String, Bitmap>(cacheSize) {
			@Override
			protected int sizeOf(String key, Bitmap bitmap) {
				// The cache size will be measured in kilobytes rather than
				// number of items.
				return bitmap.getByteCount() / 1024;
			}
		};
	}

	public void addBitmapToMemoryCache(String key, Bitmap bitmap) {
		if (key == null) return;
		if (getBitmapFromMemCache(key) == null) {
			mImageMemoryCache.put(key, bitmap);
		}
	}

	public void removeBitmapToMemoryCache(String key) {
		if (key == null) return;
		if (getBitmapFromMemCache(key) != null) {
			mImageMemoryCache.remove(key);
		}
	}

	public boolean isBitMapAvailable(String key) {
		return (getBitmapFromMemCache(key) != null) ? true : false;
	}

	public Bitmap getBitmapFromMemCache(String key) {
		if (key == null) return null;
		return mImageMemoryCache.get(key);
	}

	public static synchronized App getInstance() {
		return singleTon;
	}

	@Override
	public void onTerminate() {
		super.onTerminate();
	}

	public Context getApplicationContext() {
		return mApplicationContext;
	}

	public boolean isAppForground() {
		return isAppForground;
	}

	public void setAppForground(boolean isAppForground) {
		this.isAppForground = isAppForground;
	}
	

	public static void initImageLoader(Context context) {
		// This configuration tuning is custom. You can tune every option, you may tune some of them,
		// or you can create default configuration by
		//  ImageLoaderConfiguration.createDefault(this);
		// method.
		ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(context)
				.threadPriority(Thread.NORM_PRIORITY - 2)
				.denyCacheImageMultipleSizesInMemory()
				.diskCacheFileNameGenerator(new Md5FileNameGenerator())
				.diskCacheSize(50 * 1024 * 1024) // 50 Mb
				.tasksProcessingOrder(QueueProcessingType.LIFO)
				.writeDebugLogs() // Remove for release app
				.build();
		// Initialize ImageLoader with configuration.
		ImageLoader.getInstance().init(config);
	}

}
