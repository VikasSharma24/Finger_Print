package com.alq.constant;

public class Constants {

	public static final String APP_TAG = "ALQ";
	public static String FOLDER_NAME_MEDIA = "Media";
	public static String FOLDER_NAME_CATLOG = "Catalogue";
	public static String FOLDER_NAME_EXPORT = "Export";
	public static String EXTRA_SEARCH_IMAGE_DETAILS = "extra_search_image_details";
	
	public static final String LOCAL_DATE_PATTERN = "yyyy-MM-dd";
	public static final String LOCAL_DATE_PATTERN_1 = "yyyy-mm-dd";
	
	public static final int INVALID_ID = -1;
	
	//API response param
	public static final String PARAM_STATUS = "status";
	public static final String PARAM_REASON = "reason";
	public static final String PARAM_STOCK_INFORMATION_RESULT = "stockInformationResult";
	public static final String PARAM_FINAL_CUSTOMER_lIST = "finalCustomerList";
	public static final String PARAM_CUSTOMER_INFO_RESULT = "customerInfoResult";
	public static final String PARAM_CUSTOMER_INFO = "customerInfo";
	public static final String PARAM_DOWNLOAD_IMAGES_PATH_RESULT = "downloadImagesPathResult";
	public static final String PARAM_IMAGE_DOWNLOAD_LIST = "imageDownloadList";
	public static final String PARAM_DONWLOAD_IMAGE_PATH = "imagePath";
	public static final String PARAM_DOWNLOAD_IMAGE_SYNC_DATE = "synchDate";
	
	public static final String PARAM_DOWNLOAD_IMAGES_DATA_RESULT = "downloadImagesDataResult";
	
	public static final int REQUEST_TIMEOUT = 20000;
	
	public static final String PARAM_IMAGE_NAME = "imageName";
	public static final String PARAM_IMAGE_DATA = "imageData";
	
	
	public interface URLs {
		final static String BASE_URL = "http://smartbaby.dyndns.org:8090/ExcelFileService/ExcelFileServices/";
		final static String BASE_SYN_URL = "http://smartbaby.dyndns.org:8090/ExcelFileService/SyncExcelServices/";
		final static String SEARCH_URL = BASE_URL + "GetStockInformation/";
		final static String SAVE_PHOTO_URL = BASE_URL + "upload-image/";
		final static String GET_STOCK_INFO_URL = BASE_SYN_URL + "getAllStockInformationByGet/";
		final static String GET_CUST_INFO_URL = BASE_SYN_URL + "GetAllCustomerInformation/";
		final static String GET_DOWNLOAD_IMAGES_URL = BASE_SYN_URL + "GetDownloadImagesPath/";
		final static String GET_DOWNLOAD_IMAGES_DATA = BASE_URL + "getDownloadImagesData/";
	}
	
	public interface HTTPMethod {
		final static String POST = "POST";
		final static String GET = "GET";
	}

}
