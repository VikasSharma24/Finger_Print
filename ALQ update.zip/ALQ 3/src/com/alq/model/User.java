package com.alq.model;

public class User {
	
	private String username;
	private String password;
}
