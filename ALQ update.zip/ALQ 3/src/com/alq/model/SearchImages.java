package com.alq.model;

import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;

import com.alq.constant.Constants;
import com.alq.model.dao.StockInformationDAO;
import com.alq.utils.Utility;

public class SearchImages implements Parcelable {

	private long rowId;
	private String itemCode;
	private String articleNo;
	private String description;
	private String boothNo;
	private String packing;
	private String brand;
	private String colour;
	private String weight;
	private String measurement;
	private String origin;

	private String size;
	private double puchasePrice;
	private String orderDate;
	private String imagePath;
	
	private String currency;
	private String customerCode;
	private String customerCountry;
	private String customerName;
	private int    lastArrivalQuantity;
	private String lastOrderDate;
	private String lastPurchaseDate;
	private String lastSellDate;
	private float  markUpValue;
	private int    perPiecePrice;
	private int    creditPrice;
	private int    stockAvailable;
	private double wholesalePrice;
	private String barcode;
	
	public SearchImages() {
		this.rowId = Constants.INVALID_ID;
	}
	
	public long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public String getItemCode() {
		return itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	public String getArticleNo() {
		return articleNo;
	}

	public void setArticleNo(String articleNo) {
		this.articleNo = articleNo;
	}

	public String getBoothNo() {
		return boothNo;
	}

	public void setBoothNo(String boothNo) {
		this.boothNo = boothNo;
	}

	public String getPacking() {
		return packing;
	}

	public void setPacking(String packing) {
		this.packing = packing;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getColour() {
		return colour;
	}

	public void setColour(String colour) {
		this.colour = colour;
	}

	public String getWeight() {
		return weight;
	}

	public void setWeight(String weight) {
		this.weight = weight;
	}

	public String getMeasurement() {
		return measurement;
	}

	public void setMeasurement(String measurement) {
		this.measurement = measurement;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public double getPrice() {
		return puchasePrice;
	}

	public void setPrice(float puchasePrice) {
		this.puchasePrice = puchasePrice;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public double getPuchasePrice() {
		return puchasePrice;
	}

	public void setPuchasePrice(double puchasePrice) {
		this.puchasePrice = puchasePrice;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getCustomerCode() {
		return customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	public String getCustomerCountry() {
		return customerCountry;
	}

	public void setCustomerCountry(String customerCountry) {
		this.customerCountry = customerCountry;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public int getLastArrivalQuantity() {
		return lastArrivalQuantity;
	}

	public void setLastArrivalQuantity(int lastArrivalQuantity) {
		this.lastArrivalQuantity = lastArrivalQuantity;
	}

	public String getLastOrderDate() {
		return lastOrderDate;
	}

	public void setLastOrderDate(String lastOrderDate) {
		this.lastOrderDate = lastOrderDate;
	}

	public String getLastPurchaseDate() {
		return lastPurchaseDate;
	}

	public void setLastPurchaseDate(String lastPurchaseDate) {
		this.lastPurchaseDate = lastPurchaseDate;
	}

	public String getLastSellDate() {
		return lastSellDate;
	}

	public void setLastSellDate(String lastSellDate) {
		this.lastSellDate = lastSellDate;
	}

	public float getMarkUpValue() {
		return markUpValue;
	}

	public void setMarkUpValue(float markUpValue) {
		this.markUpValue = markUpValue;
	}

	public int getPerPiecePrice() {
		return perPiecePrice;
	}

	public void setPerPiecePrice(int perPiecePrice) {
		this.perPiecePrice = perPiecePrice;
	}

	public int getCreditPrice() {
		return creditPrice;
	}

	public void setCreditPrice(int creditPrice) {
		this.creditPrice = creditPrice;
	}

	public int getStockAvailable() {
		return stockAvailable;
	}

	public void setStockAvailable(int stockAvailable) {
		this.stockAvailable = stockAvailable;
	}

	public double getWholesalePrice() {
		return wholesalePrice;
	}

	public void setWholesalePrice(double wholesalePrice) {
		this.wholesalePrice = wholesalePrice;
	}
	
	public String getBarcode() {
		return barcode;
	}

	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}

	/*
	 * {"stockInformationResult":{"finalCustomerList":{"articleNo":"OK8118","boothNo":"2F-36175-7-1","brand":"INTEX","colour":"GREY",
	 * "creditPrice":480,"currency":"RMB","customerCode":"001007","customerCountry":"Male","customerName":"Shokran Mr.","description":"LEATHER SHOE POLISH 2-SECTION",
	 * "imagePath":"E:\/AnandData\/SearchApp_Data_code\/Images\/0210022.png","itemCode":"0210022","lastArrivalQuantity":10,"lastOrderDate":"15-Dec-14","lastPurchaseDate":"01-May-13",
	 * "lastSellDate":"24-Nov-14","markUpValue":1,"measurement":"3.42 CUF","orderDate":"15-Dec-14","origin":"CHINA","packing":"1*20BOX*12PCS","perPiecePrice":2,
	 * "puchasePrice":1.6,"size":"11X45X60","stockAvailable":5,"weight":"13.5 KG.","wholesalePrice":384.01},"reason":"OK","status":"success"}}
	 */
	public static SearchImages getSearchItemDataFromJSON(JSONObject jsonObject) throws JSONException {
		SearchImages searchImages = new SearchImages();
		
		searchImages.setItemCode((String) Utility.getJsonObjectValue(jsonObject, "itemCode"));
		searchImages.setDescription((String) Utility.getJsonObjectValue(jsonObject, "description"));
		searchImages.setArticleNo((String) Utility.getJsonObjectValue(jsonObject, "articleNo"));
		searchImages.setBoothNo((String) Utility.getJsonObjectValue(jsonObject, "boothNo"));
		searchImages.setPacking((String) Utility.getJsonObjectValue(jsonObject, "packing"));

		searchImages.setOrderDate((String) Utility.getJsonObjectValue(jsonObject, "orderDate"));
		searchImages.setBrand((String) Utility.getJsonObjectValue(jsonObject, "brand"));
		searchImages.setColour((String) Utility.getJsonObjectValue(jsonObject, "colour"));
		searchImages.setSize((String) Utility.getJsonObjectValue(jsonObject,"size"));
		searchImages.setWeight((String) Utility.getJsonObjectValue(jsonObject, "weight"));
		searchImages.setMeasurement((String) Utility.getJsonObjectValue(jsonObject, "measurement"));
		searchImages.setOrigin((String) Utility.getJsonObjectValue(jsonObject, "origin"));
		searchImages.setImagePath((String) Utility.getJsonObjectValue(jsonObject, "imagePath"));

		searchImages.setCreditPrice(jsonObject.getInt("creditPrice"));
		searchImages.setPuchasePrice(jsonObject.getDouble("puchasePrice"));
		searchImages.setWholesalePrice(jsonObject.getDouble("wholesalePrice"));
		searchImages.setOrigin((String) Utility.getJsonObjectValue(jsonObject, "currency"));
		
		searchImages.setStockAvailable(jsonObject.getInt("stockAvailable"));
		searchImages.setLastArrivalQuantity(jsonObject.getInt("lastArrivalQuantity"));
		searchImages.setLastOrderDate((String) Utility.getJsonObjectValue(jsonObject, "lastOrderDate"));
		searchImages.setLastPurchaseDate((String) Utility.getJsonObjectValue(jsonObject, "lastPurchaseDate"));
		searchImages.setLastSellDate((String) Utility.getJsonObjectValue(jsonObject, "lastSellDate"));

		searchImages.setCustomerCode((String) Utility.getJsonObjectValue(jsonObject, "customerCode"));
		searchImages.setCustomerCountry((String) Utility.getJsonObjectValue(jsonObject, "customerCountry"));
		searchImages.setCustomerName((String) Utility.getJsonObjectValue(jsonObject, "customerName"));

		return searchImages;
	}

	@Override
	public int describeContents() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void writeToParcel(Parcel parcel, int flag) {
		parcel.writeString(itemCode);
		parcel.writeString(articleNo);
		parcel.writeString(description);
		parcel.writeString(boothNo);
		parcel.writeString(packing);
		parcel.writeString(brand);
		parcel.writeString(colour);
		parcel.writeString(weight);
		parcel.writeString(measurement);
		parcel.writeString(origin);
		parcel.writeString(size);
		parcel.writeDouble(puchasePrice);
		parcel.writeString(orderDate);
		parcel.writeString(imagePath);
		parcel.writeString(currency);
		parcel.writeString(customerCode);
		parcel.writeString(customerCountry);
		parcel.writeString(customerName);
		parcel.writeInt(lastArrivalQuantity);
		parcel.writeString(lastOrderDate);
		parcel.writeString(lastPurchaseDate);
		parcel.writeString(lastSellDate);
		parcel.writeFloat(markUpValue);
		parcel.writeInt(perPiecePrice);
		parcel.writeInt(creditPrice);
		parcel.writeInt(stockAvailable);
		parcel.writeDouble(wholesalePrice);
		parcel.writeString(barcode);
	}
	
	public static final Parcelable.Creator<SearchImages> CREATOR = new Creator<SearchImages>() { 
		public SearchImages createFromParcel(Parcel source) { 
			SearchImages searchImages = new SearchImages(); 
			searchImages.itemCode = source.readString();           
			searchImages.articleNo = source.readString();          
			searchImages.description = source.readString();        
			searchImages.boothNo = source.readString();            
			searchImages.packing = source.readString();            
			searchImages.brand = source.readString();              
			searchImages.colour = source.readString();             
			searchImages.weight = source.readString();             
			searchImages.measurement = source.readString();        
			searchImages.origin = source.readString();             
			                    
			searchImages.size = source.readString();               
			searchImages.puchasePrice = source.readDouble();       
			searchImages.orderDate = source.readString();          
			searchImages.imagePath = source.readString();          
			                    
			searchImages.currency = source.readString();           
			searchImages.customerCode = source.readString();       
			searchImages.customerCountry = source.readString();    
			searchImages.customerName = source.readString();       
			searchImages.lastArrivalQuantity = source.readInt();
			searchImages.lastOrderDate = source.readString();      
			searchImages.lastPurchaseDate = source.readString();   
			searchImages.lastSellDate = source.readString();       
			searchImages.markUpValue  = source.readFloat();        
			searchImages.perPiecePrice = source.readInt() ;      
			searchImages.creditPrice = source.readInt();        
			searchImages.stockAvailable = source.readInt();     
			searchImages.wholesalePrice = source.readDouble();
			searchImages.barcode = source.readString();
			
			return searchImages; 
		} 
		public SearchImages[] newArray(int size) { 
			return new SearchImages[size]; 
		} 
	};
	
	public void save(Context context) {
		StockInformationDAO stockInformationDAO = null;
		try {
			stockInformationDAO = new StockInformationDAO(context, this);
			
			if (this.rowId == Constants.INVALID_ID) {
				stockInformationDAO.save();
			} else {
				stockInformationDAO.update();
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

}
