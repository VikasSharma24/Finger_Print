package com.alq.model.dao;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;

public abstract class BaseDAO {
	private Context context;
	 
	public BaseDAO() {};
	
	public BaseDAO(Context context) {
		this.context = context;
	}
	
	public abstract void save();
	public abstract void update();
	public abstract boolean delete();
	
	public ContentResolver getContentResolver() {
		return context.getContentResolver();
	}
	
	public Context getContext() {
		return this.context;
	}
	
	public static class QueryBuilder implements QueryParams {

		private String selection;
		private String[] selectionArgs;
		private String[] projection;
		private String sortOrder;
		
		private Context context;
		
		public QueryBuilder(Context context) {
			this.context = context;
		}
		
		@Override
		public void withSelection(String selection) {
			this.selection = selection;
		}

		@Override
		public void withSelectionArg(String[] selectionArgs) {
			this.selectionArgs = selectionArgs;
		}

		@Override
		public void withProjection(String[] projection) {
			this.projection = projection;
		}

		@Override
		public void withSortOrder(String sortOrder) {
			this.sortOrder = sortOrder;
		}

		@Override
		public Cursor query(Uri uri) {
			if (context == null) {
				throw new IllegalArgumentException("Invalid context");
			}
			
			return context.getContentResolver().query(uri, projection, selection, selectionArgs, sortOrder);
		}
	}
	
	private interface QueryParams {
		
		void withSelection(String selection);
		void withSelectionArg(String[] selectionArgs);
		void withProjection(String[] projection);
		void withSortOrder(String sortOrder);
		Cursor query(Uri uri);
	}
}
