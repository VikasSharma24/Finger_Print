package com.alq.model.dao;

import java.security.InvalidParameterException;

import org.json.JSONObject;

import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;

import com.alq.constant.Constants;
import com.alq.database.Tables.CustomerInformationTable;
import com.alq.database.Tables.ItemTable;
import com.alq.model.CustomerInfo;

public class CustomerInformationDAO extends BaseDAO {

	private CustomerInfo customerInfo;

	@SuppressWarnings("unused")
	private CustomerInformationDAO() {};

	public CustomerInformationDAO(Context context, CustomerInfo customerInfo) {
		super(context);
		this.customerInfo = customerInfo;
	}

	public JSONObject createJSONObject() {
		JSONObject jsonObject = new JSONObject();
		return jsonObject;
	}


	@Override
	public void save() {
		if (customerInfo == null) {
			return;
		}

		Uri uri = getContentResolver().insert(CustomerInformationTable.CONTENT_URI, getContentValues());

		if (uri != null) {
			customerInfo.setRowId(ContentUris.parseId(uri));
		}
	}

	@Override
	public void update() {
		if (customerInfo == null) {
			return;
		}

		if (customerInfo.getCustomerCode() == null) {
			return;
		}

		getContentResolver().update(CustomerInformationTable.CONTENT_URI, getContentValues(), CustomerInformationTable.COLUMN_CUSTOMER_CODE + " =?", new String[]{customerInfo.getCustomerCode()});
	}

	@Override
	public boolean delete() {
		return false;
	}

	public ContentValues getContentValues() {
		ContentValues values = new ContentValues();

		values.put(CustomerInformationTable.COLUMN_CUSTOMER_CODE, customerInfo.getCustomerCode());
		values.put(CustomerInformationTable.COLUMN_CUSTOMER_NAME, customerInfo.getCustomerName());
		values.put(CustomerInformationTable.COLUMN_COUNTRY, customerInfo.getCustomerCountry());
		values.put(CustomerInformationTable.COLUMN_MARK_UP_VALUE, customerInfo.getMarkUpValue());
		return values;
	}
	
	public static CustomerInfo getStoredCustomerInfo(Context context, String custCode) {
		if (context == null) {
			throw new IllegalArgumentException("Context argumnent is null");
		}

		if (custCode == null) {
			return null;
		}

		if (custCode.equals(Constants.INVALID_ID)) {
			throw new InvalidParameterException("Invalid customer code ");
		}

		QueryBuilder queryBuilder = new QueryBuilder(context);
		queryBuilder.withSelection( CustomerInformationTable.COLUMN_CUSTOMER_CODE + " =?");
		queryBuilder.withSelectionArg(new String[] {custCode});

		Cursor cursor = queryBuilder.query(CustomerInformationTable.CONTENT_URI);
		return bindData(cursor);
	}

	private static CustomerInfo bindData(Cursor cursor) {
		CustomerInfo customerInfo = null;

		if (cursor != null && cursor.moveToFirst()) {
			customerInfo = getCustomerInformationFromCursor(cursor);

			cursor.close();
		}

		return customerInfo;
	}

	private static CustomerInfo getCustomerInformationFromCursor(Cursor cursor) {
		CustomerInfo customerInfo = new  CustomerInfo();
		
		customerInfo.setRowId(cursor.getLong(cursor.getColumnIndex(CustomerInformationTable.COLUMN_ID)));
		customerInfo.setCustomerCode(cursor.getString(cursor.getColumnIndex(CustomerInformationTable.COLUMN_CUSTOMER_CODE)));
		
		customerInfo.setCustomerName(cursor.getString(cursor.getColumnIndex(CustomerInformationTable.COLUMN_CUSTOMER_NAME)));
		customerInfo.setCustomerCountry(cursor.getString(cursor.getColumnIndex(CustomerInformationTable.COLUMN_COUNTRY)));
		customerInfo.setMarkUpValue(cursor.getFloat(cursor.getColumnIndex(CustomerInformationTable.COLUMN_MARK_UP_VALUE)));
		
		return customerInfo;
	}


}
