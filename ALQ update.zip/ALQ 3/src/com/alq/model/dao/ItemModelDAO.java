package com.alq.model.dao;

import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.Date;

import org.json.JSONException;
import org.json.JSONObject;

import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.text.TextUtils;

import com.alq.constant.Constants;
import com.alq.database.Tables.ItemTable;
import com.alq.model.ItemModel;
import com.alq.utils.Utility;

public class ItemModelDAO extends BaseDAO {

	private ItemModel itemModel;

	@SuppressWarnings("unused")
	private ItemModelDAO() {};

	public ItemModelDAO(Context context, ItemModel itemModel) {
		super(context);
		this.itemModel = itemModel;
	}

	public JSONObject createJSONObject() {
		JSONObject jsonObject = new JSONObject();

		return jsonObject;
	}


	@Override
	public void save() {
		if (itemModel == null) {
			return;
		}

		//itemModel.setLastUpdatedDate(Utility.getCurTime());
		Uri uri = getContentResolver().insert(ItemTable.CONTENT_URI, getContentValues());

		if (uri != null) {
			itemModel.setRowID(ContentUris.parseId(uri));
		}
	}

	@Override
	public void update() {
		if (itemModel == null) {
			return;
		}

		if (itemModel.getItemID() == null) {
			return;
		}

		getContentResolver().update(ItemTable.CONTENT_URI, getContentValues(), ItemTable.COLUMN_ITEM_ID + " =?", new String[]{itemModel.getItemID()});
	}

	@Override
	public boolean delete() {
		return false;
	}

	public ContentValues getContentValues() {
		ContentValues values = new ContentValues();

		values.put(ItemTable.COLUMN_ITEM_ID, itemModel.getItemID());
		values.put(ItemTable.COLUMN_ART, itemModel.getArt());
		values.put(ItemTable.COLUMN_DESCRiPTION, itemModel.getDescription());
		values.put(ItemTable.COLUMN_BOOTH_NO, itemModel.getCtn());
		values.put(ItemTable.COLUMN_PKG, itemModel.getPkg());
		values.put(ItemTable.COLUMN_ORDER_DATE, itemModel.getOrderDate());
		values.put(ItemTable.COLUMN_BRAND, itemModel.getBrand());
		values.put(ItemTable.COLUMN_COLOUR, itemModel.getColour());
		values.put(ItemTable.COLUMN_SIZE, itemModel.getSize());
		values.put(ItemTable.COLUMN_WEIGHT, itemModel.getWeight());
		values.put(ItemTable.COLUMN_MEASUREMENT, itemModel.getMeasurement());
		values.put(ItemTable.COLUMN_ORIGIN, itemModel.getOrigin());
		values.put(ItemTable.COLUMN_CURRENCY, itemModel.getCurrency());
		
		values.put(ItemTable.COLUMN_PRICE, itemModel.getPrice());
		values.put(ItemTable.COLUMN_ITEM_PHOTO_PATH, itemModel.getItemImagePath());
		values.put(ItemTable.COLUMN_ITEM_PHOTO_URL, itemModel.getItemPhotoUrl());
		values.put(ItemTable.COLUMN_ITEM_PHOTO_FILE_NAME, itemModel.getItemPhotofileName());
		values.put(ItemTable.COLUMN_LAST_UPDATE_DATE, itemModel.getLastUpdatedDate());
		values.put(ItemTable.COLUMN_ITEM_DELIVERY_DATE, itemModel.getItemDeliveryDate());
		
		values.put(ItemTable.COLUMN_BARCODE_NO, itemModel.getBarcodeNo());
		values.put(ItemTable.COLUMN_PIECE_PER_CARTOON, itemModel.getPiecePer());
		values.put(ItemTable.COLUMN_ORDERED_QTY, itemModel.getOrderedQty());

		return values;
	}

	public static ItemModel getStoredItem(Context context, String itemID) {
		if (context == null) {
			throw new IllegalArgumentException("Context argumnent is null");
		}

		if (itemID == null) {
			return null;
		}

		if (itemID.equals(Constants.INVALID_ID)) {
			throw new InvalidParameterException("Invalid itemId ");
		}

		QueryBuilder queryBuilder = new QueryBuilder(context);
		queryBuilder.withSelection( ItemTable.COLUMN_ITEM_ID + " =?");
		queryBuilder.withSelectionArg(new String[] {itemID});

		Cursor cursor = queryBuilder.query(ItemTable.CONTENT_URI);
		return bindData(cursor);
	}

	private static ItemModel bindData(Cursor cursor) {
		ItemModel itemModel = null;

		if (cursor != null && cursor.moveToFirst()) {
			itemModel = getItemModelFromCursor(cursor);

			cursor.close();
		}

		return itemModel;
	}

	public static ItemModel getItemModelFromCursor(Cursor cursor) {
		ItemModel itemModel = new ItemModel();

		itemModel.setRowID(cursor.getLong(cursor.getColumnIndex(ItemTable.COLUMN_ID)));
		itemModel.setItemID(cursor.getString(cursor.getColumnIndex(ItemTable.COLUMN_ITEM_ID)));
		itemModel.setArt(cursor.getString(cursor.getColumnIndex(ItemTable.COLUMN_ART)));
		itemModel.setDescription(cursor.getString(cursor.getColumnIndex(ItemTable.COLUMN_DESCRiPTION)));
		itemModel.setCtn(cursor.getString(cursor.getColumnIndex(ItemTable.COLUMN_BOOTH_NO)));
		itemModel.setPkg(cursor.getString(cursor.getColumnIndex(ItemTable.COLUMN_PKG)));
		
		itemModel.setOrderDate(cursor.getString(cursor.getColumnIndex(ItemTable.COLUMN_ORDER_DATE)));
		itemModel.setBrand(cursor.getString(cursor.getColumnIndex(ItemTable.COLUMN_BRAND)));
		itemModel.setColour(cursor.getString(cursor.getColumnIndex(ItemTable.COLUMN_COLOUR)));
		itemModel.setSize(cursor.getString(cursor.getColumnIndex(ItemTable.COLUMN_SIZE)));
		itemModel.setWeight(cursor.getString(cursor.getColumnIndex(ItemTable.COLUMN_WEIGHT)));
		itemModel.setMeasurement(cursor.getString(cursor.getColumnIndex(ItemTable.COLUMN_MEASUREMENT)));
		itemModel.setOrigin(cursor.getString(cursor.getColumnIndex(ItemTable.COLUMN_ORIGIN)));
		itemModel.setCurrency(cursor.getString(cursor.getColumnIndex(ItemTable.COLUMN_CURRENCY)));
		
		itemModel.setPrice(cursor.getInt(cursor.getColumnIndex(ItemTable.COLUMN_PRICE)));
		itemModel.setItemImagePath(cursor.getString(cursor.getColumnIndex(ItemTable.COLUMN_ITEM_PHOTO_PATH)));
		itemModel.setItemPhotoUrl(cursor.getString(cursor.getColumnIndex(ItemTable.COLUMN_ITEM_PHOTO_URL)));
		itemModel.setItemPhotoFileName(cursor.getString(cursor.getColumnIndex(ItemTable.COLUMN_ITEM_PHOTO_FILE_NAME)));

		itemModel.setCreateDate(cursor.getLong(cursor.getColumnIndex(ItemTable.COLUMN_CREATE_DATE)));
		itemModel.setLastUpdatedDate(cursor.getLong(cursor.getColumnIndex(ItemTable.COLUMN_LAST_UPDATE_DATE)));
		itemModel.setItemSyncDate(cursor.getLong(cursor.getColumnIndex(ItemTable.COLUMN_ITEM_SYNC_DATE)));
		
		itemModel.setBarcodeNo(cursor.getString(cursor.getColumnIndex(ItemTable.COLUMN_BARCODE_NO)));
		itemModel.setPiecePer(cursor.getInt(cursor.getColumnIndex(ItemTable.COLUMN_PIECE_PER_CARTOON)));
		itemModel.setOrderedQty(cursor.getInt(cursor.getColumnIndex(ItemTable.COLUMN_ORDERED_QTY)));

		return itemModel;
	}

	
	/*
	 * {"stockInformationResult":{"finalCustomerList":{"articleNo":"OK8118","boothNo":"2F-36175-7-1","brand":"INTEX","colour":"GREY","creditPrice":480,"currency":"RMB","customerCode":"001007","customerCountry":"Male","customerName":"Shokran Mr.","description":"LEATHER SHOE POLISH 2-SECTION","imagePath":"E:\/AnandData\/SearchApp_Data_code\/Images\/0210022.png","itemCode":"0210022","lastArrivalQuantity":10,"lastOrderDate":"15-Dec-14","lastPurchaseDate":"01-May-13","lastSellDate":"24-Nov-14","markUpValue":1,"measurement":"3.42 CUF","orderDate":"15-Dec-14","origin":"CHINA","packing":"1*20BOX*12PCS","perPiecePrice":2,"puchasePrice":1.6,"size":"11X45X60","stockAvailable":5,"weight":"13.5 KG.","wholesalePrice":384.01},"reason":"OK","status":"success"}}
	 */
	public static ItemModel geItemDataFromJSON(Context context, JSONObject jsonObject) throws JSONException {

		String itemCode = (String) Utility.getJsonObjectValue(jsonObject, "ItemCode");
		
		if (itemCode == null) return null;
		
		ItemModel itemModel = getStoredItem(context, itemCode);

		if (itemModel == null) {
			itemModel = new ItemModel();
		}

		itemModel.setItemID((String) Utility.getJsonObjectValue(jsonObject, "itemCode"));
		itemModel.setDescription((String) Utility.getJsonObjectValue(jsonObject, "description"));
		itemModel.setArt((String) Utility.getJsonObjectValue(jsonObject, "articleNo"));
		itemModel.setCtn((String) Utility.getJsonObjectValue(jsonObject, "boothNo"));
		itemModel.setPkg((String) Utility.getJsonObjectValue(jsonObject, "packing"));
		
		String orderDate = (String) Utility.getJsonObjectValue(jsonObject, "orderDate");
		java.text.DateFormat dateFormat = Utility.getPreferedDateFormat(context);
		
		Date date = Utility.convertStringDateToDateFormat(orderDate, Constants.LOCAL_DATE_PATTERN);
		String dateString = dateFormat.format(date);
		
		itemModel.setOrderDate(dateString);
		itemModel.setBrand((String) Utility.getJsonObjectValue(jsonObject, "brand"));
		itemModel.setColour((String) Utility.getJsonObjectValue(jsonObject, "colour"));
		itemModel.setSize((String) Utility.getJsonObjectValue(jsonObject,"size"));
		itemModel.setWeight((String) Utility.getJsonObjectValue(jsonObject, "weight"));
		itemModel.setMeasurement((String) Utility.getJsonObjectValue(jsonObject, "measurement"));
		itemModel.setOrigin((String) Utility.getJsonObjectValue(jsonObject, "origin"));
		itemModel.setCurrency((String) Utility.getJsonObjectValue(jsonObject, "currency"));
		itemModel.setPrice(jsonObject.getDouble("purchasePrice"));
		
		itemModel.setItemPhotoUrl((String) Utility.getJsonObjectValue(jsonObject, "imagePath"));

		return itemModel;
	}
	
	public static void parseSaveImageResponse(Context context, String responseString) {
		try {
			if (responseString == null)
				return;
			JSONObject jsonObject = new JSONObject(responseString);

			JSONObject uploadImageResult = (JSONObject) Utility
					.getJsonObjectValue(jsonObject, "uploadImageResult");

			if (uploadImageResult == null) {
				return;
			}

			String reason = (String) Utility.getJsonObjectValue(jsonObject,
					"reason");
			String status = (String) Utility.getJsonObjectValue(jsonObject,
					"status");

			if ("OK".equals(reason) && "success".equals(status)) {
				JSONObject uploadImage = (JSONObject) Utility
						.getJsonObjectValue(jsonObject, "uploadImage");
				String uploadImageDate = (String) Utility.getJsonObjectValue(
						uploadImage, "uploadImageDate");
				String uploadImageName = (String) Utility.getJsonObjectValue(
						uploadImage, "uploadImageName");
				String uploadImagePath = (String) Utility.getJsonObjectValue(
						uploadImage, "uploadImagePath");

				String itemId = uploadImageName.substring(0,
						uploadImageName.indexOf("."));

				if (TextUtils.isEmpty(itemId)) {
					return;
				}

				ItemModel itemModel = ItemModelDAO.getStoredItem(context, itemId);

				if (itemModel != null) {
					Date updateDate = Utility.convertStringDateToDateFormat(
							uploadImageDate, Constants.LOCAL_DATE_PATTERN);

					itemModel.setLastUpdatedDate(updateDate == null ? 0
							: updateDate.getTime());
					itemModel.setItemPhotoUrl(uploadImagePath);
					itemModel.setItemPhotoFileName(uploadImageName);

					itemModel.save(context);
				}
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}
	
	public static ArrayList<ItemModel> getPendingItemImages(Context context) {
		ArrayList<ItemModel> itemList = new ArrayList<ItemModel>();
		
		QueryBuilder queryBuilder = new QueryBuilder(context);
		queryBuilder.withSelection(ItemTable.COLUMN_LAST_UPDATE_DATE + " =?");
		queryBuilder.withSelectionArg(new String[] {String.valueOf(0)});
		
		Cursor cursor = queryBuilder.query(ItemTable.CONTENT_URI);
		
		if (cursor != null && cursor.moveToFirst()) {
			do {
				ItemModel itemModel = getItemModelFromCursor(cursor);
				if (itemModel != null) {
					itemList.add(itemModel);
				}
				
			} while (cursor.moveToNext());
			
			cursor.close();
		}
		
		return itemList;
	}
	
}
