package com.alq.model.dao;

import java.security.InvalidParameterException;

import org.json.JSONObject;

import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;

import com.alq.constant.Constants;
import com.alq.database.Tables.StockInformationTable;
import com.alq.model.SearchImages;
import com.alq.utils.Utility;

public class StockInformationDAO extends BaseDAO {

	private SearchImages searchImages;

	@SuppressWarnings("unused")
	private StockInformationDAO() {};

	public StockInformationDAO(Context context, SearchImages searchImages) {
		super(context);
		this.searchImages = searchImages;
	}

	public JSONObject createJSONObject() {
		JSONObject jsonObject = new JSONObject();
		return jsonObject;
	}


	@Override
	public void save() {
		if (searchImages == null) {
			return;
		}

		Uri uri = getContentResolver().insert(StockInformationTable.CONTENT_URI, getContentValues());

		if (uri != null) {
			searchImages.setRowId(ContentUris.parseId(uri));
		}
	}

	@Override
	public void update() {
		if (searchImages == null) {
			return;
		}

		if (searchImages.getItemCode() == null) {
			return;
		}

		getContentResolver().update(StockInformationTable.CONTENT_URI, getContentValues(), StockInformationTable.COLUMN_ITEM_ID + " =?", new String[]{searchImages.getItemCode()});
	}

	@Override
	public boolean delete() {
		return false;
	}

	public ContentValues getContentValues() {
		ContentValues values = new ContentValues();

		values.put(StockInformationTable.COLUMN_ITEM_ID, searchImages.getItemCode());
		values.put(StockInformationTable.COLUMN_ARTICLE_NO, searchImages.getArticleNo());
		values.put(StockInformationTable.COLUMN_DESCRIPTION, searchImages.getDescription());
		values.put(StockInformationTable.COLUMN_BOOTH_NO, searchImages.getBoothNo());
		values.put(StockInformationTable.COLUMN_PACKING, searchImages.getPacking());

		values.put(StockInformationTable.COLUMN_BRAND, searchImages.getBrand());
		values.put(StockInformationTable.COLUMN_COLOUR, searchImages.getColour());
		values.put(StockInformationTable.COLUMN_SIZE, searchImages.getSize());
		values.put(StockInformationTable.COLUMN_WEIGHT, searchImages.getWeight());
		values.put(StockInformationTable.COLUMN_MEASUREMENT, searchImages.getMeasurement());
		values.put(StockInformationTable.COLUMN_ORIGIN, searchImages.getOrigin());
		values.put(StockInformationTable.COLUMN_ORDER_DATE, searchImages.getOrderDate());
		values.put(StockInformationTable.COLUMN_CURRENCY, searchImages.getCurrency());

		values.put(StockInformationTable.COLUMN_PURCHASE_PRICE, String.valueOf(searchImages.getPuchasePrice()));
		values.put(StockInformationTable.COLUMN_IMAGE_PATH, searchImages.getImagePath());
		values.put(StockInformationTable.COLUMN_CUSTOMER_CODE, searchImages.getCustomerCode());
		values.put(StockInformationTable.COLUMN_CUSTOMER_NAME, searchImages.getCustomerName());
		values.put(StockInformationTable.COLUMN_CUSTOMER_COUNTRY, searchImages.getCustomerCountry());
		values.put(StockInformationTable.COLUMN_LAST_ARRIAVAL_QUANTITY, String.valueOf(searchImages.getLastArrivalQuantity()));
		values.put(StockInformationTable.COLUMN_LAST_ORDER_DATE, searchImages.getOrderDate());
		values.put(StockInformationTable.COLUMN_LAST_PURCHASE_DATE, searchImages.getLastPurchaseDate());
		values.put(StockInformationTable.COLUMN_LAST_SELL_DATE, searchImages.getLastSellDate());

		values.put(StockInformationTable.COLUMN_MARK_UP_VALUE, String.valueOf(searchImages.getMarkUpValue()));
		values.put(StockInformationTable.COLUMN_PER_PIECE_PRICE, String.valueOf(searchImages.getPerPiecePrice()));
		values.put(StockInformationTable.COLUMN_CREDIT_PRICE, String.valueOf(searchImages.getCreditPrice()));
		values.put(StockInformationTable.COLUMN_STOCK_AVAILABLE, String.valueOf(searchImages.getStockAvailable()));
		values.put(StockInformationTable.COLUMN_WHOLE_SALE_PRICE, String.valueOf(searchImages.getWholesalePrice()));

		values.put(StockInformationTable.COLUMN_BARCODE, searchImages.getBarcode());

		return values;
	}

	public static SearchImages getStoredStockInfo(Context context, String itemID) {
		if (context == null) {
			throw new IllegalArgumentException("Context argumnent is null");
		}

		if (itemID == null) {
			return null;
		}

		if (itemID.equals(Constants.INVALID_ID)) {
			throw new InvalidParameterException("Invalid itemId ");
		}

		QueryBuilder queryBuilder = new QueryBuilder(context);
		queryBuilder.withSelection( StockInformationTable.COLUMN_ITEM_ID + " =?");
		queryBuilder.withSelectionArg(new String[] {itemID});

		Cursor cursor = queryBuilder.query(StockInformationTable.CONTENT_URI);
		return bindData(cursor);
	}

	public static SearchImages getStoredStockInfo(Context context, long rowId) {
		if (context == null) {
			throw new IllegalArgumentException("Context argumnent is null");
		}

		QueryBuilder queryBuilder = new QueryBuilder(context);
		queryBuilder.withSelection( StockInformationTable.COLUMN_ID + " =?");
		queryBuilder.withSelectionArg(new String[] {String.valueOf(rowId)});

		Cursor cursor = queryBuilder.query(StockInformationTable.CONTENT_URI);
		return bindData(cursor);
	}

	private static SearchImages bindData(Cursor cursor) {
		SearchImages searchImages = null;
		try {
			if (cursor != null && cursor.moveToFirst()) {
				searchImages = getStockInformationFromCursor(cursor);

				cursor.close();
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return searchImages;
	}

	public static SearchImages getStockInformationFromCursor(Cursor cursor) {
		SearchImages searchImages = new  SearchImages();

		searchImages.setRowId(cursor.getLong(cursor.getColumnIndex(StockInformationTable.COLUMN_ID)));
		searchImages.setItemCode(cursor.getString(cursor.getColumnIndex(StockInformationTable.COLUMN_ITEM_ID)));

		searchImages.setArticleNo(cursor.getString(cursor.getColumnIndex(StockInformationTable.COLUMN_ARTICLE_NO)));
		searchImages.setDescription(cursor.getString(cursor.getColumnIndex(StockInformationTable.COLUMN_DESCRIPTION)));
		searchImages.setBoothNo(cursor.getString(cursor.getColumnIndex(StockInformationTable.COLUMN_BOOTH_NO)));
		searchImages.setPacking(cursor.getString(cursor.getColumnIndex(StockInformationTable.COLUMN_PACKING)));
		searchImages.setBrand(cursor.getString(cursor.getColumnIndex(StockInformationTable.COLUMN_BRAND)));
		searchImages.setColour(cursor.getString(cursor.getColumnIndex(StockInformationTable.COLUMN_COLOUR)));
		searchImages.setWeight(cursor.getString(cursor.getColumnIndex(StockInformationTable.COLUMN_WEIGHT)));
		searchImages.setMeasurement(cursor.getString(cursor.getColumnIndex(StockInformationTable.COLUMN_MEASUREMENT)));
		searchImages.setOrigin(cursor.getString(cursor.getColumnIndex(StockInformationTable.COLUMN_ORIGIN)));

		searchImages.setSize(cursor.getString(cursor.getColumnIndex(StockInformationTable.COLUMN_SIZE)));
		searchImages.setOrderDate(cursor.getString(cursor.getColumnIndex(StockInformationTable.COLUMN_ORDER_DATE)));
		String purchasePrice = cursor.getString(cursor.getColumnIndex(StockInformationTable.COLUMN_PURCHASE_PRICE));

		searchImages.setPuchasePrice(Double.parseDouble(Utility.isEmpty(purchasePrice)? "0": purchasePrice));
		searchImages.setImagePath(cursor.getString(cursor.getColumnIndex(StockInformationTable.COLUMN_IMAGE_PATH)));
		searchImages.setCurrency(cursor.getString(cursor.getColumnIndex(StockInformationTable.COLUMN_CURRENCY)));

		searchImages.setCustomerCode(cursor.getString(cursor.getColumnIndex(StockInformationTable.COLUMN_CUSTOMER_CODE)));
		searchImages.setCustomerName(cursor.getString(cursor.getColumnIndex(StockInformationTable.COLUMN_CUSTOMER_NAME)));
		searchImages.setCustomerCountry(cursor.getString(cursor.getColumnIndex(StockInformationTable.COLUMN_CUSTOMER_COUNTRY)));
		searchImages.setLastArrivalQuantity(Integer.parseInt(cursor.getString(cursor.getColumnIndex(StockInformationTable.COLUMN_LAST_ARRIAVAL_QUANTITY))));
		searchImages.setLastOrderDate(cursor.getString(cursor.getColumnIndex(StockInformationTable.COLUMN_LAST_ORDER_DATE)));
		searchImages.setLastPurchaseDate(cursor.getString(cursor.getColumnIndex(StockInformationTable.COLUMN_LAST_PURCHASE_DATE)));
		searchImages.setLastSellDate(cursor.getString(cursor.getColumnIndex(StockInformationTable.COLUMN_LAST_SELL_DATE)));

		String markupValue = cursor.getString(cursor.getColumnIndex(StockInformationTable.COLUMN_MARK_UP_VALUE));
		String perPieccePrice = cursor.getString(cursor.getColumnIndex(StockInformationTable.COLUMN_PER_PIECE_PRICE));
		String creditPrice = cursor.getString(cursor.getColumnIndex(StockInformationTable.COLUMN_CREDIT_PRICE));
		String stockAvailable = cursor.getString(cursor.getColumnIndex(StockInformationTable.COLUMN_STOCK_AVAILABLE));
		String wholeSalePrice = cursor.getString(cursor.getColumnIndex(StockInformationTable.COLUMN_WHOLE_SALE_PRICE));

		searchImages.setMarkUpValue(Float.parseFloat(Utility.isEmpty(markupValue)? "0" : markupValue));
		searchImages.setPerPiecePrice(Integer.parseInt(Utility.isEmpty(perPieccePrice)? "0" : perPieccePrice));
		searchImages.setCreditPrice(Integer.parseInt(Utility.isEmpty(creditPrice)? "0" : creditPrice));
		searchImages.setStockAvailable(Integer.parseInt(Utility.isEmpty(stockAvailable)? "0" : stockAvailable));
		searchImages.setWholesalePrice(Double.parseDouble(Utility.isEmpty(wholeSalePrice)? "0" : wholeSalePrice));

		searchImages.setBarcode(cursor.getString(cursor.getColumnIndex(StockInformationTable.COLUMN_BARCODE)));

		return searchImages;
	}


}
