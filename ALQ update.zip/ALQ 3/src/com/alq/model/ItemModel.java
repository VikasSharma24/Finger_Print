package com.alq.model;

import android.content.Context;

import com.alq.constant.Constants;
import com.alq.model.dao.ItemModelDAO;

public class ItemModel {

	private long rowID;
	private String itemID;
	private String art;
	private String description;
	private String ctn;
	private String pkg;
	private String brand;
	private String colour;
	private String weight;
	private String measurement;
	private String origin;
	private String currency;
	private String barcodeNo;
	private int piecePer;
	private int orderedQty;
	
	
	private String size;
	private double price;
	private String itemPhotoPath;
	private String itemPhotoUrl;
	private String itemPhotoFileName;
	private String orderDate;
	private long createDate;
	private long lastUpdatedDate;
	private long itemSyncDate;
	private long itemDeliveryDate;

	public ItemModel() {
		this.rowID = Constants.INVALID_ID;
	}

	public long getRowID() {
		return rowID;
	}
	
	public void setRowID(long rowID) {
		this.rowID = rowID;
	}
	
	public String getItemID() {
		return itemID;
	}
	
	public void setItemID(String itemID) {
		this.itemID = itemID;
	}
	
	public String getArt() {
		return art;
	}
	
	public void setArt(String art) {
		this.art = art;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getCtn() {
		return ctn;
	}
	
	public void setCtn(String ctn) {
		this.ctn = ctn;
	}
	
	public String getPkg() {
		return pkg;
	}
	
	public void setPkg(String pkg) {
		this.pkg = pkg;
	}
	
	
	public double getPrice() {
		return price;
	}
	
	public void setPrice(double price) {
		this.price = price;
	}
	
	public String getItemImagePath() {
		return itemPhotoPath;
	}
	
	public void setItemImagePath(String itemPhotoPath) {
		this.itemPhotoPath = itemPhotoPath;
	}
	
	public long getLastUpdatedDate() {
		return lastUpdatedDate;
	}
	
	public void setLastUpdatedDate(long lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}
	
	public long getItemSyncDate() {
		return itemSyncDate;
	}
	
	public void setItemSyncDate(long itemSyncDate) {
		this.itemSyncDate = itemSyncDate;
	}
	
	public long getItemDeliveryDate() {
		return itemDeliveryDate;
	}
	
	public void setItemDeliveryDate(long itemDeliveryDate) {
		this.itemDeliveryDate = itemDeliveryDate;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getColour() {
		return colour;
	}

	public void setColour(String colour) {
		this.colour = colour;
	}

	public String getWeight() {
		return weight;
	}

	public void setWeight(String weight) {
		this.weight = weight;
	}

	public String getMeasurement() {
		return measurement;
	}

	public void setMeasurement(String measurement) {
		this.measurement = measurement;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}
	
	public long getCreateDate() {
		return createDate;
	}

	public void setCreateDate(long createDate) {
		this.createDate = createDate;
	}
	
	public String getItemPhotoUrl() {
		return itemPhotoUrl;
	}

	public void setItemPhotoUrl(String itemPhotoUrl) {
		this.itemPhotoUrl = itemPhotoUrl;
	}

	public String getItemPhotoPath() {
		return itemPhotoPath;
	}

	public void setItemPhotoPath(String itemPhotoPath) {
		this.itemPhotoPath = itemPhotoPath;
	}

	public String getItemPhotofileName() {
		return itemPhotoFileName;
	}

	public void setItemPhotoFileName(String itemPhotofileName) {
		this.itemPhotoFileName = itemPhotofileName;
	}

	public String getBarcodeNo() {
		return barcodeNo;
	}

	public void setBarcodeNo(String barcodeNo) {
		this.barcodeNo = barcodeNo;
	}

	public int getPiecePer() {
		return piecePer;
	}

	public void setPiecePer(int piecePer) {
		this.piecePer = piecePer;
	}

	public int getOrderedQty() {
		return orderedQty;
	}

	public void setOrderedQty(int orderedQty) {
		this.orderedQty = orderedQty;
	}

	public void save(Context context) {
		ItemModelDAO itemModelDAO = null;
		try {
			itemModelDAO = new ItemModelDAO(context, this);
			
			if (this.rowID == Constants.INVALID_ID) {
				itemModelDAO.save();
			} else {
				itemModelDAO.update();
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public boolean delete() {
		return false;
	}
}
