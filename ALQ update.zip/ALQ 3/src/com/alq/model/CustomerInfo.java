package com.alq.model;

import java.util.ArrayList;

import android.content.ContentProviderOperation;
import android.content.ContentValues;
import android.content.Context;
import android.content.OperationApplicationException;
import android.os.RemoteException;

import com.alq.constant.Constants;
import com.alq.database.ALQContentProvider;
import com.alq.database.DatabaseHelper;
import com.alq.database.Tables.CustomerInformationTable;
import com.alq.model.dao.CustomerInformationDAO;

public class CustomerInfo {

	private long rowId;
	private String customerCode;
	private String customerName;
	private String customerCountry;
	private float markUpValue;

	public CustomerInfo() {
		this.rowId = Constants.INVALID_ID;
	}

	public long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	public String getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerCountry() {
		return customerCountry;
	}
	public void setCustomerCountry(String customerCountry) {
		this.customerCountry = customerCountry;
	}

	public float getMarkUpValue() {
		return markUpValue;
	}

	public void setMarkUpValue(float markUpValue) {
		this.markUpValue = markUpValue;
	}

	public void save(Context context) {
		CustomerInformationDAO customerInformationDAO = null;
		try {
			customerInformationDAO = new CustomerInformationDAO(context, this);

			if (this.rowId == Constants.INVALID_ID) {
				customerInformationDAO.save();
			} else {
				customerInformationDAO.update();
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public ContentProviderOperation addContentProviderOpr(Context context) {
		CustomerInformationDAO customerInformationDAO = null;
		try {
			customerInformationDAO = new CustomerInformationDAO(context, this);

			if (this.rowId == Constants.INVALID_ID) {
				return insert(customerInformationDAO.getContentValues());
			} else {
				return update(customerInformationDAO.getContentValues());
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
		return null;
	}
	

	public ContentProviderOperation insert(ContentValues values) {
		return ContentProviderOperation.newInsert(CustomerInformationTable.CONTENT_URI)
				.withValues(values)
				.build();
	}	
	
	public ContentProviderOperation update(ContentValues values) {
		return ContentProviderOperation.newUpdate(CustomerInformationTable.CONTENT_URI)
				.withSelection(CustomerInformationTable.COLUMN_CUSTOMER_CODE + " =?", new String[]{getCustomerCode()})
				.withValues(values)
				.build();
	}
	
	public static void applyBatch(Context context, ArrayList<ContentProviderOperation> oprs) {
		try {
			if (oprs == null || oprs.isEmpty()) return;
			context.getContentResolver().applyBatch(ALQContentProvider.AUTHORITY, oprs);
		} catch (RemoteException e) {
			e.printStackTrace();
		} catch (OperationApplicationException e) {
			e.printStackTrace();
		}
	}
}
