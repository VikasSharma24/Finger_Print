package com.alq.services;

import java.io.InputStream;
import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import android.util.Log;

import com.alq.utils.Utility;


public class ServiceParser {

	public static String TAG = "ServiceParser";

	public static Element getDocumentElement(String result) {	
        try {
		// This is not the correct resolution this should be fixed at server end.
		if(result != null)result = result.replaceAll("<>", "&lt;&gt;");	
		InputStream streamToParse = Utility.stringToInputStream(result);
		if(streamToParse == null) return null;					
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();		
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document dom = builder.parse(streamToParse);
			Element root = dom.getDocumentElement();	
			return root;
		} catch(Exception e) {
			Log.e(TAG, "getDocumentElement()" + e.getMessage());
			return null;
		}	
	}

	public static String nodeToString(Node node) {
		StringWriter sw = new StringWriter();
		try {
			Transformer t = TransformerFactory.newInstance().newTransformer();
			t.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
			t.transform(new DOMSource(node), new StreamResult(sw));
		} catch (TransformerException te) {
			System.out.println("nodeToString Transformer Exception");
		}
		return sw.toString();
	}
}
