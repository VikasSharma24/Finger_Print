package com.alq.services;

import org.w3c.dom.Element;

import android.text.TextUtils;

/**
 * Class contains service response details
 * for activity
 */
public class ServiceResponse {

	// class members
	private String errorMsg;
	private int serviceRequestTag;
	private String responseString;

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public int getServiceRequestTag() {
		return serviceRequestTag;
	}

	public void setServiceRequestTag(int serviceRequestTag) {
		this.serviceRequestTag = serviceRequestTag;
	}
	public String getResponseString() {
		return responseString;
	}

	public void setResponseString(String responseString) {
		this.responseString = responseString;
	}

	public Element getElement() {
		
		Element element = null;
		if(!TextUtils.isEmpty(responseString)) {
			element = ServiceParser.getDocumentElement(responseString);
		} 
		return element;
	}

	

}
