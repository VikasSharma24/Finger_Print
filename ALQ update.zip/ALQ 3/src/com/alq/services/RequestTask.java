package com.alq.services;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Hashtable;
import java.util.Scanner;
import java.util.Set;

import org.apache.http.NoHttpResponseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.conn.HttpHostConnectException;

import android.os.AsyncTask;
import android.os.Build;
import android.text.TextUtils;
import android.util.Base64;

import com.alq.utils.LogUtility;
import com.alq.utils.PrefsUtility;
import com.alq.utils.Utility;

/**
 * Class to request web service in background using AsyncTask.
 * @author Aloha
 * */
public class RequestTask extends AsyncTask<ServiceRequest, String, ServiceResponse> {

	private static final String CLASSTAG = RequestTask.class.getSimpleName();

	private ServiceRequest serviceRequest;
	private String errorMsg;
	public static String REQUEST_TIMEDOUT = "Unable to connect server. Please try again.";
	public static String ERROR_OCCURED_ON_SERVER = "An error occured on server.";
	@Override
	protected ServiceResponse doInBackground(ServiceRequest... serviceRequests) {
		
		serviceRequest = serviceRequests[0];
		ServiceResponse serviceResponse = new ServiceResponse();
		
		// get the HTTP Client for the self - signed certificate.
		String responseString = null;
		HttpURLConnection conn = null;

		try { 
			if(serviceRequest == null) return null;
			serviceResponse.setServiceRequestTag(serviceRequest.tag);
			printRequestDetails();
			
			responseString = initiateRequest(conn, serviceRequest);
			serviceResponse.setResponseString(responseString);
			
			LogUtility.printDebugMessage("RequestTask:doInBackground response - "+responseString);

			// parsing of response asynchronously
//			APIModel apiModel = serviceRequest.getApiModel();
//			apiModel.parseResponse(responseString);
//
//			if(apiModel instanceof ICacheable) {
//				((ICacheable)apiModel).save(apiModel.getContext());
//			}
//			

		} catch (ClientProtocolException e) {
			if(e != null) {
				LogUtility.printErrorMessage(CLASSTAG, e);
			}
			errorMsg = ERROR_OCCURED_ON_SERVER;
			serviceResponse.setErrorMsg(errorMsg);
			return serviceResponse;
		} catch(SocketTimeoutException iioe) {
			if(iioe != null) {
				LogUtility.printErrorMessage(CLASSTAG, iioe);
			}
			errorMsg = REQUEST_TIMEDOUT;
			serviceResponse.setErrorMsg(errorMsg);
			return serviceResponse;
		} catch(ConnectTimeoutException cte) {
			if(cte != null) {
				LogUtility.printErrorMessage(CLASSTAG, cte);
			}
			errorMsg = REQUEST_TIMEDOUT;
			serviceResponse.setErrorMsg(errorMsg);
			return serviceResponse;
		} catch(NoHttpResponseException cte) {
			if(cte != null) {
				LogUtility.printErrorMessage(CLASSTAG, cte);
			}
			errorMsg = REQUEST_TIMEDOUT;
			serviceResponse.setErrorMsg(errorMsg);
			return serviceResponse;
		} catch(UnknownHostException uhe) {
			if(uhe != null) {
				LogUtility.printErrorMessage(CLASSTAG, uhe);
			}
			errorMsg = REQUEST_TIMEDOUT;
			serviceResponse.setErrorMsg(errorMsg);
			return serviceResponse;
		} catch(HttpHostConnectException uhe) {
			if(uhe != null) {
				LogUtility.printErrorMessage(CLASSTAG, uhe);
			}
			errorMsg = REQUEST_TIMEDOUT;
			serviceResponse.setErrorMsg(errorMsg);
			return serviceResponse;
		} catch (IOException e) {
			
			if(e != null){
				LogUtility.printErrorMessage(CLASSTAG, e);
			}
			errorMsg = REQUEST_TIMEDOUT;
			serviceResponse.setErrorMsg(errorMsg);
			return serviceResponse;
		} catch (Exception e) {
			if(e != null) {
				LogUtility.printErrorMessage(CLASSTAG, e);
			}
			errorMsg = ERROR_OCCURED_ON_SERVER;
			serviceResponse.setErrorMsg(errorMsg);
			return serviceResponse;
		}

		serviceResponse.setResponseString(responseString);
		LogUtility.printDebugMessage("RequestTask:doInBackground response - "+responseString);

		return serviceResponse;
	}

	@Override
	protected void onPostExecute(ServiceResponse result) {

		if(!TextUtils.isEmpty(result.getErrorMsg())) {
			LogUtility.printErrorMessage("RequestTask:onPostExecute - "+result.getErrorMsg());	
		}

		result.setServiceRequestTag(serviceRequest.tag);
		serviceRequest.getDelegate().onComplete(result);
	}

	private void printRequestDetails() {
		if(serviceRequest != null) {
			LogUtility.printInfoMessage("Request URL = "+serviceRequest.getUrl());
			LogUtility.printInfoMessage("Request Body = "+serviceRequest.getAdditionalHTTPBody());
		}	
	}

	/**
	 * Connect to provided target url and send request data and return response  
	 * @param conn 
	 * @param request
	 * @return reqResponse
	 * @throws MalformedURLException
	 * @throws IOException
	 * @throws Exception
	 */
	private String initiateRequest(HttpURLConnection conn, ServiceRequest request) throws MalformedURLException, IOException, Exception {

		URL url = null;

		String response= "";
		
		//if you are using https, make sure to import java.net.HttpsURLConnection
		url = new URL(request.getUrl());

		conn= (HttpURLConnection) url.openConnection();

		initHttpHeaders(request, conn);
		//once you set the output to true, you don?t really need to set the request method to post, but I?m doing it anyway
		conn.setRequestMethod(request.getHTTPMethod());
		conn.setRequestProperty("Content-Type", request.getContentType());
		conn.setConnectTimeout(30000);
		conn.setReadTimeout(30000);
		
		String auth = PrefsUtility.getInstance().getUsername() + ":" + PrefsUtility.getInstance().getPassword();
		
		final String basicAuth = "Basic " + Base64.encodeToString(auth.getBytes(), Base64.NO_WRAP);
		conn.setRequestProperty ("Authorization", basicAuth);
		
		//Android documentation suggested that you set the length of the data you are sending to the server, BUT
		// do NOT specify this length in the header by using conn.setRequestProperty(?Content-Length?, length);
		//use this instead.
        
		String additionHttpBody = request.getAdditionalHTTPBody();
		
		if (!Utility.isEmpty(additionHttpBody)) {
			//set the output to true, indicating you are outputting(uploading) POST data
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setFixedLengthStreamingMode(request.getAdditionalHTTPBody().getBytes().length);
			
			// This is for avoid EOF exception from getResponseCode
			if (Build.VERSION.SDK_INT > 13) { 
				conn.setRequestProperty("Connection", "close"); 
				System.setProperty("http.keepAlive", "false");
			}
			
			//send the POST out
			PrintWriter out = new PrintWriter(conn.getOutputStream());
			out.print(request.getAdditionalHTTPBody());
			out.close();
		}
		
		int responseCode = conn.getResponseCode();
		LogUtility.printErrorMessage("Response Code :: Request Task User Auth :: "+responseCode);

		//start listening to the stream
		Scanner inStream = null;
		try {
			
			int status = conn.getResponseCode();
			if (status >= 400 ) {
				inStream = new Scanner( conn.getErrorStream() );
			} else {
				inStream = new Scanner(conn.getInputStream());
			}
			
//			inStream = new Scanner(conn.getInputStream());

			//process the stream and store it in StringBuilder
			while(inStream.hasNextLine()) {
				response+=(inStream.nextLine());
			}

			inStream.close();
		} catch (IOException ioe) {
			if(conn != null) {
				
			}
			
			throw ioe;
		} finally {
			
			if(inStream != null) inStream.close();
			conn.disconnect();
		}
		return response;
	}

	private void initHttpHeaders(ServiceRequest request, HttpURLConnection httpURLConnection) {
		Hashtable<String, String> additionalHTTPHeaders = request.getHTTPHeaders();
		if(additionalHTTPHeaders == null || additionalHTTPHeaders.isEmpty()) return;
		Set<String> keys = additionalHTTPHeaders.keySet();
        for(String key: keys) {
            httpURLConnection.setRequestProperty(key, additionalHTTPHeaders.get(key));
        }
	}

}