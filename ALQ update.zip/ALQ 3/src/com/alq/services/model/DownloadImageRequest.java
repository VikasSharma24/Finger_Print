package com.alq.services.model;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.text.TextUtils;
import android.util.Base64;

import com.alq.App;
import com.alq.R;
import com.alq.constant.Constants;
import com.alq.delegates.IServiceDelegate;
import com.alq.delegates.IWebRequestDelegate;
import com.alq.services.ServiceRequest;
import com.alq.services.ServiceResponse;
import com.alq.utils.PrefsUtility;
import com.alq.utils.Utility;

public class DownloadImageRequest extends ServiceRequest implements IServiceDelegate {

	private static final String TAG = DownloadImageRequest.class.getSimpleName();

	private IWebRequestDelegate delegate; 
	private Context context;

	public DownloadImageRequest(Context context, IWebRequestDelegate delegate) {
		this.context = context;
		this.delegate = delegate;
	}

	@Override
	public void initWebRequest() {
		setUrl(Constants.URLs.GET_DOWNLOAD_IMAGES_DATA);
		setHTTPMethod(Constants.HTTPMethod.POST);
		setContentType(context.getString(R.string.content_type_json));
		setDelegate(this);
	}

	@Override
	public void onComplete(ServiceResponse serviceResponse) {
		if (!TextUtils.isEmpty(serviceResponse.getErrorMsg())) {
			delegate.onWebRequestFailure(serviceResponse.getErrorMsg(), TAG, this);
			if (context != null) 
				Utility.showMessage(context, serviceResponse.getErrorMsg());
		} else {
			PrefsUtility.getInstance().setLastDownloadImageDate(Utility.getCurTime());
			parseDownloadImageResponse(serviceResponse.getResponseString());
			delegate.onWebRequestSuccess(TAG, this);
		}
	}

	private void parseDownloadImageResponse(String responseString) {
		boolean isFailedParsing = false;
		try {
			JSONObject respJosn = new JSONObject(responseString);
			JSONObject customerJsonObject = (JSONObject) Utility.getJsonObjectValue(respJosn, Constants.PARAM_DOWNLOAD_IMAGES_DATA_RESULT);

			if (customerJsonObject == null) return;
			if (customerJsonObject.has(Constants.PARAM_DOWNLOAD_IMAGE_SYNC_DATE)) {
				String syncDate = (String) Utility.getJsonObjectValue(customerJsonObject, Constants.PARAM_DOWNLOAD_IMAGE_SYNC_DATE);
				PrefsUtility.getInstance().setSyncDownloadImagesDate(syncDate);
			}

			if (!customerJsonObject.has(Constants.PARAM_IMAGE_DOWNLOAD_LIST)) return;

			Object obj = Utility.getJsonObjectValue(customerJsonObject, Constants.PARAM_IMAGE_DOWNLOAD_LIST);

			if (obj instanceof JSONArray) {
				JSONArray finalArray = (JSONArray) obj;

				for ( int i = 0; i < finalArray.length(); i++ ) {
					if (finalArray.isNull(i)) continue;

					JSONObject downloadJson = finalArray.getJSONObject(i);
					String imageName = (String) Utility.getJsonObjectValue(downloadJson, Constants.PARAM_IMAGE_NAME);
					String imageData = (String) Utility.getJsonObjectValue(downloadJson, Constants.PARAM_IMAGE_DATA);
					writeImageDataToFile(imageName, imageData);
				}
			} else if (obj instanceof JSONObject) {
				JSONObject jsonObject = (JSONObject) obj;
				String imageName = (String) Utility.getJsonObjectValue(jsonObject, Constants.PARAM_IMAGE_NAME);
				String imageData = (String) Utility.getJsonObjectValue(jsonObject, Constants.PARAM_IMAGE_DATA);
				writeImageDataToFile(imageName, imageData);
			}

		} catch (JSONException e) {
			e.printStackTrace();
			isFailedParsing = true;
		} 

		if (isFailedParsing) {
			Utility.showMessage(context, "Failed to sync domaload images");
		} else {
			Utility.showMessage(context, "Sync Download images completed");
		}
	}

	private void writeImageDataToFile(String imageName, String imageData) {
		try {
			File catdir = Utility.createCatlogDir();
			File imageFile = new File(catdir + File.separator + imageName);

			if (imageFile != null) {
				byte[] byteImageData = null;
				if (imageData != null) {
					byteImageData = Base64.decode(imageData, Base64.DEFAULT);

					if(!imageFile.exists()) {
						imageFile.createNewFile();
					}

					FileOutputStream fos = new FileOutputStream(imageFile);

					if (fos != null) {
						fos.write(byteImageData);
						fos.flush();
						fos.close();
					}

				}
			}

		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

}
