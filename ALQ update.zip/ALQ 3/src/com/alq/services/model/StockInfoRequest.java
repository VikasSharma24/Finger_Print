package com.alq.services.model;

import java.io.File;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.os.Handler;
import android.text.TextUtils;

import com.alq.R;
import com.alq.constant.Constants;
import com.alq.delegates.IServiceDelegate;
import com.alq.delegates.IWebRequestDelegate;
import com.alq.model.SearchImages;
import com.alq.model.dao.StockInformationDAO;
import com.alq.services.ServiceRequest;
import com.alq.services.ServiceResponse;
import com.alq.utils.GsonUtils;
import com.alq.utils.PrefsUtility;
import com.alq.utils.Utility;

public class StockInfoRequest extends ServiceRequest implements IServiceDelegate {
	private static final String TAG = StockInfoRequest.class.getSimpleName();

	private IWebRequestDelegate delegate; 
	private Context context;
	private Handler handler;

	public StockInfoRequest(Context context, IWebRequestDelegate delegate) {
		this.context = context;
		this.delegate = delegate;
	}

	public void initWebRequest() {
		setUrl(Constants.URLs.GET_STOCK_INFO_URL);
		setHTTPMethod(Constants.HTTPMethod.GET);
		setContentType(context.getString(R.string.content_type_json));
		setDelegate(this);
	}

	@Override
	public void onComplete(ServiceResponse serviceResponse) {
		if (!TextUtils.isEmpty(serviceResponse.getErrorMsg())) {
			delegate.onWebRequestFailure(serviceResponse.getErrorMsg(), TAG, this);
			if (context != null)
				Utility.showMessage(context, serviceResponse.getErrorMsg());
		} else {
			PrefsUtility.getInstance().setLastSyncStockDate(Utility.getCurTime());
			final String responseString = serviceResponse.getResponseString();
			handler = new Handler(context.getMainLooper());
			handler.post(new Runnable() {

				@Override
				public void run() {
					parseSearchResponse(responseString);
					delegate.onWebRequestSuccess(TAG, StockInfoRequest.this);
				}
			});
		}
	}

	private void parseSearchResponse(String responseString) {
		boolean isFailedParsing = false;
		try {
			JSONObject respJosn = new JSONObject(responseString);
			JSONObject stockJsonObject = (JSONObject) Utility.getJsonObjectValue(respJosn, Constants.PARAM_STOCK_INFORMATION_RESULT);

			if (stockJsonObject == null) return;

			if (stockJsonObject.has("syncValue")) {
				int syncValue = stockJsonObject.getInt("syncValue");
				PrefsUtility.getInstance().setSyncStockValue(syncValue);
			}

			if (stockJsonObject.has("stockDownloaded")) {
				boolean stockDownloaded = Utility.getJsonObjectBooleanValue(stockJsonObject, "stockDownloaded");
				PrefsUtility.getInstance().setStockDownloaded(stockDownloaded);
			}

			if (!stockJsonObject.has(Constants.PARAM_FINAL_CUSTOMER_lIST)) return;

			Object obj = Utility.getJsonObjectValue(stockJsonObject, Constants.PARAM_FINAL_CUSTOMER_lIST);

			if (obj instanceof JSONObject) {
				JSONObject finalCustJson = (JSONObject) obj;

				//SearchImages searchImages = SearchImages.getSearchItemDataFromJSON(finalCustJson);
				SearchImages searchImages = GsonUtils.createGson().fromJson(finalCustJson.toString(), SearchImages.class);
				searchImages.save(context);

			} else if (obj instanceof JSONArray) {
				JSONArray finalCustArray = (JSONArray) obj;

				for ( int i = 0; i < finalCustArray.length(); i++ ) {
					if (finalCustArray.isNull(i)) continue;

					//SearchImages searchImages = SearchImages.getSearchItemDataFromJSON(finalCustArray.getJSONObject(i));
					SearchImages searchImages = GsonUtils.createGson().fromJson(finalCustArray.getJSONObject(i).toString(), SearchImages.class);
					if (searchImages == null) continue;

					SearchImages stockInfo = StockInformationDAO.getStoredStockInfo(context, searchImages.getItemCode());
					if (stockInfo != null) {
						searchImages.setRowId(stockInfo.getRowId());
					}

					File catlogFile = Utility.createCatlogDir();

					if (catlogFile != null) {
						searchImages.setImagePath(catlogFile.getAbsolutePath() + File.separator + searchImages.getItemCode() + ".jpg");
					}

					searchImages.save(context);
				}
			}

		} catch (JSONException e) {
			isFailedParsing = true;
			e.printStackTrace();
		}

		if (isFailedParsing) {
			Utility.showMessage(context, "Failed to sync stock information");
		}
	}

}
