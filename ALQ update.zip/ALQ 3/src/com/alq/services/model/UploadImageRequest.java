package com.alq.services.model;

import java.io.File;

import org.json.JSONObject;

import android.content.Context;
import android.graphics.Bitmap;
import android.text.TextUtils;

import com.alq.R;
import com.alq.constant.Constants;
import com.alq.delegates.IServiceDelegate;
import com.alq.delegates.IWebRequestDelegate;
import com.alq.services.ServiceRequest;
import com.alq.services.ServiceResponse;
import com.alq.utils.ScalingUtilities;
import com.alq.utils.Utility;

public class UploadImageRequest extends ServiceRequest implements IServiceDelegate {
	private static final String TAG = UploadImageRequest.class.getSimpleName();

	private IWebRequestDelegate delegate; 
	private Context context;

	public UploadImageRequest(Context context, IWebRequestDelegate delegate) {
		this.context = context;
		this.delegate = delegate;
	}

	public void initWebRequest() {
		setUrl(Constants.URLs.SAVE_PHOTO_URL);
		setHTTPMethod(Constants.HTTPMethod.POST);
		setContentType(context.getString(R.string.content_type_json));
		setDelegate(this);
	}

	@Override
	public void onComplete(ServiceResponse serviceResponse) {
		if (TextUtils.isEmpty(serviceResponse.getErrorMsg())) {
			delegate.onWebRequestFailure(serviceResponse.getErrorMsg(), TAG, this);
		} else {
			delegate.onWebRequestSuccess(TAG, this);
		}
	}

	public JSONObject createJSONObject(String path, String fileName) {
		Bitmap bmp = ScalingUtilities.decodeFile(path);
		String imageBase64Str = Utility.convertToBase64String(bmp);

		JSONObject jsonObject = new JSONObject();
		try {
			jsonObject.put(Constants.PARAM_IMAGE_NAME, fileName);
			jsonObject.put(Constants.PARAM_IMAGE_DATA, imageBase64Str);
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		
		return jsonObject;

	}



}
