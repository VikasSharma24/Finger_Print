package com.alq.services.model;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.content.ContentProviderOperation;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;

import com.alq.R;
import com.alq.constant.Constants;
import com.alq.delegates.IServiceDelegate;
import com.alq.delegates.IWebRequestDelegate;
import com.alq.model.CustomerInfo;
import com.alq.model.dao.CustomerInformationDAO;
import com.alq.services.ServiceRequest;
import com.alq.services.ServiceResponse;
import com.alq.utils.GsonUtils;
import com.alq.utils.PrefsUtility;
import com.alq.utils.Utility;

public class CustomerInfoRequest extends ServiceRequest implements IServiceDelegate {
	private static final String TAG = CustomerInfoRequest.class.getSimpleName();

	private IWebRequestDelegate delegate; 
	private Context context;

	public CustomerInfoRequest(Context context, IWebRequestDelegate delegate) {
		this.context = context;
		this.delegate = delegate;
	}

	@Override
	public void initWebRequest() {
		setUrl(Constants.URLs.GET_CUST_INFO_URL);
		setHTTPMethod(Constants.HTTPMethod.POST);
		setContentType(context.getString(R.string.content_type_json));
		setDelegate(this);
	}

	@Override
	public void onComplete(ServiceResponse serviceResponse) {
		if (!TextUtils.isEmpty(serviceResponse.getErrorMsg())) {
			delegate.onWebRequestFailure(serviceResponse.getErrorMsg(), TAG, this);
			if (context != null) 
				Utility.showMessage(context, serviceResponse.getErrorMsg());
		} else {
			/*PrefsUtility.getInstance().setLastSyncCustDate(Utility.getCurTime());
			parsecCustomerInfoResponse(serviceResponse.getResponseString());
			delegate.onWebRequestSuccess(TAG, this);*/
			
			// Send the name of the connected device back to the UI Activity
			Message msg = mHandler.obtainMessage(1);
			Bundle bundle = new Bundle();
			bundle.putString("custResString", serviceResponse.getResponseString());
			msg.setData(bundle);
			mHandler.sendMessage(msg);
		}
	}


	private void parsecCustomerInfoResponse(String responseString) {
		boolean isFailedParsing = false;
		try {
			if (responseString == null) return;
			JSONObject respJosn = new JSONObject(responseString);
			JSONObject customerJsonObject = (JSONObject) Utility.getJsonObjectValue(respJosn, Constants.PARAM_CUSTOMER_INFO_RESULT);

			if (customerJsonObject == null) return;
			if (!customerJsonObject.has(Constants.PARAM_CUSTOMER_INFO)) return;

			Object obj = Utility.getJsonObjectValue(customerJsonObject, Constants.PARAM_CUSTOMER_INFO);

			if (obj instanceof JSONObject) {
				JSONObject finalCustJson = (JSONObject) obj;

				//SearchImages searchImages = SearchImages.getSearchItemDataFromJSON(finalCustJson);
				CustomerInfo customerInfo = GsonUtils.createGson().fromJson(finalCustJson.toString(), CustomerInfo.class);
				customerInfo.save(context);

			} else if (obj instanceof JSONArray) {
				JSONArray finalCustArray = (JSONArray) obj;
				ArrayList<ContentProviderOperation> oprs = new ArrayList<ContentProviderOperation>();
				
				for ( int i = 0; i < finalCustArray.length(); i++ ) {
					if (finalCustArray.isNull(i)) continue;

					//SearchImages searchImages = SearchImages.getSearchItemDataFromJSON(finalCustArray.getJSONObject(i));
					CustomerInfo customerInfo = GsonUtils.createGson().fromJson(finalCustArray.getJSONObject(i).toString(), CustomerInfo.class);

					if (customerInfo == null) continue;

					CustomerInfo cusinfo = CustomerInformationDAO.getStoredCustomerInfo(context, customerInfo.getCustomerCode());

					if (cusinfo != null) {
						customerInfo.setRowId(cusinfo.getRowId());						
					}
				
					//customerInfo.save(context);
					
					ContentProviderOperation contentProviderOperation = customerInfo.addContentProviderOpr(context);
					
					if (contentProviderOperation != null) {
						oprs.add(contentProviderOperation);
					}
				}
				
				CustomerInfo.applyBatch(context, oprs);
			}

		} catch (JSONException e) {
			e.printStackTrace();
			isFailedParsing = true;
		}

		if (isFailedParsing) {
			Utility.showMessage(context, "Failed to sync customer information");
		}
	}
	
	@SuppressLint("HandlerLeak")
	private Handler mHandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case 1:
				delegate.onWebRequestSuccess(TAG, CustomerInfoRequest.this);
				String resString = msg.getData().getString("custResString");
				PrefsUtility.getInstance().setLastSyncCustDate(Utility.getCurTime());
				parsecCustomerInfoResponse(resString);
				break;
			default:
				break;
			}
		};
	};

}
