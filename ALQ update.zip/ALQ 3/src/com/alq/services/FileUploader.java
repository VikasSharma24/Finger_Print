package com.alq.services;


import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import android.os.AsyncTask;
import android.text.TextUtils;

import com.alq.App;
import com.alq.delegates.IFileUploadProgressModelDelegate;
import com.alq.utils.LogUtility;
import com.alq.utils.MultipartUtility;
import com.alq.utils.Utility;

/**
 * Handle functionality of upload file 
 */
public class FileUploader extends AsyncTask<ServiceRequest, String, ServiceResponse> {

	// class members
	private ServiceRequest serviceRequest;
	private String TAG = "FileUploader";
	private int requestTimeout;
	private IFileUploadProgressModelDelegate uploadProgressDelegate;
	private HashMap<String, String> fieldMap;
	private HashMap<String, String> fileMap;

	/**
	 * Initialize object
	 * @param requestResponseData
	 * @param delegate
	 */
	public FileUploader(IFileUploadProgressModelDelegate uploadProgressDelegate, int requestTimeout) {
		this.uploadProgressDelegate = uploadProgressDelegate;
		this.requestTimeout = requestTimeout;
	}


	@Override
	protected ServiceResponse doInBackground(ServiceRequest... params) {

		serviceRequest = params[0];

		ServiceResponse serviceResponse = new ServiceResponse();

		try {
			String charset = "UTF-8";

			MultipartUtility multipart = new MultipartUtility(serviceRequest.getUrl(), charset, requestTimeout);

			// add form field params
			if(fieldMap != null && fieldMap.size() > 0) {
				Set<String> keys = fieldMap.keySet();
				Iterator<String> iterator = keys.iterator();
				while (iterator.hasNext()) {
					String key = (String) iterator.next();
					String value = fieldMap.get(key);
					if(!TextUtils.isEmpty(key) && !TextUtils.isEmpty(value)) {
						multipart.addFormField(key, value);
					}
				}
			}
			
			boolean addFilePart = false;
			
			if (Utility.isNetworkAvailable(App.getInstance().getApplicationContext()) 
					|| Utility.isWiFiAvailable(App.getInstance().getApplicationContext())) {
				addFilePart = true;
			}  
			
			// add file field params
			if(addFilePart && fileMap != null && fileMap.size() > 0) {
				Set<String> keys = fileMap.keySet();
				Iterator<String> iterator = keys.iterator();
				while (iterator.hasNext()) {
					String key = (String) iterator.next();
					String value = fileMap.get(key);
					if(!TextUtils.isEmpty(key) && !TextUtils.isEmpty(value)) {
						File file = new File(value);
						if(file.exists()) {
							// add file part
							multipart.addFilePart(key, file, this);
						} else {
							LogUtility.printDebugMessage(TAG+":doInBackground - file not found "+value);
						}
					} else {
						LogUtility.printDebugMessage(TAG+":doInBackground - key or value is null");
					}
				}
			}

			String responseString = multipart.finish();
			//TODO : set error message of service response
			/*if(Utility.isError(responseString)) {
				serviceResponse.setErrorMsg(Utility.getErrorMsg(responseString));
			}*/
			serviceResponse.setResponseString(responseString);
			LogUtility.printDebugMessage(TAG+":doInBackground - "+responseString);


		} catch (Exception e) {
			String msg = e.getMessage();
			LogUtility.printErrorMessage(TAG + " - doInBackground : Exception occured " + msg);
			serviceResponse.setErrorMsg(msg);
			e.printStackTrace();
		} 

		return serviceResponse;
	}

	@Override
	protected void onProgressUpdate(String... values) {
		super.onProgressUpdate(values);
		if(uploadProgressDelegate != null) {
			uploadProgressDelegate.onFileUploadProgressUpdate(values[0]);
		}
	}

	@Override
	protected void onPostExecute(ServiceResponse result) {
		super.onPostExecute(result);

		if(!TextUtils.isEmpty(result.getErrorMsg())) {
			LogUtility.printErrorMessage("FileUploader:onPostExecute - "+result.getErrorMsg());	
		}
		
		serviceRequest.getDelegate().onComplete(result);  
	}

	public void updateProgressFromUIThread(String values) {
		publishProgress(values);
	}

	public void setFieldMap(HashMap<String, String> fieldMap) {
		this.fieldMap = fieldMap;
	}

	public void setFileMap(HashMap<String, String> fileMap) {
		this.fileMap = fileMap;
	}

}

