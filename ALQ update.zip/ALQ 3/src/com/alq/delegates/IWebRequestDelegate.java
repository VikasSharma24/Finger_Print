package com.alq.delegates;

import com.alq.services.ServiceRequest;



public interface IWebRequestDelegate {
	
	/** Success status callback */
	public void onWebRequestSuccess(String tag, ServiceRequest request);
	
	/** Failure status callback */
	public void onWebRequestFailure(String errMsg, String tag, ServiceRequest request);

}
