package com.alq.delegates;

import android.content.Context;

import com.alq.services.ServiceResponse;

/**
 * Delegate/interface to handle model class callback's.
 */
public interface IModelDelegate {
	
	public void onDataDidChange(ServiceResponse serviceResponse);
	
	public boolean isActivityDelegateLive(Object obj);
	
	public Context getAppContext(); 
}
