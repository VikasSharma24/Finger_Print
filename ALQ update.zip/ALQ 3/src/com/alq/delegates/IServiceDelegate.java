package com.alq.delegates;


import com.alq.services.ServiceResponse;

/**
 * Delegate/interface to handle service callback's.
 */
public interface IServiceDelegate {
	public void onComplete(ServiceResponse serviceResponse);
}
