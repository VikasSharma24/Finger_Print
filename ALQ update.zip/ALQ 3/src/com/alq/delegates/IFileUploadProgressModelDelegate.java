package com.alq.delegates;

/**
 * Interface/Delegate for upload file status
 * @author Administrator
 *
 */
public interface IFileUploadProgressModelDelegate {

	/** file upload progress update callback */
	public void onFileUploadProgressUpdate(String values); 
}
