package com.alq.delegates;


public interface ISyncServiceDelegate extends IWebRequestDelegate {
	public void startSync();
	public void stopSync();
}
