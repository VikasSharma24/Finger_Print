package com.alq.fragment;

import java.util.ArrayDeque;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager.LoaderCallbacks;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.alq.App;
import com.alq.R;
import com.alq.delegates.ISyncServiceDelegate;
import com.alq.delegates.IWebRequestDelegate;
import com.alq.services.ServiceRequest;
import com.alq.services.model.CustomerInfoRequest;
import com.alq.services.model.StockInfoRequest;
import com.alq.utils.Utility;
import com.nostra13.universalimageloader.core.DisplayImageOptions;

public abstract class BaseFragment extends android.support.v4.app.Fragment implements IWebRequestDelegate, ISyncServiceDelegate {
	private ArrayDeque<ServiceRequest> requestPool;
	public static DisplayImageOptions options;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestPool = new ArrayDeque<ServiceRequest>();
	}

	public Context getAppContext() {
		return App.getInstance().getApplicationContext();
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		setActionBarIcon(getResources().getDrawable(R.drawable.ic_launcher));
		disableBackButton(getActivity());
		setActionBarIcon(null);
	}

	public void setActionBarTitle(int resId) {
		ActionBar actionBar = getActivity().getActionBar();
		actionBar.setTitle(resId);
	}

	public void setActionBarTitle(String strTitle) {
		ActionBar actionBar = getActivity().getActionBar();
		actionBar.setTitle(strTitle);
	}

	public static void enableBackButton(Activity activity) {
		ActionBar actionBar = activity.getActionBar();
		actionBar.setDisplayHomeAsUpEnabled(true);
	}

	public static void disableBackButton(Activity activity) {
		ActionBar actionBar = activity.getActionBar();
		actionBar.setDisplayHomeAsUpEnabled(false);
	}

	public void setActionBarSubTitle(String subTitle) {
		if (getActivity() == null) return;
		ActionBar actionBar = getActivity().getActionBar();
		actionBar.setSubtitle(subTitle);
	}

	public void setActionBarIcon(Drawable drawable) {
		ActionBar actionBar = getActivity().getActionBar();
		actionBar.setIcon(drawable);
	}

	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		// Inflate the menu; this adds items to the action bar if it is present.
		inflater.inflate(R.menu.main, menu);
		super.onCreateOptionsMenu(menu, inflater);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		switch (id) {
		case android.R.id.home:
			getActivity().onBackPressed();
			break;
		case R.id.action_capture:
			handleActionCapture();
			break;
		case R.id.action_search:
			handleActionSearch();
			break;
		case R.id.action_export:
			handleActionExport();
			break;
		case R.id.action_stock:
			//handleActionStock();
			break;
		default:
			break;
		}

		return super.onOptionsItemSelected(item);
	}


	/**
	 * @param <T>
	 * @param canResetLoader
	 * Loader will get reset if Chat fragment initialize when click on notification. 
	 */
	public <T> void initLoader(boolean canResetLoader, int loaderId, LoaderCallbacks<T> callbacks) {
		if(canResetLoader) {
			getLoaderManager().restartLoader(loaderId, null, callbacks);
		}else {
			getLoaderManager().initLoader(loaderId, null, callbacks);
		}
	}

	@Override
	public void onPause() {
		super.onPause();
	}

	public interface OnUploadListener {
		public void onUploadSuccess();
		public void onUploadFailed();
	}

	private void handleActionCapture() {
		Fragment fragment = getActivity().getSupportFragmentManager().findFragmentByTag(CaptureImageFragment.TAG);
		if (fragment != null && fragment instanceof CaptureImageFragment) {
			if (fragment.isVisible()) {
				return;
			}
		}
		CaptureImageFragment.pushFragment(getActivity(), null, true);

	}

	private void handleActionSearch() {
		Fragment fragment = getActivity().getSupportFragmentManager().findFragmentByTag(SearchImagesFragment.TAG);
		if (fragment != null && fragment instanceof SearchImagesFragment) {
			return;
		}

		SearchImagesFragment.pushFragment(getActivity(), null);
	}

	private void handleActionExport() {
		Fragment fragment = getActivity().getSupportFragmentManager().findFragmentByTag(ExportToExcelFragment.TAG);
		if (fragment != null && fragment instanceof ExportToExcelFragment) {
			if (fragment.isVisible()) {
				return;
			}
		}

		ExportToExcelFragment.pushFragment(getActivity(), null);
	}

	private void handleActionStock() {
		Fragment fragment = getActivity().getSupportFragmentManager().findFragmentByTag(StockFragment.TAG);
		if (fragment != null && fragment instanceof StockFragment) {
			if (fragment.isVisible()) {
				return;
			}
		}
		
		StockFragment.pushFragment(getActivity(), true);
	}
	
	/**
	 * Check is fragment live
	 * @return boolean
	 */
	public boolean isFragmentLive(Fragment fragment) {

		if(fragment == null) { return false; }

		Activity activity = fragment.getActivity();
		
		if (fragment.isVisible() && isActivityLive(activity)) {
			return true;
		}

		return false;
	}
	
	private boolean isActivityLive(Activity activity) {
		if(activity != null && !activity.isFinishing()) {
			return true;
		}
		
		return false;
	}
	
	
	@Override
	public void onWebRequestSuccess(String tag, ServiceRequest request) {
		requestCompleteAction(request);
	}

	@Override
	public void onWebRequestFailure(String errMsg, String tag,
			ServiceRequest request) {
		requestCompleteAction(request);
	}

	@Override
	public void startSync() {
		if(requestPool == null || requestPool.isEmpty()) {
			return;
		}

		try {
			ServiceRequest request = requestPool.getFirst();
			request.initWebRequest();
			request.invoke();
		} catch(Exception exception) {
			exception.printStackTrace();
		}
	}

	@Override
	public void stopSync() {
		if(requestPool != null) {
			requestPool.clear();
		}
	}


	private synchronized void addRequest(ServiceRequest request) {
		requestPool.add(request);
	}

	private synchronized void removeRequest(ServiceRequest request) {
		requestPool.remove(request);
	}

	private synchronized void addRequestAtTop(ServiceRequest request) {
		requestPool.addFirst(request);
	}

	/**
	 * Remove provided request and call to start sync
	 * @param model
	 */
	private void requestCompleteAction(ServiceRequest request) {
		removeRequest(request);
		startSync();
		
		if (request instanceof CustomerInfoRequest) {
			Utility.showMessage(getAppContext(), "Sync completed");
		}
	}

	public void setupExcelDataRequests() {

		StockInfoRequest stockInfoRequest = new StockInfoRequest(getActivity(), this);
		CustomerInfoRequest customerInfoRequest = new CustomerInfoRequest(getActivity(), this);

		addRequest(stockInfoRequest);
		addRequest(customerInfoRequest);
	}
	

	public void setDisplayImageOptions() {
		options = new DisplayImageOptions.Builder()
		.showImageOnLoading(R.drawable.ic_empty)
		.showImageForEmptyUri(R.drawable.ic_empty)
		.showImageOnFail(R.drawable.ic_empty)
		.cacheInMemory(true)
		.cacheOnDisk(true)
		.considerExifParams(true)
		.bitmapConfig(Bitmap.Config.RGB_565)
		.build();

	}

}
