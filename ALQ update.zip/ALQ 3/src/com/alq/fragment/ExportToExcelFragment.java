package com.alq.fragment;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import android.app.DatePickerDialog.OnDateSetListener;
import android.app.ProgressDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

import com.alq.R;
import com.alq.constant.Constants;
import com.alq.database.Tables;
import com.alq.database.Tables.ItemTable;
import com.alq.model.dao.BaseDAO.QueryBuilder;
import com.alq.utils.Utility;
import com.opencsv.CSVWriter;

public class ExportToExcelFragment extends BaseFragment implements OnDateSetListener {
	public static final String TAG = ExportToExcelFragment.class.getSimpleName();

	EditText edtFromDate;
	EditText edtToDate;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setHasOptionsMenu(true);
		setRetainInstance(true);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_export_to_excel, container, false);
		initView(view);
		return view;
	}

	private void initView(View view) {
		edtFromDate = (EditText) view.findViewById(R.id.edtFromDate);
		edtToDate = (EditText) view.findViewById(R.id.edtToDate);
		setButtonListener(view);
	}

	private void setButtonListener(View view) {
		((Button) view.findViewById(R.id.exportToExcelButton)).setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				actionOnExportToExcelButton();
			}
		});

		((Button) view.findViewById(R.id.cancelButton)).setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				getActivity().onBackPressed();
			}
		});

		edtFromDate.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				showDatePickerDialogFragment(v);
			}
		});

		edtToDate.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				showDatePickerDialogFragment(v);
			}
		});
	}

	protected void actionOnExportToExcelButton() {
		String frmStrDate = edtFromDate.getText().toString();
		String toStrDate = edtToDate.getText().toString();
		Date fromDate = Utility.convertStringDateToDateFormat(frmStrDate, Constants.LOCAL_DATE_PATTERN);
		Date toDate = Utility.convertStringDateToDateFormat(toStrDate, Constants.LOCAL_DATE_PATTERN);

		if ( fromDate != null && toDate != null) {

			if (fromDate.compareTo(toDate) != 1) {
				ExportDataToExcelTask exportTask = new ExportDataToExcelTask();
				
				// Initiate asynchronous task 
				if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
					exportTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, frmStrDate, toStrDate);
				} else {
					exportTask.execute(frmStrDate, toStrDate);
				}
			} else {
				Utility.showAlertMessage(getActivity(), "To date cann't not be less than from date");
			}
		}
	}

	private void expotDataToExcel(String frmStrDate, String toStrDate) throws IOException, SQLException {
			String selection = "Date(" + ItemTable.COLUMN_ORDER_DATE + ") >= Date(?) AND Date(" + ItemTable.COLUMN_ORDER_DATE + ") <= Date(?)";

			QueryBuilder queryBuilder = new QueryBuilder(getAppContext());
			queryBuilder.withSelection( selection);
			queryBuilder.withSelectionArg(new String[] {frmStrDate, toStrDate});

			Cursor cursor = queryBuilder.query(ItemTable.CONTENT_URI);

			
		    File file = Utility.getExportDirPath();
		    
		    if (!Utility.makeDirectory(file)) {
		    	return;
		    }
		    
		   // String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
		    
		    File exportFile = new File(file.getPath() + File.separator +
					"Export_frm"+ frmStrDate +"_to_"+toStrDate+ ".csv");
		    
		    if (!exportFile.exists()) {
		    	exportFile.createNewFile();
		    }
		    
			CSVWriter csvWrite = new CSVWriter(new FileWriter(exportFile));

			if (cursor != null) {
				csvWrite.writeNext(new String[] {
						Tables.ItemTable.COLUMN_ITEM_ID,
						Tables.ItemTable.COLUMN_BARCODE_NO,
						Tables.ItemTable.COLUMN_ART,
						Tables.ItemTable.COLUMN_DESCRiPTION,
						Tables.ItemTable.COLUMN_BOOTH_NO,
						Tables.ItemTable.COLUMN_PKG,
						Tables.ItemTable.COLUMN_ORDER_DATE,
						Tables.ItemTable.COLUMN_BRAND,
						Tables.ItemTable.COLUMN_COLOUR,
						Tables.ItemTable.COLUMN_SIZE,
						Tables.ItemTable.COLUMN_WEIGHT,
						Tables.ItemTable.COLUMN_MEASUREMENT,
						Tables.ItemTable.COLUMN_ORIGIN,
						Tables.ItemTable.COLUMN_CURRENCY,
						Tables.ItemTable.COLUMN_PRICE,
						Tables.ItemTable.COLUMN_PIECE_PER_CARTOON,
						Tables.ItemTable.COLUMN_ORDERED_QTY,
						Tables.ItemTable.COLUMN_ITEM_PHOTO_URL
				});

				while (cursor.moveToNext()) {

					String arrStr[] = {
							cursor.getString(cursor.getColumnIndex(Tables.ItemTable.COLUMN_ITEM_ID)),
							cursor.getString(cursor.getColumnIndex(Tables.ItemTable.COLUMN_BARCODE_NO)),
							cursor.getString(cursor.getColumnIndex(Tables.ItemTable.COLUMN_ART)),
							cursor.getString(cursor.getColumnIndex(Tables.ItemTable.COLUMN_DESCRiPTION)),
							cursor.getString(cursor.getColumnIndex(Tables.ItemTable.COLUMN_BOOTH_NO)),
							cursor.getString(cursor.getColumnIndex(Tables.ItemTable.COLUMN_PKG)),
							cursor.getString(cursor.getColumnIndex(Tables.ItemTable.COLUMN_ORDER_DATE)),
							cursor.getString(cursor.getColumnIndex(Tables.ItemTable.COLUMN_BRAND )),
							cursor.getString(cursor.getColumnIndex(Tables.ItemTable.COLUMN_COLOUR)),
							cursor.getString(cursor.getColumnIndex(Tables.ItemTable.COLUMN_SIZE )),
							cursor.getString(cursor.getColumnIndex(Tables.ItemTable.COLUMN_WEIGHT)),
							cursor.getString(cursor.getColumnIndex(Tables.ItemTable.COLUMN_MEASUREMENT)),
							cursor.getString(cursor.getColumnIndex(Tables.ItemTable.COLUMN_ORIGIN)),
							cursor.getString(cursor.getColumnIndex(Tables.ItemTable.COLUMN_CURRENCY)),
							cursor.getString(cursor.getColumnIndex(Tables.ItemTable.COLUMN_PRICE)),
							cursor.getString(cursor.getColumnIndex(Tables.ItemTable.COLUMN_PIECE_PER_CARTOON)),
							cursor.getString(cursor.getColumnIndex(Tables.ItemTable.COLUMN_ORDERED_QTY)),
							cursor.getString(cursor.getColumnIndex(Tables.ItemTable.COLUMN_ITEM_PHOTO_URL))
					};
						
					csvWrite.writeNext(arrStr);
				}
			}

			csvWrite.close();
			cursor.close();
	}

	private void showDatePickerDialogFragment(View view) {
		DatePickerDialogFragment dialogFragment = new DatePickerDialogFragment();
		dialogFragment.setSrcView(view);
		dialogFragment.setOnDateSetListener(this);
		dialogFragment.show(getActivity().getSupportFragmentManager(), DatePickerDialogFragment.TAG);
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		setActionBarTitle(R.string.export_to_excel);
		enableBackButton(getActivity());
	}

	@Override
	public void onPause() {
		super.onPause();
	}

	@Override
	public void onResume() {
		super.onResume();
	}

	@Override
	public void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
	}


	public static ExportToExcelFragment pushFragment(Context activityContext, Bundle bundle) {
		ExportToExcelFragment fragment = new ExportToExcelFragment();
		Utility.fragmentTransaction(TAG, R.id.container, fragment, activityContext, true);
		return fragment;
	}

	@Override
	public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
		Object object = view.getTag();

		if (object != null) {
			TextView textView = (TextView) object;
			SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.LOCAL_DATE_PATTERN, Locale.US);

			Calendar calendar = Calendar.getInstance();
			calendar.set(Calendar.YEAR, year);
			calendar.set(Calendar.MONTH, monthOfYear);
			calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

			textView.setText(dateFormat.format(calendar.getTime()));

			view.updateDate(year, monthOfYear, dayOfMonth);
		}
	}


	class ExportDataToExcelTask extends AsyncTask<String, Void, Boolean> {

		ProgressDialog progressDialog;

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			progressDialog = ProgressDialog.show(getActivity(), "", "Exporting data Please wait...");
		}

		@Override
		protected Boolean doInBackground(String... param) {

			try {
				expotDataToExcel(param[0], param[1]);
				return true;
			} catch(SQLException ex) {
				ex.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}
			return false;
		}

		@Override
		protected void onPostExecute(Boolean success) {
			super.onPostExecute(success);

			if (progressDialog != null && progressDialog.isShowing()) {
				progressDialog.dismiss();
			}

			if (success) {
				Utility.showMessage(getAppContext(), "Export succeed");
			} else {
				Utility.showMessage(getAppContext(), "Export failed");
			}
		}

	}


}
