package com.alq.fragment;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;

import com.alq.R;
import com.alq.constant.Constants;
import com.alq.constant.Constants.HTTPMethod;
import com.alq.constant.Constants.URLs;
import com.alq.database.Tables.StockInformationTable;
import com.alq.delegates.IServiceDelegate;
import com.alq.model.CustomerInfo;
import com.alq.model.SearchImages;
import com.alq.model.dao.BaseDAO.QueryBuilder;
import com.alq.model.dao.CustomerInformationDAO;
import com.alq.model.dao.StockInformationDAO;
import com.alq.services.RequestTask;
import com.alq.services.ServiceRequest;
import com.alq.services.ServiceResponse;
import com.alq.sync.AsyncImageLoader;
import com.alq.sync.AsyncImagePresenter;
import com.alq.utils.GsonUtils;
import com.alq.utils.Utility;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingProgressListener;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;

public class SearchImagesFragment extends BaseFragment implements
IServiceDelegate {

	public static final String TAG = SearchImagesFragment.class.getSimpleName();

	private EditText edtCustomCode;
	private EditText edtSearchText;
	private EditText edtItemRangeFrom;
	private EditText edtItemRangeTo;
	private Spinner searchBySpinner;
	private GridView gridView;
	private ProgressBar progressBar;
	private CheckBox chkImageBox;

	private ImageAdapter imageAdapter;
	private ImageLoader imageLoader;

	private ArrayList<SearchImages> searchItemList;
	private SearchImagesTask searchImagesTask;


	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setHasOptionsMenu(true);
		setRetainInstance(true);

		setDisplayImageOptions();
		imageLoader = ImageLoader.getInstance();
		searchItemList = new ArrayList<>();
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_search_images,
				container, false);
		initView(view);
		return view;
	}

	private void initView(View view) {
		edtCustomCode = (EditText) view.findViewById(R.id.edtCustomCode);
		edtSearchText = (EditText) view.findViewById(R.id.edtSearchText);
		edtItemRangeFrom = (EditText) view.findViewById(R.id.edtItemRangeFrom);
		edtItemRangeTo = (EditText) view.findViewById(R.id.edtItemRangeTo);
		searchBySpinner = (Spinner) view.findViewById(R.id.searchItemSpinner);
		chkImageBox = (CheckBox) view.findViewById(R.id.chkImages);

		edtCustomCode.setText("1001");

		gridView = (GridView) view.findViewById(R.id.itemGridView);
		progressBar = (ProgressBar) view.findViewById(R.id.progressBar);

		gridView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long which) {
				SearchImages searchImages = (SearchImages) parent
						.getItemAtPosition(position);

				showSearchImageDetailsFragment(searchImages);
			}
		});

		chkImageBox.setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean isChecked) {
				boolean isSearchByRange = "Range".equals(searchBySpinner
						.getSelectedItem().toString());

				edtCustomCode.setVisibility(isChecked ? View.GONE
						: View.VISIBLE);
				searchBySpinner.setVisibility(isChecked ? View.GONE
						: View.VISIBLE);

				if (isSearchByRange) {
					edtItemRangeFrom
					.setVisibility(isSearchByRange && isChecked ? View.GONE
							: View.VISIBLE);
					edtItemRangeTo
					.setVisibility(isSearchByRange && isChecked ? View.GONE
							: View.VISIBLE);
					edtSearchText.setVisibility(isChecked ? View.VISIBLE
							: View.GONE);
				} else {
					edtItemRangeFrom.setVisibility(View.GONE);
					edtItemRangeTo.setVisibility(View.GONE);
				}
			}
		});

		setButtonListener(view);
	}

	private void showSearchImageDetailsFragment(SearchImages searchImages) {
		SearchItemDetailsDialogFragment dialogFragment = SearchItemDetailsDialogFragment
				.newInstance(searchImages);
		dialogFragment.setTargetFragment(this, 0);
		dialogFragment
		.show(getActivity().getSupportFragmentManager(), "dialog");
	}

	private void setButtonListener(View view) {
		((Button) view.findViewById(R.id.btnSearchItem))
		.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				searchImages();
			}
		});

		((Button) view.findViewById(R.id.btnReset))
		.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				reset();
			}
		});

		searchBySpinner.setOnItemSelectedListener(new OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> parent, View view,
					int pos, long which) {

				String searchByText = (String) parent.getItemAtPosition(pos);

				if (searchByText == null)
					return;

				if ("Range".equals(searchByText)) {
					edtSearchText.setVisibility(View.GONE);
					edtItemRangeFrom.setVisibility(View.VISIBLE);
					edtItemRangeTo.setVisibility(View.VISIBLE);
				} else {
					edtSearchText.setVisibility(View.VISIBLE);
					edtItemRangeFrom.setVisibility(View.GONE);
					edtItemRangeTo.setVisibility(View.GONE);
				}
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
			}
		});
	}

	protected void reset() {
		edtCustomCode.setText("");
		edtSearchText.setText("");
		edtItemRangeFrom.setText("");
		edtItemRangeTo.setText("");
		searchBySpinner.setSelection(0);
		edtCustomCode.requestFocus();
	}

	protected void searchImages() {

		if (chkImageBox.isChecked()) {

			if (TextUtils.isEmpty(edtSearchText.getText().toString())) {
				edtSearchText.setError("Please enter item code");
				return;
			}

			FullPictureFragment.pushFragment(getActivity(), edtSearchText
					.getText().toString());
			return;
		}

		if (!isValidInput()) {
			return;
		}

		setListAdapter();
		showLoading(true);

		if (Utility.isNetworkAvailable(getActivity())) {
			searchImagesFromServer();
		} else {
			searchImagesFromLocal();
		}
	}

	private void searchImagesFromLocal() {
		String custCode = edtCustomCode.getText().toString();
		String searchString = edtSearchText.getText().toString();
		String startRange = edtItemRangeFrom.getText().toString();
		String endRange = edtItemRangeTo.getText().toString();
		String searchBy = searchBySpinner.getSelectedItem().toString();

		String selection = null;
		String selectionArg[] = null;

		CustomerInfo customerInfo = CustomerInformationDAO
				.getStoredCustomerInfo(getAppContext(), custCode);

		if (customerInfo != null) {
			if (searchBy.equals("Description")) {
				selection = StockInformationTable.COLUMN_DESCRIPTION
						+ " like ?";
				selectionArg = new String[] { "%" + searchString + "%" };
			} else if (searchBy.equals("ArtNo")) {
				selection = StockInformationTable.COLUMN_ARTICLE_NO + " Like ?";
				selectionArg = new String[] { "%" + searchString + "%" };
			} else if (searchBy.equals("BoothNo")) {
				selection = StockInformationTable.COLUMN_BOOTH_NO + " Like ?";
				selectionArg = new String[] { "%" + searchString + "%" };
			} else if (searchBy.equals("ItemCode")) {
				selection = StockInformationTable.COLUMN_ITEM_ID + " =?";
				selectionArg = new String[] { searchString };
			} else if (searchBy.equals("Range")) {
				selection = StockInformationTable.COLUMN_ITEM_ID
						+ " BETWEEN  ? AND ?";
				selectionArg = new String[] { startRange, endRange };
			}

			QueryBuilder builder = new QueryBuilder(getAppContext());
			builder.withSelection(selection);
			builder.withSelectionArg(selectionArg);

			searchItemList.clear();

			if (searchImagesTask != null) {
				searchImagesTask.cancel(true);
			}

			searchImagesTask = new SearchImagesTask();

			// Initiate asynchronous task
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
				searchImagesTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR,
						builder, customerInfo);
			} else {
				searchImagesTask.execute(builder, customerInfo);
			}
			/*
			Cursor cursor = builder.query(StockInformationTable.CONTENT_URI);


			if (cursor != null && cursor.moveToFirst()) {
				do {
					SearchImages searchImages = StockInformationDAO
							.getStockInformationFromCursor(cursor);

					if (searchImages != null) {
						searchImages.setCustomerCode(customerInfo
								.getCustomerCode());
						searchImages.setCustomerName(customerInfo
								.getCustomerName());
						searchImages.setCustomerCountry(customerInfo
								.getCustomerCountry());
						searchImages.setWholesalePrice(searchImages
								.getWholesalePrice()
			 * customerInfo.getMarkUpValue());
						searchImages.setMarkUpValue(customerInfo.getMarkUpValue());
						searchItemList.add(searchImages);
					}

				} while (cursor.moveToNext());

				cursor.close();
			} else {
				Utility.showMessage(getAppContext(), "no record found");
			}

			showLoading(false);

			Collections.sort(searchItemList, SORT_DATE);

			// bind all search item data to adapter
			imageAdapter.addAllItem(searchItemList);
			 */		} else {
				 showLoading(false);
				 Utility.showMessage(getAppContext(), "no record found");
			 }
	}

	private void searchImagesFromServer() {
		try {
			JSONObject obj = createJSONObj();

			ServiceRequest request = new ServiceRequest();
			request.setUrl(URLs.SEARCH_URL);
			request.setContentType(getString(R.string.content_type_json));
			request.setHTTPMethod(HTTPMethod.POST);
			request.setDelegate(this);
			request.setAdditionalHTTPBody(obj.toString());

			RequestTask requestTask = new RequestTask();

			// Initiate asynchronous task
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
				requestTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR,
						request);
			} else {
				requestTask.execute(request);
			}

		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	private JSONObject createJSONObj() throws JSONException {
		JSONObject jsonObject = new JSONObject();

		String searchBy = searchBySpinner.getSelectedItem().toString();

		jsonObject.put("customerCode", edtCustomCode.getText().toString());

		if (searchBy.equals("Description")) {
			jsonObject.put("searchTypeName", "byDescription");
			jsonObject.put("description", edtSearchText.getText().toString());
		} else if (searchBy.equals("ArtNo")) {
			jsonObject.put("searchTypeName", "byARTNo");
			jsonObject.put("artNo", edtSearchText.getText().toString());
		} else if (searchBy.equals("BoothNo")) {
			jsonObject.put("searchTypeName", "byBoothNo");
			jsonObject.put("boothNo", edtSearchText.getText().toString());
		} else if (searchBy.equals("ItemCode")) {
			jsonObject.put("searchTypeName", "byItemCode");
			jsonObject.put("itemcode", edtSearchText.getText().toString());
		} else if (searchBy.equals("Range")) {
			jsonObject.put("searchTypeName", "byRange");
			jsonObject.put("startItemCode", edtItemRangeFrom.getText()
					.toString());
			jsonObject.put("endItemCode", edtItemRangeTo.getText().toString());
		}

		return jsonObject;
	}

	private boolean isValidInput() {
		if (TextUtils.isEmpty(edtCustomCode.getText().toString())) {
			edtCustomCode.setError("Custom code cann't be empty");
			return false;
		}

		if (searchBySpinner.getSelectedItem().toString().equals("Range")) {
			if (TextUtils.isEmpty(edtItemRangeFrom.getText().toString())
					|| TextUtils.isEmpty(edtItemRangeTo.getText().toString())) {
				edtItemRangeFrom.setError("Please enter valid range");
				return false;
			}
		} else if (TextUtils.isEmpty(edtSearchText.getText().toString())) {
			edtSearchText.setError("Please enter search value");

			return false;
		}

		return true;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		setActionBarTitle(R.string.search_images);
		enableBackButton(getActivity());

		setListAdapter();

		showLoading(false);
	}

	private void setListAdapter() {
		imageAdapter = new ImageAdapter(getActivity());
		gridView.setAdapter(imageAdapter);
	}

	@Override
	public void onPause() {
		super.onPause();
	}

	@Override
	public void onResume() {
		super.onResume();

		// dumpData();
		// imageAdapter.addAllItem(searchItemList);
	}

	@Override
	public void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
	}

	public static SearchImagesFragment pushFragment(Context activityContext,
			Bundle bundle) {
		SearchImagesFragment fragment = new SearchImagesFragment();
		Utility.fragmentTransaction(TAG, R.id.container, fragment,
				activityContext, true);
		return fragment;
	}

	@Override
	public void onComplete(ServiceResponse serviceResponse) {

		if (!isFragmentLive(this)) {
			return;
		}

		showLoading(false);

		if (!Utility.isEmpty(serviceResponse.getErrorMsg())) {
			Utility.showAlertMessage(getActivity(),
					serviceResponse.getErrorMsg());
			return;
		}

		searchItemList.clear();

		// parse response of search
		parseSearchResponse(serviceResponse.getResponseString());

		// bind all search item data to adapter
		imageAdapter.addAllItem(searchItemList);
	}

	private void parseSearchResponse(String responseString) {
		try {
			JSONObject respJosn = new JSONObject(responseString);
			JSONObject stockJsonObject = (JSONObject) Utility
					.getJsonObjectValue(respJosn,
							Constants.PARAM_STOCK_INFORMATION_RESULT);

			if (stockJsonObject == null)
				return;
			if (!stockJsonObject.has(Constants.PARAM_FINAL_CUSTOMER_lIST))
				return;

			Object obj = Utility.getJsonObjectValue(stockJsonObject,
					Constants.PARAM_FINAL_CUSTOMER_lIST);

			if (obj instanceof JSONObject) {
				JSONObject finalCustJson = (JSONObject) obj;

				// SearchImages searchImages =
				// SearchImages.getSearchItemDataFromJSON(finalCustJson);
				SearchImages searchImages = GsonUtils.createGson().fromJson(
						finalCustJson.toString(), SearchImages.class);
				searchItemList.add(searchImages);

			} else if (obj instanceof JSONArray) {
				JSONArray finalCustArray = (JSONArray) obj;

				for (int i = 0; i < finalCustArray.length(); i++) {
					if (finalCustArray.isNull(i))
						continue;

					// SearchImages searchImages =
					// SearchImages.getSearchItemDataFromJSON(finalCustArray.getJSONObject(i));
					SearchImages searchImages = GsonUtils.createGson()
							.fromJson(
									finalCustArray.getJSONObject(i).toString(),
									SearchImages.class);
					searchItemList.add(searchImages);
				}
			}

		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	private void showLoading(boolean isLoading) {
		if (progressBar != null) {
			progressBar.setVisibility(isLoading ? View.VISIBLE : View.GONE);
		}
	}

	static class ViewHolder {
		ImageView imageView;
		ProgressBar progressBar;
		TextView itemcodeText;
		FrameLayout imageLayout;
	}

	public class ImageAdapter extends BaseAdapter {
		Context context;
		ArrayList<SearchImages> searchImgList;
		private AsyncImagePresenter asyncImagePresenter;
		private AsyncImageLoader asyncImageLoader;

		public ImageAdapter(Context context) {
			this.context = context;
			searchImgList = new ArrayList<>();
			asyncImageLoader = new AsyncImageLoader(context);
		}

		@Override
		public int getCount() {
			return searchImgList.size();
		}

		@Override
		public Object getItem(int pos) {
			return searchImgList.get(pos);
		}

		@Override
		public long getItemId(int pos) {
			return pos;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			final ViewHolder holder;
			View view = convertView;
			if (view == null) {
				LayoutInflater inflater = LayoutInflater.from(context);
				view = inflater.inflate(R.layout.list_item_grid_image_text,
						parent, false);
				holder = new ViewHolder();
				assert view != null;
				holder.imageView = (ImageView) view
						.findViewById(R.id.itemImage);
				holder.itemcodeText = (TextView) view
						.findViewById(R.id.itemCodeText);
				holder.progressBar = (ProgressBar) view
						.findViewById(R.id.progressBar);
				holder.imageLayout = (FrameLayout) view
						.findViewById(R.id.imageLayout);
				view.setTag(holder);
			} else {
				holder = (ViewHolder) view.getTag();
			}

			SearchImages searchImage = (SearchImages) getItem(position);

			holder.itemcodeText.setText(searchImage.getItemCode());

			boolean isStockEmpty = searchImage.getStockAvailable() == 0 ? true
					: false;

			// TODO :: Done New changes item 10
			if (isStockEmpty) {
				holder.itemcodeText.setTypeface(Typeface.DEFAULT_BOLD,
						Typeface.BOLD);
				holder.itemcodeText.setTextColor(Color.RED);
			} else {
				holder.itemcodeText.setTypeface(Typeface.DEFAULT);
				holder.itemcodeText.setTextColor(Color.BLACK);
			}

			// TODO :: Done new changes item 11
			boolean isLastPurDateMoreThanTwoYear = isLastPurDateMoreThanTwoYear(searchImage
					.getLastPurchaseDate()) ? true : false;
			holder.imageLayout
			.setBackgroundResource(isLastPurDateMoreThanTwoYear ? R.drawable.red_border_square_shape
					: android.R.color.transparent);

			if (searchImage.getImagePath() != null) {
				if (searchImage.getImagePath().startsWith("http")) {
					loadImageFromServerUrl(searchImage, holder);
				} else {
					loadImageFromLocal(searchImage, holder);
				}
			}

			return view;
		}

		private void loadImageFromLocal(final SearchImages searchImage,
				final ViewHolder holder) {

			asyncImageLoader.loadBitmap(searchImage.getImagePath(), holder.imageView, holder.progressBar);

			/*imageLoader.displayImage(Uri.fromFile(new File(searchImage.getImagePath())).toString(),
					holder.imageView, options,
					new SimpleImageLoadingListener() {
				@Override
				public void onLoadingStarted(String imageUri, View view) {
					holder.progressBar.setProgress(0);
					holder.progressBar.setVisibility(View.VISIBLE);
				}

				@Override
				public void onLoadingFailed(String imageUri, View view,
						FailReason failReason) {
					holder.progressBar.setVisibility(View.GONE);
				}

				@Override
				public void onLoadingComplete(String imageUri,
						View view, Bitmap loadedImage) {
					holder.progressBar.setVisibility(View.GONE);
				}
			}, new ImageLoadingProgressListener() {
				@Override
				public void onProgressUpdate(String imageUri,
						View view, int current, int total) {
					holder.progressBar.setProgress(Math.round(100.0f
			 * current / total));
				}
			});
			 */			
			/*asyncImagePresenter = new AsyncImagePresenter(getActivity(),
					holder.imageView, ScalingLogic.CROP,
					new SimpleImageLoadingListener() {
				@Override
				public void onLoadingComplete(String imageUri,
						View view, Bitmap loadedImage) {
					holder.progressBar.setVisibility(View.GONE);
				}

				@Override
				public void onLoadingFailed(String imageUri, View view,
						FailReason failReason) {
					holder.progressBar.setVisibility(View.GONE);
				}

				@Override
				public void onLoadingStarted(String imageUri, View view) {
					holder.progressBar.setProgress(0);
					holder.progressBar.setVisibility(View.VISIBLE);
				}
			});*/
		}

		private void loadImageFromServerUrl(final SearchImages searchImage,
				final ViewHolder holder) {
			imageLoader.displayImage(searchImage.getImagePath(),
					holder.imageView, options,
					new SimpleImageLoadingListener() {
				@Override
				public void onLoadingStarted(String imageUri, View view) {
					holder.progressBar.setProgress(0);
					holder.progressBar.setVisibility(View.VISIBLE);
				}

				@Override
				public void onLoadingFailed(String imageUri, View view,
						FailReason failReason) {
					holder.progressBar.setVisibility(View.GONE);
				}

				@Override
				public void onLoadingComplete(String imageUri,
						View view, Bitmap loadedImage) {
					holder.progressBar.setVisibility(View.GONE);
				}
			}, new ImageLoadingProgressListener() {
				@Override
				public void onProgressUpdate(String imageUri,
						View view, int current, int total) {
					holder.progressBar.setProgress(Math.round(100.0f
							* current / total));
				}
			});

		}

		public void addItem(SearchImages images) {
			this.searchImgList.clear();
			searchImgList.add(images);
			this.notifyDataSetChanged();
		}

		public void addAllItem(ArrayList<SearchImages> list) {
			this.searchImgList.clear();
			searchImgList.addAll(list);
			this.notifyDataSetChanged();
		}
	}

	private void dumpData() {
		String searchJson = getString(R.string.dummy_data_json);

		JSONObject finalCustJson;
		try {
			finalCustJson = new JSONObject(searchJson);
			// SearchImages searchImages =
			// SearchImages.getSearchItemDataFromJSON(finalCustJson);
			SearchImages searchImages = GsonUtils.createGson().fromJson(
					finalCustJson.toString(), SearchImages.class);
			searchItemList.add(searchImages);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static class SearchItemDetailsDialogFragment extends
	android.support.v4.app.DialogFragment {

		private SearchImages searchImages;

		public static SearchItemDetailsDialogFragment newInstance(
				SearchImages searchImages) {
			SearchItemDetailsDialogFragment listDialogFragment = new SearchItemDetailsDialogFragment();
			Bundle args = new Bundle();
			args.putParcelable(Constants.EXTRA_SEARCH_IMAGE_DETAILS,
					searchImages);
			listDialogFragment.setArguments(args);
			return listDialogFragment;
		}

		@Override
		public void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);

			if (this.getArguments() != null) {
				searchImages = (SearchImages) (this.getArguments().containsKey(
						Constants.EXTRA_SEARCH_IMAGE_DETAILS) ? this
								.getArguments().getParcelable(
										Constants.EXTRA_SEARCH_IMAGE_DETAILS)
										: searchImages);
			}

			if (searchImages == null) {
				dismiss();
				return;
			}

		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			getDialog().setTitle("Details");
			View view = inflater.inflate(R.layout.search_item_details_layout,
					container, false);
			bindView(view);
			return view;
		}

		private void bindView(View view) {

			((TextView) view.findViewById(R.id.itemCode)).setText(formatString(
					"ItemCode: ", searchImages.getItemCode()));
			((TextView) view.findViewById(R.id.barcode)).setText(formatString(
					"Barcode: ", searchImages.getBarcode()));
			((TextView) view.findViewById(R.id.articleNo))
			.setText(formatString("Article No: ",
					searchImages.getArticleNo()));
			((TextView) view.findViewById(R.id.description))
			.setText(formatString("Description: ",
					searchImages.getDescription()));
			((TextView) view.findViewById(R.id.boothNo)).setText(formatString(
					"Booth No: ", searchImages.getBoothNo()));
			((TextView) view.findViewById(R.id.packing)).setText(formatString(
					"Packing No: ", searchImages.getPacking()));
			((TextView) view.findViewById(R.id.brand)).setText(formatString(
					"Brand: ", searchImages.getBrand()));
			((TextView) view.findViewById(R.id.colour)).setText(formatString(
					"Colour : ", searchImages.getColour()));
			((TextView) view.findViewById(R.id.weight)).setText(formatString(
					"Weight: ", searchImages.getWeight()));
			((TextView) view.findViewById(R.id.measurement))
			.setText(formatString("Measurement: ",
					searchImages.getMeasurement()));
			((TextView) view.findViewById(R.id.origin)).setText(formatString(
					"Origin: ", searchImages.getOrigin()));
			((TextView) view.findViewById(R.id.size)).setText(formatString(
					"Size: ", searchImages.getSize()));
			((TextView) view.findViewById(R.id.puchasePrice))
			.setText(formatString("Purchase Price: ",
					String.valueOf(searchImages.getPuchasePrice())));
			// ((TextView)view.findViewById(R.id.orderDate)).setText(formatString("Order Date: ",
			// searchImages.getOrderDate()));
			((TextView) view.findViewById(R.id.currency)).setText(formatString(
					"Currency: ", String.valueOf(searchImages.getCurrency())));

			((TextView) view.findViewById(R.id.customerCode))
			.setText(formatString("Customer Code: ",
					searchImages.getCustomerCode()));
			((TextView) view.findViewById(R.id.customerCountry))
			.setText(formatString("Customer Country: ",
					searchImages.getCustomerCountry()));
			((TextView) view.findViewById(R.id.customerName))
			.setText(formatString("Customer Name: ",
					searchImages.getCustomerName()));
			((TextView) view.findViewById(R.id.lastArrivalQuantity))
			.setText(formatString("Last Arriaval Quantity: ", String
					.valueOf(searchImages.getLastArrivalQuantity())));
			((TextView) view.findViewById(R.id.lastOrderDate))
			.setText(formatString("Last Order Date: ",
					searchImages.getLastOrderDate()));
			((TextView) view.findViewById(R.id.lastPurchaseDate))
			.setText(formatString("Last Purchase Date: ",
					searchImages.getLastPurchaseDate()));
			((TextView) view.findViewById(R.id.lastSellDate))
			.setText(formatString("Last Sell Date: ",
					searchImages.getLastSellDate()));
			((TextView) view.findViewById(R.id.markUpValue))
			.setText(formatString("MarkUp Value: ",
					String.valueOf(searchImages.getMarkUpValue())));

			((TextView) view.findViewById(R.id.perPiecePrice))
			.setText(formatString("Per Piece Price: ",
					String.valueOf(searchImages.getPerPiecePrice() * searchImages.getMarkUpValue())));
			((TextView) view.findViewById(R.id.creditPrice))
			.setText(formatString("Credit Price: ",
					String.valueOf(searchImages.getCreditPrice())));
			((TextView) view.findViewById(R.id.stockAvailable))
			.setText(formatString("Stock Available: ",
					String.valueOf(searchImages.getStockAvailable())));
			((TextView) view.findViewById(R.id.wholesalePrice))
			.setText(formatString("Whole Sale Price: ",
					String.valueOf(searchImages.getWholesalePrice())));

			setItemImage(((ImageView) view.findViewById(R.id.itemImage)));

			boolean isAdmin = Utility.isAdminUser(getActivity());

			((TextView) view.findViewById(R.id.puchasePrice)).setVisibility(isAdmin ? View.VISIBLE : View.GONE);
			((TextView) view.findViewById(R.id.currency)).setVisibility(isAdmin ? View.VISIBLE : View.GONE);
			((TextView) view.findViewById(R.id.boothNo)).setVisibility(isAdmin ? View.VISIBLE : View.GONE);

		}

		private void setItemImage(ImageView imageView) {
			if (imageView == null
					|| TextUtils.isEmpty(searchImages.getImagePath())) {
				return;
			}

			if (searchImages.getImagePath().startsWith("http")) {
				ImageLoader.getInstance().displayImage(
						searchImages.getImagePath(), imageView, options);
			} else {
				loadImageFromLocal(searchImages, imageView);
			}
		}

		private void loadImageFromLocal(final SearchImages searchImage,
				ImageView imageView) {

			AsyncImageLoader asyncImageLoader = new AsyncImageLoader(getActivity());
			asyncImageLoader.loadBitmap(searchImage.getImagePath(), imageView, null);
			/*AsyncImagePresenter asyncImagePresenter = new AsyncImagePresenter(
					getActivity(), imageView, ScalingLogic.CROP,
					new SimpleImageLoadingListener() {
						@Override
						public void onLoadingComplete(String imageUri,
								View view, Bitmap loadedImage) {
						}

						@Override
						public void onLoadingFailed(String imageUri, View view,
								FailReason failReason) {
						}

						@Override
						public void onLoadingStarted(String imageUri, View view) {
						}
					});

			asyncImagePresenter.executeOnExecutor(
					AsyncImagePresenter.THREAD_POOL_EXECUTOR, searchImage);
			 */		}

		@Override
		public void onActivityCreated(Bundle savedInstanceState) {
			super.onActivityCreated(savedInstanceState);

		}

		private void fetchStockFromItemID() {
			String itemID = "";
			SearchImages searchImages = StockInformationDAO.getStoredStockInfo(
					getActivity(), itemID);
			if (searchImages != null) {
				SearchItemDetailsDialogFragment dialogFragment = SearchItemDetailsDialogFragment
						.newInstance(searchImages);
				dialogFragment.setTargetFragment(this, 0);
				dialogFragment.show(getActivity().getSupportFragmentManager(),
						"dialog");
			}
		}
	}

	private static String getValidString(String str) {
		if (TextUtils.isEmpty(str)) {
			return "";
		}

		return str;
	}

	public static String formatString(String fmtStr, String args) {
		return String.format(fmtStr + " %s", getValidString(args));
	}

	private boolean isLastPurDateMoreThanTwoYear(String lastPurDate) {
		if (TextUtils.isEmpty(lastPurDate))
			return false;

		Date lastDate = Utility.convertStringDateToDateFormat(lastPurDate);
		// Date curDate =
		// Utility.convertStringDateToDateFormat(Utility.getFormattedDate(Constants.LOCAL_DATE_PATTERN,
		// Utility.getCurTime()), Constants.LOCAL_DATE_PATTERN);

		if (lastDate == null) {
			return false;
		}

		Calendar lastDate2 = Calendar.getInstance();
		lastDate2.setTime(lastDate);

		Calendar curDate2 = Calendar.getInstance();
		curDate2.setTimeInMillis(Utility.getCurTime());

		int curYear = curDate2.get(Calendar.YEAR);
		int lastYear = lastDate2.get(Calendar.YEAR);

		int year = curYear - lastYear;

		if (year > 2) {
			return true;
		}

		return false;
	}

	private Comparator<SearchImages> SORT_DATE = new Comparator<SearchImages>() {
		@Override
		public int compare(SearchImages image1, SearchImages image2) {

			Date date1 = Utility.convertStringDateToDateFormat(image1
					.getLastPurchaseDate());
			Date date2 = Utility.convertStringDateToDateFormat(image2
					.getLastPurchaseDate());

			if (date1 == null || date2 == null)
				return -1;

			if (date1.after(date2)) {
				return 1;
			} else if (date1.before(date2)) {
				return -1;
			} else if (date1.equals(date2)) {
				return 0;
			}

			return -1;
		}
	};


	class SearchImagesTask extends AsyncTask<Object, Void, ArrayList<SearchImages>> {

		@Override
		protected ArrayList<SearchImages> doInBackground(Object... params) {
			QueryBuilder builder = (QueryBuilder) params[0];
			CustomerInfo customerInfo = (CustomerInfo) params[1];

			Cursor cursor = builder.query(StockInformationTable.CONTENT_URI);

			if (cursor != null && cursor.moveToFirst()) {
				do {
					SearchImages searchImages = StockInformationDAO
							.getStockInformationFromCursor(cursor);

					if (searchImages != null) {
						searchImages.setCustomerCode(customerInfo
								.getCustomerCode());
						searchImages.setCustomerName(customerInfo
								.getCustomerName());
						searchImages.setCustomerCountry(customerInfo
								.getCustomerCountry());
						searchImages.setWholesalePrice(searchImages
								.getWholesalePrice()
								* customerInfo.getMarkUpValue());
						searchImages.setMarkUpValue(customerInfo.getMarkUpValue());
						searchItemList.add(searchImages);
					}

				} while (cursor.moveToNext());

				cursor.close();
			}

			return searchItemList;
		}

		@Override
		protected void onPostExecute(ArrayList<SearchImages> result) {

			if (!isVisible()) return;

			showLoading(false);

			if (searchItemList.isEmpty()) {
				Utility.showMessage(getAppContext(), "no record found");
			} else {
				//Collections.sort(searchItemList, SORT_DATE);

				// bind all search item data to adapter
				imageAdapter.addAllItem(searchItemList);
			}
		}
	}

}
