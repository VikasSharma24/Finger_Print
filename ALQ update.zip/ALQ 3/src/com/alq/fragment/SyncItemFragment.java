package com.alq.fragment;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;

import com.alq.R;
import com.alq.constant.Constants;
import com.alq.delegates.IWebRequestDelegate;
import com.alq.services.ServiceRequest;
import com.alq.services.model.CustomerInfoRequest;
import com.alq.services.model.DownloadImageRequest;
import com.alq.services.model.StockInfoRequest;
import com.alq.utils.LogUtility;
import com.alq.utils.PrefsUtility;
import com.alq.utils.Utility;

public class SyncItemFragment extends BaseFragment implements OnClickListener, IWebRequestDelegate {

	public static final String TAG = SyncItemFragment.class.getSimpleName();
	private ProgressDialog progressDialog;
	private static Handler handler;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setHasOptionsMenu(true);
		setRetainInstance(true);
		handler = new Handler(Looper.getMainLooper());
	}

	@Override
	public View onCreateView(LayoutInflater inflater,
			@Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.sync_item_layout, container, false);
		initView(view);
		return view;
	}

	private void initView(View view) {
		((Button) view.findViewById(R.id.buttonSyncStockInfo)).setOnClickListener(this);
		((Button) view.findViewById(R.id.buttonSyncCustInfo)).setOnClickListener(this);
		((Button) view.findViewById(R.id.buttonSyncImages)).setOnClickListener(this);
		
		((Button) view.findViewById(R.id.buttonSyncStockInfo)).setText(String.format("Get All Stock Information (%s)", PrefsUtility.getInstance().getSyncStockValue()));
		
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

		setActionBarTitle("Synchronize");
		enableBackButton(getActivity());
		
		setButtonText();
	}
	
	private void setButtonText() {
		if (getView() == null) return;
		((Button) getView().findViewById(R.id.buttonSyncStockInfo)).setText(String.format("Get All Stock Information (%s)", PrefsUtility.getInstance().getSyncStockValue()));
		
		if (PrefsUtility.getInstance().getLastSyncStockDate() > 0) {
			((Button) getView().findViewById(R.id.buttonSyncStockInfo)).setText(String.format("Get All Stock Information (%s) \n (%s)", PrefsUtility.getInstance().getSyncStockValue(),
					Utility.getFormattedDate(Constants.LOCAL_DATE_PATTERN, PrefsUtility.getInstance().getLastSyncStockDate())));
		}
		
		if (PrefsUtility.getInstance().getLastSyncCustDate() > 0) {
			((Button) getView().findViewById(R.id.buttonSyncCustInfo)).setText(String.format("Get All Customer Information  \n (%s)", 
					Utility.getFormattedDate(Constants.LOCAL_DATE_PATTERN, PrefsUtility.getInstance().getLastSyncCustDate())));
		}
		
		if (PrefsUtility.getInstance().getLastDownloadImageDate() > 0) {
			((Button) getView().findViewById(R.id.buttonSyncImages)).setText(String.format("Download Images  \n (%s)", 
					Utility.getFormattedDate(Constants.LOCAL_DATE_PATTERN, PrefsUtility.getInstance().getLastDownloadImageDate())));
		}
		
	}

	@Override
	public void onResume() {
		super.onResume();
	}

	public static SyncItemFragment pushFragment(Context context, boolean addToBackStack) {
		SyncItemFragment fragment = new SyncItemFragment();
		Utility.fragmentTransaction(TAG, R.id.container, fragment, context, addToBackStack);
		return fragment;
	}

	@Override
	public void onClick(View arg0) {
		int id = arg0.getId();

		switch (id) {
		case R.id.buttonSyncStockInfo:
			//showProgressDialog(true);
			actionOnSyncStockInfo();
			break;
		case R.id.buttonSyncCustInfo:
			showProgressDialog(true);
			syncCustomerInformation();
			break;
		case R.id.buttonSyncImages:
			showProgressDialog(true);
			downloadImagesFromServer();
			break;

		default:
			break;
		}
	}
	
	private void actionOnSyncStockInfo() {
		if (PrefsUtility.getInstance().isStockDownloaded()) {
			showUpdateOrGetAllSyncConfirmDialog();
			return;
		}
		
		syncStockInformation(PrefsUtility.getInstance().getSyncStockValue());
	}

	private void showUpdateOrGetAllSyncConfirmDialog() {
		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
		builder.setCancelable(true);

		builder.setPositiveButton("Get All Stock Information", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
				PrefsUtility.getInstance().setSyncStockValue(0);
				PrefsUtility.getInstance().setStockDownloaded(false);
				syncStockInformation(PrefsUtility.getInstance().getSyncStockValue());
			}
		});
		builder.setNegativeButton("Only Updates", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
				syncStockInformation(PrefsUtility.getInstance().getSyncStockValue());
			}
		});
		
		builder.setMessage("Are you want to update or get all stock information?");
		builder.create().show();
	}

	@Override
	public void onWebRequestFailure(String errMsg, String tag, ServiceRequest request) {
		if (isVisible() && getActivity() != null) {
			showProgressDialog(false);
		}
		
		if (request instanceof StockInfoRequest) {
			if (PrefsUtility.getInstance().isStockDownloaded()) {
				//PrefsUtility.getInstance().setSyncStockValue(0);
				return;
			}
			
			handler.postDelayed(new Runnable() {
				@Override
				public void run() {
					syncStockInformation(PrefsUtility.getInstance().getSyncStockValue());					
				}
			}, 1000);
		}
	
	}
	
	@Override
	public void onWebRequestSuccess(String tag, ServiceRequest request) {
		if (isVisible() && getActivity() != null) {
			showProgressDialog(false);
			setButtonText();
		}
		
		if (request instanceof StockInfoRequest) {
			
			if (PrefsUtility.getInstance().isStockDownloaded()) {
				if (isVisible() && getActivity() != null) {
					Utility.showAlertMessage(getActivity(), "Sync stock information completed");
				}
				//Utility.showMessage(getAppContext(), "Sync stock information completed");
				//PrefsUtility.getInstance().setSyncStockValue(0);
				return;
			}
			
			handler.postDelayed(new Runnable() {
				@Override
				public void run() {
					syncStockInformation(PrefsUtility.getInstance().getSyncStockValue());					
				}
			}, 1000);
			
		} 
	}

	/**
	 * Show/Dismiss progress dialog according to provided status
	 * 
	 * @param isShow
	 */
	private void showProgressDialog(boolean isShow) {
		try {
			if (progressDialog == null) {

				progressDialog = new ProgressDialog(getActivity());
				progressDialog
				.setMessage("Please wait...");
				progressDialog.setCancelable(false);
				progressDialog.setCanceledOnTouchOutside(false);
			}

			if (isShow) {
				if (!progressDialog.isShowing())
					progressDialog.show();
			} else {
				if (progressDialog.isShowing())
					progressDialog.dismiss();
			}
		} catch (Exception ex) {
			LogUtility
			.printErrorMessage("ReportAnIssueFragment : showProgressDialog "
					+ isShow + " Exception occured " + ex.getMessage());
		}
	}
	
	private void syncStockInformation(int value) {
		if (!Utility.isNetworkAvailable(getAppContext())) {
			Utility.showMessage(getAppContext(), R.string.no_network_connection_available);
			showProgressDialog(false);
			return;
		}
		
		StockInfoRequest request = new StockInfoRequest(getAppContext(), this);
		request.initWebRequest();
		JSONObject jsonObject = new JSONObject(); 
		try {
			jsonObject.put("stockSyncValue", String.valueOf(value));
		} catch (JSONException e) {
			e.printStackTrace();
		}
		request.setAdditionalHTTPBody(jsonObject.toString());
		request.invoke();
	}
	
	private void syncCustomerInformation() {
		if (!Utility.isNetworkAvailable(getAppContext())) {
			Utility.showMessage(getAppContext(), R.string.no_network_connection_available);
			showProgressDialog(false);
			return;
		}
		
		CustomerInfoRequest request = new CustomerInfoRequest(getAppContext(), this);
		request.initWebRequest();
		request.invoke();
	}
	
	private void downloadImagesFromServer() {
		if (!Utility.isNetworkAvailable(getAppContext())) {
			Utility.showMessage(getAppContext(), R.string.no_network_connection_available);
			showProgressDialog(false);
			return;
		}
		
		DownloadImageRequest request = new DownloadImageRequest(getAppContext(), this);
		request.initWebRequest();
		JSONObject jsonObject = new  JSONObject();
		
		try {
			jsonObject.put(Constants.PARAM_DOWNLOAD_IMAGE_SYNC_DATE, PrefsUtility.getInstance().getSyncDownloadImagesDate());
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
		request.setAdditionalHTTPBody(jsonObject.toString());
		request.invoke();
	}

}
