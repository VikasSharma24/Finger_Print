package com.alq.fragment;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;

import com.alq.R;
import com.alq.model.SearchImages;
import com.alq.model.dao.StockInformationDAO;
import com.alq.sync.AsyncImageLoader;
import com.alq.utils.Utility;
import com.nostra13.universalimageloader.core.ImageLoader;

public class StockFragment extends BaseFragment {
	public static final String TAG = StockFragment.class.getSimpleName();

	Button previousButton;
	Button nextButton;
	EditText searchEditText;

	private SearchImages stockinfo;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setHasOptionsMenu(true);
		setRetainInstance(true);
	}

	@Override
	public View onCreateView(LayoutInflater inflater,
			ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_stock_information,
				container, false);
		initView(view);
		return view;
	}

	private void initView(View view) {
		searchEditText = (EditText) view.findViewById(R.id.searchEdit);
		previousButton = (Button) view.findViewById(R.id.previousButton);
		nextButton = (Button) view.findViewById(R.id.nextButton);
		
		previousButton.setEnabled(false);
		nextButton.setEnabled(false);

		setButtonListener();
	}
	
	private void loadData() {
		stockinfo = StockInformationDAO.getStoredStockInfo(getAppContext(), 1);
		if (stockinfo == null) return;
		previousButton.setEnabled(true);
		nextButton.setEnabled(true);
		
		searchEditText.setText(stockinfo.getItemCode());
		
		bindView(stockinfo);
	}
	

	private void setButtonListener() {
		previousButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				fetchNextOrPreviousStockInfor(true);
			}
		});

		nextButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				fetchNextOrPreviousStockInfor(false);
			}
		});
		
		searchEditText.setOnEditorActionListener(editorActionListener);
	}
	
	private OnEditorActionListener editorActionListener = new OnEditorActionListener() {
		@Override
		public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {

			if (event == null) {
				if (actionId == EditorInfo.IME_ACTION_DONE) {
					performActionDone();
				}
			} else if(event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER) {
				performActionDone();
				return true;

			}
			return false;
		}
	};
	
	private void performActionDone() {
		String searchText = searchEditText.getText().toString();
		if (TextUtils.isEmpty(searchText)) {
			return;
		}

		stockinfo = StockInformationDAO.getStoredStockInfo(getAppContext(), searchText);
		if (stockinfo == null) {
			Utility.showAlertMessage(getActivity(), "No record found");
			return;
		}

		bindView(stockinfo);
		nextButton.setEnabled(true);

	}

	private void fetchNextOrPreviousStockInfor(boolean isPrevious) {
		long rowId;

		if (stockinfo == null) {
			return;
		}

		previousButton.setEnabled((stockinfo.getRowId() < 0) ? false : true);

		if (isPrevious) {
			rowId = stockinfo.getRowId() - 1;
		} else {
			rowId = stockinfo.getRowId() + 1;
		}

		SearchImages stockinform = StockInformationDAO.getStoredStockInfo(getAppContext(), rowId);
		if (stockinform == null) {
			Utility.showAlertMessage(getActivity(), "No record found");
			return;
		}
		
		stockinfo = stockinform;

		searchEditText.setText(stockinfo.getItemCode());
		bindView(stockinfo);
		
	}

	private void bindView(SearchImages searchImages) {
		if (getView() == null) {
			return ;
		}

		View view = getView();

		((TextView)view.findViewById(R.id.itemCode)).setText(formatString("ItemCode: ", searchImages.getItemCode()));
		((TextView)view.findViewById(R.id.barcode)).setText(formatString("Barcode: ", searchImages.getBarcode()));
		((TextView)view.findViewById(R.id.articleNo)).setText(formatString("Article No: ", searchImages.getArticleNo()));
		((TextView)view.findViewById(R.id.description)).setText(formatString("Description: ", searchImages.getDescription()));
		((TextView)view.findViewById(R.id.boothNo)).setText(formatString("Booth No: ", searchImages.getBoothNo()));
		((TextView)view.findViewById(R.id.packing)).setText(formatString("Packing No: ", searchImages.getPacking()));
		((TextView)view.findViewById(R.id.brand)).setText(formatString("Brand: ", searchImages.getBrand()));
		((TextView)view.findViewById(R.id.colour)).setText(formatString("Colour : ", searchImages.getColour()));
		((TextView)view.findViewById(R.id.weight)).setText(formatString("Weight: ", searchImages.getWeight()));
		((TextView)view.findViewById(R.id.measurement)).setText(formatString("Measurement: ", searchImages.getMeasurement()));
		((TextView)view.findViewById(R.id.origin)).setText(formatString("Origin: ", searchImages.getOrigin()));
		((TextView)view.findViewById(R.id.size)).setText(formatString("Size: ", searchImages.getSize()));
		((TextView)view.findViewById(R.id.puchasePrice)).setText(formatString("Purchase Price: ", String.valueOf(searchImages.getPuchasePrice())));
		//((TextView)view.findViewById(R.id.orderDate)).setText(formatString("Order Date: ", searchImages.getOrderDate()));
		((TextView)view.findViewById(R.id.currency)).setText(formatString("Currency: ", String.valueOf(searchImages.getCurrency())));

		((TextView)view.findViewById(R.id.customerCode)).setText(formatString("Customer Code: ", searchImages.getCustomerCode()));
		((TextView)view.findViewById(R.id.customerCountry)).setText(formatString("Customer Country: ", searchImages.getCustomerCountry()));
		((TextView)view.findViewById(R.id.customerName)).setText(formatString("Customer Name: ", searchImages.getCustomerName()));
		((TextView)view.findViewById(R.id.lastArrivalQuantity)).setText(formatString("Last Arriaval Quantity: ", String.valueOf(searchImages.getLastArrivalQuantity())));
		((TextView)view.findViewById(R.id.lastOrderDate)).setText(formatString("Last Order Date: ", searchImages.getLastOrderDate()));
		((TextView)view.findViewById(R.id.lastPurchaseDate)).setText(formatString("Last Purchase Date: ", searchImages.getLastPurchaseDate()));
		((TextView)view.findViewById(R.id.lastSellDate)).setText(formatString("Last Sell Date: ", searchImages.getLastSellDate()));
		((TextView)view.findViewById(R.id.markUpValue)).setText(formatString("MarkUp Value: ", String.valueOf(searchImages.getMarkUpValue())));

		((TextView)view.findViewById(R.id.perPiecePrice)).setText(formatString("Per Piece Price: ", String.valueOf(searchImages.getPerPiecePrice())));
		((TextView)view.findViewById(R.id.creditPrice)).setText(formatString("Credit Price: ", String.valueOf(searchImages.getCreditPrice())));
		((TextView)view.findViewById(R.id.stockAvailable)).setText(formatString("Stock Available: ", String.valueOf(searchImages.getStockAvailable())));
		((TextView)view.findViewById(R.id.wholesalePrice)).setText(formatString("Whole Sale Price: ", String.valueOf(searchImages.getWholesalePrice())));
		
		boolean isAdmin = Utility.isAdminUser(getActivity());

		((TextView) view.findViewById(R.id.puchasePrice)).setVisibility(isAdmin ? View.VISIBLE : View.GONE);
		((TextView) view.findViewById(R.id.currency)).setVisibility(isAdmin ? View.VISIBLE : View.GONE);
		((TextView) view.findViewById(R.id.boothNo)).setVisibility(isAdmin ? View.VISIBLE : View.GONE);
		
		setItemImage(searchImages, ((ImageView)view.findViewById(R.id.itemImage)));
	}

	private void setItemImage(SearchImages searchImages, ImageView imageView) {
		if (imageView == null
				|| TextUtils.isEmpty(searchImages.getImagePath())) {
			return;
		}

		AsyncImageLoader asyncImageLoader = new AsyncImageLoader(getActivity());
		asyncImageLoader.loadBitmap(searchImages.getImagePath(), imageView, null);
	}

	
	
	private String formatString(String field, String value) {
		return	SearchImagesFragment.formatString(field, value);
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

		setActionBarTitle(R.string.stock_information);
		enableBackButton(getActivity());
		
		loadData();
	}

	@Override
	public void onResume() {
		super.onResume();
	}


	public static StockFragment pushFragment(Context context, boolean addToBackStack) {
		StockFragment fragment = new StockFragment();
		Utility.fragmentTransaction(TAG, R.id.container, fragment, context, addToBackStack);
		return fragment;
	}
}
