package com.alq.fragment;

import java.util.Calendar;

import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.Dialog;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import android.view.View;
import android.widget.DatePicker;

public class DatePickerDialogFragment extends DialogFragment implements OnDateSetListener {
	public static final String TAG = DatePickerDialogFragment.class.getSimpleName();
	private View view;
	
	OnDateSetListener listener;
	
	public void setOnDateSetListener(OnDateSetListener listener) {
		this.listener = listener;
	}
	
	
	@Override
	@NonNull
	public Dialog onCreateDialog(Bundle savedInstanceState) {
		
		Calendar calendar = Calendar.getInstance();
		
		int year = calendar.get(Calendar.YEAR);
		int monthOfYear = calendar.get(Calendar.MONTH);
		int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
		
		
		return new DatePickerDialog(getActivity(), this, year, monthOfYear, dayOfMonth);
	}
	
	public void setSrcView(View v) {
		this.view = v;
	}
	

	@Override
	public void onDateSet(DatePicker dp, int arg1, int arg2, int arg3) {
		dp.setTag(view);
		
		if (listener != null) {
			listener.onDateSet(dp, arg1, arg2, arg3);
		}
	}

}
