package com.alq.fragment;

import java.io.File;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.alq.R;
import com.alq.model.SearchImages;
import com.alq.model.dao.StockInformationDAO;
import com.alq.utils.Utility;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingProgressListener;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;

public class FullPictureFragment extends BaseFragment implements View.OnClickListener {
	
	public static final String TAG = FullPictureFragment.class.getSimpleName();

	private ImageView fullImageView;
	private ProgressBar progressBar;
	private Button btnNext;
	private Button btnPrev;
	private TextView txtItemCode;
	private String itemCode;

	public static final String EXTRA_ITEM_CODE = "extra_item_code";

	private SearchImages stockInfo;
	private ImageLoader imageLoader;


	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setRetainInstance(true);
		setHasOptionsMenu(true);

		if (this.getArguments() != null) {
			itemCode = this.getArguments().containsKey(EXTRA_ITEM_CODE)? this.getArguments().getString(EXTRA_ITEM_CODE) : null;
		}

		if (itemCode == null) {
			Utility.showMessage(getAppContext(), "no record found");
			return;
		}
		
		setDisplayImageOptions();
		imageLoader = ImageLoader.getInstance();
	}

	@Override
	public View onCreateView(LayoutInflater inflater,
			@Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.full_image_view_layout, container, false);

		initView(view);
		return view;
	}

	private void initView(View view) {
		fullImageView = (ImageView) view.findViewById(R.id.full_image_view);
		progressBar = (ProgressBar) view.findViewById(R.id.progress_bar_view);
		txtItemCode = (TextView) view.findViewById(R.id.txtItemCode);
		btnNext = (Button) view.findViewById(R.id.buttonNext);
		btnPrev = (Button) view.findViewById(R.id.buttonPrevious);

		btnNext.setOnClickListener(this);
		btnPrev.setOnClickListener(this);
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		
		enableBackButton(getActivity());
		
		bindData();
	}

	@Override
	public void onClick(View view) {
		switch (view.getId()) {
		case R.id.buttonNext:
			findNextOrPreviousImages(false);
			break;
		case R.id.buttonPrevious:
			findNextOrPreviousImages(true);
			break;
		default:
			break;
		}
	}


	private void findNextOrPreviousImages(boolean isPrevious) {
		long rowId;

		if (stockInfo == null) {
			return;
		}

		if (isPrevious) {
			rowId = stockInfo.getRowId() - 1;
		} else {
			rowId = stockInfo.getRowId() + 1;
		}

		SearchImages stockinform = StockInformationDAO.getStoredStockInfo(getAppContext(), rowId);
		if (stockinform == null) {
			Utility.showAlertMessage(getActivity(), "No record found");
			return;
		}

		stockInfo = stockinform;
		setFullImage();
	}

	private void bindData() {
		if (itemCode != null) {

			stockInfo = StockInformationDAO.getStoredStockInfo(getAppContext(), itemCode);
			if (stockInfo == null) {
				Utility.showAlertMessage(getActivity(), "No record found");
				return;
			}
			
			setFullImage();
		}
	}

	private void setFullImage() {

		if (stockInfo == null) return;
		
		txtItemCode.setText(stockInfo.getItemCode());

		progressBar.setVisibility(View.VISIBLE);
		/*
		AsyncImagePresenter presenter = new AsyncImagePresenter(getActivity(), fullImageView, ScalingLogic.FIT, new SimpleImageLoadingListener() {
			@Override
			public void onLoadingComplete(String imageUri, View view,
					Bitmap loadedImage) {
				progressBar.setVisibility(View.GONE);
			}
			
			@Override
			public void onLoadingStarted(String imageUri, View view) {
			}
			
			@Override
			public void onLoadingFailed(String imageUri, View view,
					FailReason failReason) {
				progressBar.setVisibility(View.GONE);
			}
		}); 

		presenter.executeOnExecutor(AsyncImagePresenter.THREAD_POOL_EXECUTOR, stockInfo);
*/		
		imageLoader.displayImage(Uri.fromFile(new File(stockInfo.getImagePath())).toString(),
				fullImageView, options,
				new SimpleImageLoadingListener() {
					@Override
					public void onLoadingStarted(String imageUri, View view) {
						progressBar.setVisibility(View.VISIBLE);
					}

					@Override
					public void onLoadingFailed(String imageUri, View view,
							FailReason failReason) {
						progressBar.setVisibility(View.GONE);
						fullImageView.setImageResource(R.drawable.ic_empty);
					}

					@Override
					public void onLoadingComplete(String imageUri,
							View view, Bitmap loadedImage) {
						progressBar.setVisibility(View.GONE);
					}
				}, new ImageLoadingProgressListener() {
					@Override
					public void onProgressUpdate(String imageUri,
							View view, int current, int total) {
					}
				});


	}

	
	public static FullPictureFragment pushFragment(Context context, String itemcode) {
		FullPictureFragment fragment = new FullPictureFragment();
		Bundle bundle = new Bundle();
		bundle.putString(EXTRA_ITEM_CODE, itemcode);
		fragment.setArguments(bundle);
		Utility.fragmentTransaction(TAG, R.id.container, fragment, context, true);
		return fragment;
	}
}

