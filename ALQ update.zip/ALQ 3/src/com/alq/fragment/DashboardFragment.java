package com.alq.fragment;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.TextView;

import com.alq.R;
import com.alq.utils.Utility;

public class DashboardFragment extends BaseFragment implements OnClickListener {
	public static final String TAG = DashboardFragment.class.getSimpleName();

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setHasOptionsMenu(false);
		setRetainInstance(true);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_dashboard, container, false);
		initView(view);
		return view;
	}

	private void initView(View view) {
		((TextView)view.findViewById(R.id.captureImagesTextView)).setOnClickListener(this);
		((TextView)view.findViewById(R.id.searchImagesTextView)).setOnClickListener(this);
		((TextView)view.findViewById(R.id.exportToExcelTextView)).setOnClickListener(this);
		((TextView)view.findViewById(R.id.stockInformationTextView)).setOnClickListener(this);
		((TextView)view.findViewById(R.id.synchronizeTextView)).setOnClickListener(this);
	}

	public static DashboardFragment pushFragment(Context activityContext, Bundle bundle) {
		DashboardFragment fragment = new DashboardFragment();
		Utility.fragmentTransaction(TAG, R.id.container, fragment, activityContext, true);
		return fragment;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		
		setActionBarTitle(R.string.dashboard);
	}

	@Override
	public void onResume() {
		super.onResume();
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();

		switch (id) {
		case R.id.captureImagesTextView:
			if (!Utility.isAdminUser(getAppContext())) {
				Utility.showAlertMessage(getActivity(), "You do not have permissions to access this functionality");
				return;
			}
			CaptureImageFragment.pushFragment(getActivity(), null, true);
			break;
		case R.id.searchImagesTextView:
			SearchImagesFragment.pushFragment(getActivity(), null);
			break;
		case R.id.exportToExcelTextView:
			ExportToExcelFragment.pushFragment(getActivity(), null);
			break;
		case R.id.synchronizeTextView:
			SyncItemFragment.pushFragment(getActivity(), true);
			break;
		case R.id.stockInformationTextView:
			StockFragment.pushFragment(getActivity(), true);
			break;
		default:
			break;
		}
	}
	
	private void sync() {
		Utility.showMessage(getAppContext(), "Sync started");
		setupExcelDataRequests();
		startSync();
	}

}
