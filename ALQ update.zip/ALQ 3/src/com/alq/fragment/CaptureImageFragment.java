package com.alq.fragment;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import com.alq.R;
import com.alq.constant.Constants;
import com.alq.constant.Constants.URLs;
import com.alq.delegates.IFileUploadProgressModelDelegate;
import com.alq.delegates.IServiceDelegate;
import com.alq.model.ItemModel;
import com.alq.model.dao.ItemModelDAO;
import com.alq.services.RequestTask;
import com.alq.services.ServiceRequest;
import com.alq.services.ServiceResponse;
import com.alq.utils.CameraManager;
import com.alq.utils.LogUtility;
import com.alq.utils.ScalingUtilities;
import com.alq.utils.Utility;

public class CaptureImageFragment extends BaseFragment implements
OnDateSetListener, IFileUploadProgressModelDelegate, IServiceDelegate {

	public static final String TAG = CaptureImageFragment.class.getSimpleName();

	// class members
	private CameraManager cameraManager;
	private String itemImagePath;

	// UI components
	private EditText edtArt;
	private EditText edtDesc;
	private EditText edtCtn;
	private EditText edtPkg;
	private EditText edtPrice;
	private EditText edtItemCode;
	private EditText edtWeight;
	private EditText edtOrderDate;
	private EditText edtBrand;
	private EditText edtColour;
	private EditText edtMeasure;
	private EditText edtSize;
	private EditText edtBarcode;
	private EditText edtPiecePer;
	private EditText edtOrderedQty;
	private Spinner originSpinner;
	private Spinner currencySpinner;

	private ImageView itemImageView;
	private ProgressDialog progressDialog;

	private long orderDate;
	private ArrayList<String> currencyList;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setHasOptionsMenu(true);
		setRetainInstance(true);

		cameraManager = new CameraManager(this);
		currencyList = new ArrayList<String>();
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.capture_image_edit_layout,
				container, false);
		initView(view);
		return view;
	}

	private void initView(View view) {
		edtItemCode = (EditText) view.findViewById(R.id.itemcodeEditText);

		edtArt = (EditText) view.findViewById(R.id.artEdit);
		edtDesc = (EditText) view.findViewById(R.id.descEdit);
		edtCtn = (EditText) view.findViewById(R.id.ctnEdit);
		edtPkg = (EditText) view.findViewById(R.id.pkqEdit);
		edtPrice = (EditText) view.findViewById(R.id.priceEdit);

		edtWeight = (EditText) view.findViewById(R.id.weightEdit);
		edtOrderDate = (EditText) view.findViewById(R.id.orderDateEdit);
		edtMeasure = (EditText) view.findViewById(R.id.measurementEdit);
		edtColour = (EditText) view.findViewById(R.id.colorEdit);
		edtBrand = (EditText) view.findViewById(R.id.brandEdit);
		edtSize = (EditText) view.findViewById(R.id.sizeEdit);
		edtBarcode = (EditText) view.findViewById(R.id.barcodeEdit);
		edtPiecePer = (EditText) view.findViewById(R.id.piecesPerEdit);
		edtOrderedQty = (EditText) view.findViewById(R.id.orderQtyEdit);
		
		originSpinner = (Spinner) view.findViewById(R.id.originSpinner);
		currencySpinner = (Spinner) view.findViewById(R.id.currencySpinner);

		edtOrderDate.setText(getCurrentDate());
		itemImageView = (ImageView) view.findViewById(R.id.itemImage);

		setButtonListener(view);
	}

	private void setButtonListener(View view) {
		((Button) view.findViewById(R.id.saveButton))
		.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				saveRecord();
			}
		});

		((Button) view.findViewById(R.id.resetButton))
		.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				reset();
			}
		});

		((Button) view.findViewById(R.id.cancelButton))
		.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				getActivity().onBackPressed();
			}
		});

		((ImageButton) view.findViewById(R.id.captureButton))
		.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				openCamera();
			}
		});

		edtOrderDate.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				showDatePickerDialogFragment(view);
			}
		});
	}

	private void showDatePickerDialogFragment(View view) {
		DatePickerDialogFragment dialogFragment = new DatePickerDialogFragment();
		dialogFragment.setSrcView(view);
		dialogFragment.setOnDateSetListener(this);
		dialogFragment.show(getActivity().getSupportFragmentManager(),
				DatePickerDialogFragment.TAG);
	}

	private void openCamera() {

		if (TextUtils.isEmpty(edtItemCode.getText().toString())) {
			Utility.showAlertMessage(getActivity(), "Itemcode cann't be empty");
			return;
		}

		cameraManager.setFileName(edtItemCode.getText().toString());
		cameraManager.launchCameraFromFragment(CameraManager.MEDIA_TYPE_IMAGE,
				CameraManager.REQUEST_IMAGE_CAPTURE);
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		setActionBarTitle(R.string.capture_images);
		enableBackButton(getActivity());
	}

	@Override
	public void onPause() {
		super.onPause();
	}

	@Override
	public void onResume() {
		super.onResume();
	}

	@Override
	public void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode != Activity.RESULT_OK)
			return;

		Uri mImageCaptureUri = null;
		switch (requestCode) {
		case CameraManager.REQUEST_GALLERY_CONTENT:
			if (data == null)
				return;
			// After selecting image from files, save the selected path
			mImageCaptureUri = data.getData();
			cameraManager.setOutputUri(mImageCaptureUri);
			break;
		case CameraManager.REQUEST_IMAGE_CAPTURE:
			mImageCaptureUri = cameraManager.getOutputUri();
			break;
		}

		if (mImageCaptureUri == null) {
			Utility.showMessage(getAppContext(), "Picture load failed.");
			return;
		}
		
		itemImageView.setImageURI(mImageCaptureUri);
		
		itemImagePath = cameraManager
				.getRealPathFromURI(mImageCaptureUri, true);
		
		File file = cameraManager.getCampturedImage();
		if (file == null) {
			return;
		}

		Utility.compressImage(file);
	}

	/**
	 * Create an new instance of {@code UserProfileFragment} class
	 * 
	 * @param context
	 * @param addToBackStack
	 * @return
	 */
	public static CaptureImageFragment pushFragment(Context context,
			Bundle bundle, boolean addToBackStack) {
		CaptureImageFragment fragment = new CaptureImageFragment();
		Utility.fragmentTransaction(TAG, R.id.container, fragment, context,
				true);
		return fragment;
	}

	private void saveRecord() {

		if (!validatInput()) {
			return;
		}

		ItemModel itemModel = ItemModelDAO.getStoredItem(getAppContext(),
				edtItemCode.getText().toString());

		if (itemModel != null) {
			Utility.showAlertMessage(getActivity(),
					"Record already exist for this item code");
			return;
		}

		if (itemModel == null) {
			itemModel = new ItemModel();
		}

		// Date date =
		// Utility.getDateFromString(edtOrderDate.getText().toString(),
		// Constants.LOCAL_DATE_PATTERN, TimeZone.getDefault());

		itemModel.setItemID(edtItemCode.getText().toString());
		itemModel.setArt(edtArt.getText().toString());
		itemModel.setDescription(edtDesc.getText().toString());
		itemModel.setCtn(edtCtn.getText().toString());
		itemModel.setPkg(edtPkg.getText().toString());

		itemModel.setOrderDate(edtOrderDate.getText().toString());
		itemModel.setBrand(edtBrand.getText().toString());
		itemModel.setColour(edtColour.getText().toString());
		itemModel.setSize(edtSize.getText().toString());
		itemModel.setWeight(edtWeight.getText().toString());
		itemModel.setMeasurement(edtMeasure.getText().toString());
		itemModel.setOrigin(originSpinner.getSelectedItem().toString());

		itemModel.setCurrency(currencySpinner.getSelectedItem().toString());
		itemModel.setPrice(TextUtils.isEmpty(edtPrice.getText().toString().trim())? 0 : Double.parseDouble(edtPrice.getText().toString()));
		
		itemModel.setBarcodeNo(edtBarcode.getText().toString());
		itemModel.setPiecePer(TextUtils.isEmpty(edtPiecePer.getText().toString())? 0 : Integer.parseInt(edtPiecePer.getText().toString()));
		itemModel.setOrderedQty(TextUtils.isEmpty(edtOrderedQty.getText().toString())? 0 : Integer.parseInt(edtOrderedQty.getText().toString()));

		itemModel.setCreateDate(Utility.getCurTime());
		itemModel.setItemImagePath(itemImagePath);

		itemModel.save(getAppContext());

		Utility.showMessage(getAppContext(), "Record saved successfully");

		try {
			postDataToServer(itemModel);
		} catch (JSONException ex) {
			ex.printStackTrace();
		}

	}

	private void postDataToServer(ItemModel itemModel) throws JSONException {
		if (!Utility.isNetworkAvailable(getAppContext())) {
			Utility.showMessage(getAppContext(),
					R.string.no_network_connection_available);
			reset();
			return;
		}

		String path = itemModel.getItemImagePath();

		if (TextUtils.isEmpty(path)) {
			return;
		}

		File file = new File(path);

		if (!file.exists()) {
			return;
		}

		// showing progress dialog
		showProgressDialog(true);

		Bitmap bmp = ScalingUtilities.decodeFile(path);
		String imageBase64Str = Utility.convertToBase64String(bmp);

		JSONObject jsonObject = new JSONObject();
		jsonObject.put(Constants.PARAM_IMAGE_NAME, file.getName());
		jsonObject.put(Constants.PARAM_IMAGE_DATA, imageBase64Str);

		// prepare service object and set values
		ServiceRequest serviceRequest = new ServiceRequest();
		serviceRequest.setUrl(URLs.SAVE_PHOTO_URL);
		serviceRequest.setHTTPMethod(Constants.HTTPMethod.POST);
		serviceRequest.setContentType(getString(R.string.content_type_json));
		serviceRequest.setDelegate(this);
		serviceRequest.setAdditionalHTTPBody(jsonObject.toString());

		RequestTask requestTask = new RequestTask();

		// Initiate asynchronous task
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
			requestTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR,
					serviceRequest);
		} else {
			requestTask.execute(serviceRequest);
		}
	}

	private boolean validatInput() {
		if (TextUtils.isEmpty(edtItemCode.getText().toString())) {
			Utility.showAlertMessage(getActivity(), "Item code cann't be empty");
			edtItemCode.requestFocus();
			return false;
		} else if (TextUtils.isEmpty(edtOrderDate.getText().toString())) {
			Utility.showAlertMessage(getActivity(),
					"Order date cann't be empty");
			return false;
		} /*
		 * else if (TextUtils.isEmpty(edtArt.getText().toString())) {
		 * Utility.showAlertMessage(getActivity(), "Please enter article no");
		 * return false; } else if
		 * (TextUtils.isEmpty(edtDesc.getText().toString())) {
		 * Utility.showAlertMessage(getActivity(),
		 * "Please enter the description"); return false; } else if
		 * (TextUtils.isEmpty(edtCtn.getText().toString())) {
		 * Utility.showAlertMessage(getActivity(),
		 * "Please enter the booth no."); return false; } else if
		 * (TextUtils.isEmpty(edtBrand.getText().toString())) {
		 * Utility.showAlertMessage(getActivity(), "Please enter the brand");
		 * return false; } else if
		 * (TextUtils.isEmpty(edtColour.getText().toString())) {
		 * Utility.showAlertMessage(getActivity(), "Please enter the colour");
		 * return false; } else if
		 * (TextUtils.isEmpty(edtSize.getText().toString())) {
		 * Utility.showAlertMessage(getActivity(), "Please enter the size");
		 * return false; } else if
		 * (TextUtils.isEmpty(edtPrice.getText().toString())) {
		 * Utility.showAlertMessage(getActivity(), "Please enter the price");
		 * return false; }
		 */

		return true;
	}

	private void reset() {
		edtArt.setText("");
		edtDesc.setText("");
		edtCtn.setText("");
		edtPkg.setText("");
		edtPrice.setText("");
		edtBrand.setText("");
		edtColour.setText("");
		edtItemCode.setText("");
		edtMeasure.setText("");
		edtWeight.setText("");
		edtSize.setText("");
		originSpinner.setSelection(0);

		// edtItemId.setText("");
		itemImageView.setImageResource(R.drawable.ic_empty);
	}

	@Override
	public void onDateSet(DatePicker view, int year, int monthOfYear,
			int dayOfMonth) {
		Object object = view.getTag();

		if (object != null) {
			TextView textView = (TextView) object;
			SimpleDateFormat dateFormat = new SimpleDateFormat(
					Constants.LOCAL_DATE_PATTERN, Locale.US);

			Calendar calendar = Calendar.getInstance();
			calendar.set(Calendar.YEAR, year);
			calendar.set(Calendar.MONTH, monthOfYear);
			calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

			textView.setText(dateFormat.format(calendar.getTime()));

			this.orderDate = calendar.getTimeInMillis();
			view.updateDate(year, monthOfYear, dayOfMonth);
		}
	}

	@Override
	public void onComplete(ServiceResponse serviceResponse) {
		// {"uploadImageResult":{"reason":"OK","status":"success","uploadImage":{"uploadImageDate":"03\/02\/2015",
		// "uploadImageName":"1113401.jpg","uploadImagePath":"C:\/Program
		// Files\/Apache Software Foundation\/Tomcat
		// 7.0\/webapps\/CatlogFolder\/Images\/1113401.jpg"}}}

		if (!TextUtils.isEmpty(serviceResponse.getErrorMsg())) {
			Utility.showMessage(getAppContext(), serviceResponse.getErrorMsg());
		} else {
			parseSaveImageResponse(serviceResponse.getResponseString());
		}

		if (getActivity() == null || !isVisible())
			return;

		// dismiss the progress dialog
		showProgressDialog(false);

	}

	private void parseSaveImageResponse(String responseString) {
		try {
			if (responseString == null)
				return;
			JSONObject jsonObject = new JSONObject(responseString);

			JSONObject uploadImageResult = (JSONObject) Utility
					.getJsonObjectValue(jsonObject, "uploadImageResult");

			if (uploadImageResult == null) {
				Utility.showMessage(getAppContext(), "Failed upload image");
				return;
			}

			String reason = (String) Utility.getJsonObjectValue(uploadImageResult,	"reason");
			String status = (String) Utility.getJsonObjectValue(uploadImageResult,	"status");

			if ("OK".equals(reason) && "success".equals(status)) {

				JSONObject uploadImage = (JSONObject) Utility.getJsonObjectValue(uploadImageResult, "uploadImage");
				String uploadImageDate = (String) Utility.getJsonObjectValue(uploadImage, "uploadImageDate");
				String uploadImageName = (String) Utility.getJsonObjectValue(uploadImage, "uploadImageName");
				String uploadImagePath = (String) Utility.getJsonObjectValue(uploadImage, "uploadImagePath");

				String itemId = uploadImageName.substring(0, uploadImageName.indexOf("."));

				if (TextUtils.isEmpty(itemId)) {
					return;
				}

				ItemModel itemModel = ItemModelDAO.getStoredItem(getAppContext(), itemId);

				if (itemModel != null) {
					Date updateDate = Utility.convertStringDateToDateFormat(uploadImageDate, Constants.LOCAL_DATE_PATTERN);

					itemModel.setLastUpdatedDate(updateDate == null ? 0	: updateDate.getTime());
					itemModel.setItemPhotoUrl(uploadImagePath);
					itemModel.setItemPhotoFileName(uploadImageName);

					itemModel.save(getActivity());
				}
			} else {
				Utility.showMessage(getAppContext(), "Failed upload image");
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void onFileUploadProgressUpdate(String values) {

	}

	/**
	 * Show/Dismiss progress dialog according to provided status
	 * 
	 * @param isShow
	 */
	private void showProgressDialog(boolean isShow) {
		try {
			if (progressDialog == null) {

				progressDialog = new ProgressDialog(getActivity());
				progressDialog
				.setMessage(getString(R.string.uploading_image_to_server));
				progressDialog.setCancelable(false);
				progressDialog.setCanceledOnTouchOutside(false);
			}

			if (isShow) {
				if (!progressDialog.isShowing())
					progressDialog.show();
			} else {
				if (progressDialog.isShowing())
					progressDialog.dismiss();
			}
		} catch (Exception ex) {
			LogUtility
			.printErrorMessage("ReportAnIssueFragment : showProgressDialog "
					+ isShow + " Exception occured " + ex.getMessage());
		}
	}

	private String getCurrentDate() {
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				Constants.LOCAL_DATE_PATTERN, Locale.US);
		try {

			Calendar calendar = Calendar.getInstance();
			calendar.setTimeInMillis(Utility.getCurTime());

			return dateFormat.format(calendar.getTime());
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return "";
	}

	/**
	 * Build the country list
	 */
	private void buildCountryList() {
		String countryList = getResources().getString(R.string.currency_list);

		try {
			JSONArray jsonArray = new JSONArray(countryList);

			for (int i = 0; i < countryList.length(); i++) {
				String currency = jsonArray.getString(i);
				if (currency == null) continue;
				currencyList.add(currency);
			}

		} catch (JSONException e) {
			e.printStackTrace();
		}

	}

}
