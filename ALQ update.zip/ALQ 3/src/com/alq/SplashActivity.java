package com.alq;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class SplashActivity extends Activity {
	public static final int KEY_SOURCE = 1;

	private static final int SPLASH_DISPLAY_TIME = 3000;

	private boolean isResumedActivity = false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setTheme(android.R.style.Theme_Holo_Light_NoActionBar);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.splash_screen);
		activateSplash();
	}

	private void activateSplash() {
		new Handler().postDelayed(new Runnable() {
			public void run() {
				if(!isResumedActivity) {
					navigateToLogin();
				}
			}
		}, SPLASH_DISPLAY_TIME);
	}
	
	@Override
	protected void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
		if(outState != null) {
			isResumedActivity = true;
		}
	}

	@Override
	protected void onRestoreInstanceState(Bundle savedInstanceState) {
		super.onRestoreInstanceState(savedInstanceState);
	}

	/**
	 * Navigate to NextScreen with animation.
	 * @param view
	 */
	public void navigateToLogin() {
		Intent intent = new Intent(this, LoginActivity.class);
		startActivity(intent);
		finish();
		// transition from splash to main menu
		overridePendingTransition(R.anim.abc_fade_in,
				R.anim.abc_fade_out);
	}

}
