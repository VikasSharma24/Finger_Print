package com.alq;

import java.util.ArrayDeque;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;

import com.alq.delegates.ISyncServiceDelegate;
import com.alq.delegates.IWebRequestDelegate;
import com.alq.services.ServiceRequest;
import com.alq.services.model.CustomerInfoRequest;
import com.alq.utils.PrefsUtility;
import com.alq.utils.Utility;

public class LoginActivity extends Activity implements IWebRequestDelegate , ISyncServiceDelegate{
	EditText userEdit;
	EditText passEdit;
	RelativeLayout loadingIndicator;
	Button buttonSignIn;
	private ArrayDeque<ServiceRequest> requestPool;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login_activity);

		initView();

		requestPool = new ArrayDeque<>();
	}

	private void initView() {
		userEdit = (EditText) findViewById(R.id.usernameEditText);
		passEdit = (EditText) findViewById(R.id.passwordEditText);
		loadingIndicator = (RelativeLayout) findViewById(R.id.progressIndicator);
		buttonSignIn = ((Button)findViewById(R.id.signInBtn));

		buttonSignIn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View arg0) {
				signIn();
			}
		});
	}

	protected void signIn() {
		if (!isValidInput()) return;

		PrefsUtility.getInstance().setUsername(userEdit.getText().toString());
		PrefsUtility.getInstance().setPassword(passEdit.getText().toString());

		/*if (PrefsUtility.getInstance().getSyncDate() > 0) {*/
			navigateToDashboard();	
		/*} else {
			buttonSignIn.setEnabled(false);
			showLoading(true);
			setupExcelDataRequests();
			startSync();
		}*/
	}

	private void showLoading(boolean isShown) {
		if (loadingIndicator != null) {
			loadingIndicator.setVisibility(isShown? View.VISIBLE : View.GONE);
		}
	}

	private boolean isValidInput() {
		String user = userEdit.getText().toString();
		String pass = passEdit.getText().toString();
		if (TextUtils.isEmpty(user)) {
			userEdit.setError("Please enter username");
			return false;
		} else if (TextUtils.isEmpty(pass)) {
			passEdit.setError("Please enter password");
			return false;
		} 
		
		if (!(user.equals("Admin") && pass.equals("admin"))) {
			
			if ((user.equals("Sales") && pass.equals("sales"))) {
				return true;
			}
			
			Utility.showAlertMessage(this, "Invalid username and password, please try again..");
			return false;
		}

		return true;
	}

	@Override
	protected void onResume() {
		super.onResume();
	}

	/**
	 * Navigate to NextScreen with animation.
	 * @param view
	 */
	public void navigateToDashboard() {
		showLoading(false);
		Intent intent = new Intent(this, MainActivity.class);
		startActivity(intent);
		finish();
		// transition from splash to main menu
		overridePendingTransition(R.anim.abc_fade_in,
				R.anim.abc_fade_out);
	}

	@Override
	public void onWebRequestSuccess(String tag, ServiceRequest request) {
		requestCompleteAction(request);
	}

	@Override
	public void onWebRequestFailure(String errMsg, String tag,
			ServiceRequest request) {
		requestCompleteAction(request);
	}

	@Override
	public void startSync() {

		if(requestPool == null || requestPool.isEmpty()) {
			PrefsUtility.getInstance().setSyncData(Utility.getCurTime());
			return;
		}

		try {
			ServiceRequest request = requestPool.getFirst();
			request.initWebRequest();
			request.invoke();
		} catch(Exception exception) {
			exception.printStackTrace();
		}
	}

	@Override
	public void stopSync() {
		if(requestPool != null) {
			requestPool.clear();
		}
	}


	private synchronized void addRequest(ServiceRequest request) {
		requestPool.add(request);
	}

	private synchronized void removeRequest(ServiceRequest request) {
		requestPool.remove(request);
	}

	/**
	 * Remove provided request and call to start sync
	 * @param model
	 */
	private void requestCompleteAction(ServiceRequest request) {
		removeRequest(request);
		startSync();

		if (request instanceof CustomerInfoRequest) {
			navigateToDashboard();
		}
	}
}
