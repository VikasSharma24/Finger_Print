package com.alq.sync;

import java.io.File;
import java.lang.ref.WeakReference;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.widget.ImageView;

import com.alq.App;
import com.alq.model.SearchImages;
import com.alq.utils.CameraManager;
import com.alq.utils.FileUtility;
import com.alq.utils.ScalingUtilities;
import com.alq.utils.ScalingUtilities.ScalingLogic;
import com.alq.utils.Utility;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;

public class AsyncImagePresenter extends AsyncTask<SearchImages, Void, Bitmap>{

	private WeakReference<SimpleImageLoadingListener> listener;
	private WeakReference<ImageView> weakImageView;
	private Context context;
	private ScalingLogic logic;

	public AsyncImagePresenter(Context context, ImageView imageView, ScalingLogic logic, SimpleImageLoadingListener listener) {
		this.listener = new WeakReference<SimpleImageLoadingListener>(listener);
		this.weakImageView = new WeakReference<ImageView>(imageView);
		this.context = context;
		this.logic = logic;
	}

	@Override
	protected void onPreExecute() {
		super.onPreExecute();
		if (listener != null && listener.get() != null) {
			this.listener.get().onLoadingStarted(null, null);
		}
	}


	@Override
	protected Bitmap doInBackground(SearchImages... params) {
		Bitmap bitmap = null;
		switch (logic) {
		case FIT:
			Bitmap bmp = ScalingUtilities.decodeFile(params[0].getImagePath(), -1, -1, ScalingLogic.FIT);
			if (bmp != null) {
				bitmap = Utility.rotateBitmap(bmp, new File(params[0].getImagePath()));
			}
			break;
		case CROP:
			bitmap = App.getInstance().getBitmapFromMemCache(String.valueOf(params[0].getItemCode()));
			try {
				if(bitmap == null) {
					if (FileUtility.isFileExist(params[0].getImagePath())) {
						bitmap = Utility.getBitmapThumbnailFromFilePath(params[0].getImagePath(), CameraManager.MEDIA_TYPE_IMAGE);//getBitmap(params[0], 200);
						App.getInstance().addBitmapToMemoryCache(String.valueOf(params[0].getItemCode()), bitmap);
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			};
		default:
			break;
		}
		return bitmap;
	}

	@Override
	protected void onPostExecute(Bitmap result) {
		if (isCancelled()) {
			if (listener != null && listener.get() != null) {
				this.listener.get().onLoadingCancelled(null,null);
			}
			return;
		}

		if (result != null) {
			if (weakImageView != null && weakImageView.get() != null) {
				this.weakImageView.get().setImageBitmap(result);

				if (listener != null && listener.get() != null) {
					this.listener.get().onLoadingComplete(null, null, result);
				}
			}
		} else {
			if (listener != null && listener.get() != null) {
				this.listener.get().onLoadingFailed(null, null, null);
			}
		}
	}

}

