package com.alq.sync;

public class SyncManager {
	
	static SyncManager syncManager;
	
	public synchronized static SyncManager getInstance() {
		if (syncManager == null) {
			syncManager = new SyncManager();
		}
		
		return syncManager;
	}
	
	public void sync() {
		
	}
	
}
