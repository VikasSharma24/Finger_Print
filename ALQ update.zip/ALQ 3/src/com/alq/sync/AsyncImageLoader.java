package com.alq.sync;

import java.lang.ref.WeakReference;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;

import com.alq.App;
import com.alq.R;
import com.alq.utils.FileUtility;
import com.alq.utils.ScalingUtilities;
import com.alq.utils.ScalingUtilities.ScalingLogic;

public class AsyncImageLoader {

	private Context context;

	public AsyncImageLoader(Context context) {
		this.context = context;
	}

	/**
	 * Class that Extends AyncTask, This is used to process bitmap to create
	 * thumbnail image.
	 * 
	 * @author Aloha
	 */
	class BitmapWorkerTask extends AsyncTask<String, Void, Bitmap> {

		public String data;
		private final WeakReference<ImageView> imageViewReference;
		private final WeakReference<ProgressBar> progressBarRef;

		public BitmapWorkerTask(ImageView imageView, ProgressBar progressBar) {
			// Use a WeakReference to ensure the ImageView can be garbage
			// collected
			this.imageViewReference = new WeakReference<ImageView>(imageView);
			this.progressBarRef = new WeakReference<ProgressBar>(progressBar);
		}

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			showProgressBar(true);
		}

		// Decode image in background.
		@Override
		protected Bitmap doInBackground(String... params) {
			data = params[0];
			try {
				return getBitmap(data, 400);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			
			return null;
		}

		@Override
		protected void onPostExecute(Bitmap bitmap) {
			if (isCancelled()) {
				bitmap = null;
			}

			showProgressBar(false);

			if (imageViewReference != null && bitmap != null) {
				final ImageView imageView = imageViewReference.get();
				// final BitmapWorkerTask bitmapWorkerTask =
				// getBitmapWorkerTask(imageView);
				if (imageView != null) {
					imageView.setImageBitmap(bitmap);
				}
			}
		}

		private void showProgressBar(boolean isShown) {
			if (progressBarRef != null) {
				final ProgressBar progressBar = progressBarRef.get();

				if (progressBar != null) {
					progressBar.setVisibility(isShown ? View.VISIBLE
							: View.GONE);
				}
			}
		}
	}

	private Bitmap getBitmap(String path, int size) {
		Bitmap bitmap = null;
		try {
			if (FileUtility.isFileExist(path)) {

				bitmap = ScalingUtilities.decodeFile(path, size, size,
						ScalingLogic.FIT);
				App.getInstance().addBitmapToMemoryCache(path, bitmap);
				return bitmap;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} catch (OutOfMemoryError e) {
			e.printStackTrace();
		}

		return bitmap;
	}

	/**
	 * Load Thumbnail image to their respective cell.
	 * 
	 * @param data
	 * @param imageView
	 */
	public void loadBitmap(String data, ImageView imageView,
			ProgressBar progressBar) {

		final Bitmap bitmap = App.getInstance().getBitmapFromMemCache(data);
		if (bitmap != null) {
			imageView.setImageBitmap(bitmap);
		} else if (cancelPotentialWork(data, imageView)) {
			final BitmapWorkerTask task = new BitmapWorkerTask(imageView,
					progressBar);
			final AsyncDrawable asyncDrawable = new AsyncDrawable(
					context.getResources(), BitmapFactory.decodeResource(
							context.getResources(), R.drawable.ic_empty), task);
			imageView.setImageDrawable(asyncDrawable);
			task.execute(data);
		}
	}

	/**
	 * Check if another running task is already associated with the ImageView.
	 * If so, it attempts to cancel the previous task by calling cancel(). In a
	 * small number of cases, the new task data matches the existing task and
	 * nothing further needs to happen
	 * 
	 * @param data
	 * @param imageView
	 * @return
	 */
	private static boolean cancelPotentialWork(String data, ImageView imageView) {
		final BitmapWorkerTask bitmapWorkerTask = getBitmapWorkerTask(imageView);

		if (bitmapWorkerTask != null) {
			final String bitmapData = bitmapWorkerTask.data;
			if (bitmapData == null || !bitmapData.equalsIgnoreCase(data)) {
				// Cancel previous task
				bitmapWorkerTask.cancel(true);
			} else {
				// The same work is already in progress
				return false;
			}
		}
		// No task associated with the ImageView, or an existing task was
		// cancelled
		return true;
	}

	/**
	 * A helper method, that is used above to retrieve the task associated with
	 * a particular ImageView:
	 * 
	 * @param imageView
	 * @return
	 */
	private static BitmapWorkerTask getBitmapWorkerTask(ImageView imageView) {
		if (imageView != null) {
			final Drawable drawable = imageView.getDrawable();
			if (drawable instanceof AsyncDrawable) {
				final AsyncDrawable asyncDrawable = (AsyncDrawable) drawable;
				return asyncDrawable.getBitmapWorkerTask();
			}
		}
		return null;
	}

	/**
	 * Create a dedicated Drawable subclass to store a reference back to the
	 * worker task. In this case, a BitmapDrawable is used so that a placeholder
	 * image can be displayed in the ImageView while the task completes:
	 * 
	 * @author Aloha
	 */
	static class AsyncDrawable extends BitmapDrawable {
		private final WeakReference<BitmapWorkerTask> bitmapWorkerTaskReference;

		public AsyncDrawable(Resources res, Bitmap bitmap,
				BitmapWorkerTask bitmapWorkerTask) {
			super(res, bitmap);
			bitmapWorkerTaskReference = new WeakReference<BitmapWorkerTask>(
					bitmapWorkerTask);
		}

		public BitmapWorkerTask getBitmapWorkerTask() {
			return bitmapWorkerTaskReference.get();
		}

	}
}
