package com.alq.sync;

import java.io.File;
import java.util.ArrayDeque;
import java.util.ArrayList;

import org.json.JSONObject;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.IBinder;
import android.os.Message;
import android.text.TextUtils;

import com.alq.delegates.ISyncServiceDelegate;
import com.alq.delegates.IWebRequestDelegate;
import com.alq.model.ItemModel;
import com.alq.model.dao.ItemModelDAO;
import com.alq.services.ServiceRequest;
import com.alq.services.model.CustomerInfoRequest;
import com.alq.services.model.StockInfoRequest;
import com.alq.services.model.UploadImageRequest;
import com.alq.utils.LogUtility;

public class SyncService extends Service implements ISyncServiceDelegate, IWebRequestDelegate, Callback {
	private static final String TAG = SyncService.class.getSimpleName();

	private SyncServiceBinder binder = new SyncServiceBinder();
	private ArrayDeque<ServiceRequest> requestPool;
	private Handler handler;

	public class SyncServiceBinder extends Binder {
		public SyncService getService() {
			return SyncService.this;
		}
	}

	@Override
	public IBinder onBind(Intent arg0) {
		return binder;
	}

	@Override
	public void onCreate() {
		super.onCreate();
		LogUtility.printInfoMessage(TAG +": onCreate");
		requestPool = new ArrayDeque<ServiceRequest>();
		handler = new Handler(this);
		scheduleSync();
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		return Service.START_STICKY;
	}

	@Override
	public void onWebRequestSuccess(String tag, ServiceRequest request) {
		LogUtility.printInfoMessage(TAG +": onWebRequestSuccess");
		requestCompleteAction(request);
	}

	@Override
	public void onWebRequestFailure(String errMsg, String tag, ServiceRequest request) {
		LogUtility.printInfoMessage(TAG+": onWebRequestFailure");
		requestCompleteAction(request);
	}

	@Override
	public void startSync() {

		if(requestPool == null || requestPool.isEmpty()) {
			stopSelf();
			return;
		}

		LogUtility.printInfoMessage(TAG +": startSync");

		try {
			ServiceRequest request = requestPool.getFirst();
			request.initWebRequest();
			request.invoke();
		} catch(Exception exception) {
			exception.printStackTrace();
		}
	}

	@Override
	public void stopSync() {
		LogUtility.printInfoMessage(TAG +": stopSync");
		if(requestPool != null) {
			requestPool.clear();
		}
		stopSelf();
	}

	private void scheduleSync() {
		Message message = new Message();
		message.what = 1;
		handler.sendMessageDelayed(message, 5000);
	}


	private synchronized void addRequest(ServiceRequest request) {
		requestPool.add(request);
	}

	private synchronized void removeRequest(ServiceRequest request) {
		requestPool.remove(request);
	}

	private synchronized void addRequestAtTop(ServiceRequest request) {
		requestPool.addFirst(request);
	}

	/**
	 * Remove provided request and call to start sync
	 * @param model
	 */
	private void requestCompleteAction(ServiceRequest request) {
		removeRequest(request);
		startSync();
	}

	private void setupExcelDataRequests() {

		StockInfoRequest stockInfoRequest = new StockInfoRequest(this, this);
		CustomerInfoRequest customerInfoRequest = new CustomerInfoRequest(this, this);

		addRequest(stockInfoRequest);
		addRequest(customerInfoRequest);
	}

	private void sendUploadPendingImages() {
		ArrayList<ItemModel> itemModels = ItemModelDAO.getPendingItemImages(this);

		for (ItemModel itemModel : itemModels) {
			UploadImageRequest request = new UploadImageRequest(this, this);

			String path = itemModel.getItemImagePath();

			if (TextUtils.isEmpty(path)) {
				continue;
			}

			File file = new File(path);

			if (!file.exists()) {
				continue;
			}

			JSONObject jsonObject = request.createJSONObject(path, file.getName());

			request.setAdditionalHTTPBody(jsonObject.toString());

			addRequest(request);
		}
	}

	@Override
	public boolean handleMessage(Message arg0) {
		switch (arg0.what) {
		case 1:
			sendUploadPendingImages();
			startSync();
			break;
		case 2:
			stopSelf();
			break;
		default:
			break;
		}
		return false;
	}

}
