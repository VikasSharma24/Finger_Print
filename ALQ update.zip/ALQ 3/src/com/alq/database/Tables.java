package com.alq.database;

import android.net.Uri;

public class Tables {
	static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd.iosched.block";

	public static final String PATH_ITEM_TABLE = "Item";
	public static final String PATH_STOCK_INFO_TABLE = "StockInformation";
	public static final String PATH_CUST_INFO_TABLE = "customerInformation";

	interface BaseColumn {
		public static final String COLUMN_ID = "_id";
	}

	public static class ItemTable implements BaseColumn {
		public static final Uri CONTENT_URI = getContentUri(PATH_ITEM_TABLE);

		public static final String TABLE_NAME = "Item";
		public static final String COLUMN_ITEM_ID = "itemID";
		public static final String COLUMN_ART = "ART";
		public static final String COLUMN_DESCRiPTION = "description";
		public static final String COLUMN_BOOTH_NO = "boothNo";
		public static final String COLUMN_PKG = "packing";
		public static final String COLUMN_ORDER_DATE = "orderDate";

		public static final String COLUMN_SIZE = "size";
		public static final String COLUMN_WEIGHT = "weight";
		public static final String COLUMN_MEASUREMENT = "measurement";
		public static final String COLUMN_COLOUR = "colour";
		public static final String COLUMN_BRAND = "brand";
		public static final String COLUMN_PRICE = "price";
		public static final String COLUMN_ORIGIN = "origin";
		public static final String COLUMN_CURRENCY = "currency";

		public static final String COLUMN_BARCODE_NO = "barcodeNum";
		public static final String COLUMN_PIECE_PER_CARTOON = "piecePer";
		public static final String COLUMN_ORDERED_QTY = "orderedQty";

		public static final String COLUMN_ITEM_PHOTO_PATH = "itemPhotoPath";
		public static final String COLUMN_ITEM_PHOTO_URL = "itemPhotoURL";	
		public static final String COLUMN_ITEM_PHOTO_FILE_NAME ="itemPhotoFileName";
		public static final String COLUMN_CREATE_DATE = "createDate";
		public static final String COLUMN_LAST_UPDATE_DATE = "updatedDate";
		public static final String COLUMN_ITEM_SYNC_DATE = "itemSyncDate";
		public static final String COLUMN_ITEM_DELIVERY_DATE = "itemDeliveryDate";

	}

	public static class StockInformationTable implements BaseColumn {
		public static final Uri CONTENT_URI = getContentUri(PATH_STOCK_INFO_TABLE);

		public static final String TABLE_NAME = "StockInformation";

		public static final String COLUMN_ITEM_ID = "itemCode";           
		public static final String COLUMN_ARTICLE_NO = "articleNo";          
		public static final String COLUMN_DESCRIPTION = "description";        
		public static final String COLUMN_BOOTH_NO = "boothNo";            
		public static final String COLUMN_PACKING = "packing";            
		public static final String COLUMN_BRAND = "brand";              
		public static final String COLUMN_COLOUR = "colour";             
		public static final String COLUMN_WEIGHT = "weight";             
		public static final String COLUMN_MEASUREMENT = "measurement";        
		public static final String COLUMN_ORIGIN = "origin";             

		public static final String COLUMN_SIZE = "size";               
		public static final String COLUMN_PURCHASE_PRICE = "puchasePrice";       
		public static final String COLUMN_ORDER_DATE = "orderDate";          
		public static final String COLUMN_IMAGE_PATH = "imagePath";          

		public static final String COLUMN_CURRENCY = "currency";           
		public static final String COLUMN_CUSTOMER_CODE = "customerCode";       
		public static final String COLUMN_CUSTOMER_COUNTRY = "customerCountry";    
		public static final String COLUMN_CUSTOMER_NAME = "customerName";       
		public static final String COLUMN_LAST_ARRIAVAL_QUANTITY = "lastArrivalQuantity";
		public static final String COLUMN_LAST_ORDER_DATE = "lastOrderDate";      
		public static final String COLUMN_LAST_PURCHASE_DATE = "lastPurchaseDate";   
		public static final String COLUMN_LAST_SELL_DATE = "lastSellDate";       
		public static final String COLUMN_MARK_UP_VALUE = "markUpValue";        
		public static final String COLUMN_PER_PIECE_PRICE = "perPiecePrice";      
		public static final String COLUMN_CREDIT_PRICE = "creditPrice";        
		public static final String COLUMN_STOCK_AVAILABLE = "stockAvailable";     
		public static final String COLUMN_WHOLE_SALE_PRICE = "wholesalePrice";
		public static final String COLUMN_BARCODE = "barcode";  
	}

	public static class CustomerInformationTable implements BaseColumn {
		public static final Uri CONTENT_URI = getContentUri(PATH_CUST_INFO_TABLE);

		public static final String TABLE_NAME = "CustomerInformation";

		public static final String COLUMN_CUSTOMER_CODE = "customerCode";           
		public static final String COLUMN_CUSTOMER_NAME = "customerName";          
		public static final String COLUMN_COUNTRY = "country";
		public static final String COLUMN_MARK_UP_VALUE = "markUpValue";
	}


	private static Uri getContentUri(String path) {
		return ALQContentProvider.CONTENT_URI
				.buildUpon().appendPath(path).build();
	}

}
