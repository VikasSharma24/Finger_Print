package com.alq.database;

import com.alq.utils.LogUtility;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper  extends  SQLiteOpenHelper {
	public final String TAG = DatabaseHelper.class.getSimpleName();

	public static final String DATABASE_NAME = "Alq.db";
	public static final int DATABASE_VERSION = 2;

	public DatabaseHelper(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
	}

	interface DropTable {
		String ITEM_TABLE = "Drop table IF EXISTS "+Tables.ItemTable.TABLE_NAME;
	}
	
	interface ALTER_TABLE_V3 {
		String ITEM_TABLE = "Alter table " + Tables.ItemTable.TABLE_NAME + " add column "+ Tables.ItemTable.COLUMN_BARCODE_NO + " TEXT ";
	}

	interface CreateQuery {

		String ENABLE_FOREIGN_KEY_SUPPORT = "PRAGMA foreign_keys = ON;";

		String ITEM_TABLE = "CREATE TABLE IF NOT EXISTS " + Tables.ItemTable.TABLE_NAME + " ( " + 
				Tables.ItemTable.COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
				Tables.ItemTable.COLUMN_ITEM_ID + " TEXT," +
				Tables.ItemTable.COLUMN_ART + " TEXT," +
				Tables.ItemTable.COLUMN_DESCRiPTION + " TEXT," +
				Tables.ItemTable.COLUMN_BOOTH_NO + " TEXT," +
				Tables.ItemTable.COLUMN_PKG + " TEXT," +
				Tables.ItemTable.COLUMN_ORDER_DATE + " TEXT," +
				Tables.ItemTable.COLUMN_BRAND + " TEXT," +
				Tables.ItemTable.COLUMN_COLOUR + " TEXT," +
				Tables.ItemTable.COLUMN_SIZE + " TEXT," +
				Tables.ItemTable.COLUMN_WEIGHT + " TEXT," +
				Tables.ItemTable.COLUMN_MEASUREMENT + " TEXT," +
				Tables.ItemTable.COLUMN_ORIGIN + " TEXT," +
				Tables.ItemTable.COLUMN_CURRENCY + " TEXT," +
				Tables.ItemTable.COLUMN_PRICE + " TEXT," +
				Tables.ItemTable.COLUMN_ITEM_PHOTO_PATH + " TEXT," +
				Tables.ItemTable.COLUMN_ITEM_PHOTO_URL + " TEXT," +
				Tables.ItemTable.COLUMN_ITEM_PHOTO_FILE_NAME + " TEXT," +
				Tables.ItemTable.COLUMN_CREATE_DATE + " INTEGER DEFAULT 0000," +
				Tables.ItemTable.COLUMN_LAST_UPDATE_DATE + " INTEGER DEFAULT 0000," +
				Tables.ItemTable.COLUMN_ITEM_SYNC_DATE + " INTEGER DEFAULT 0000, " +
				Tables.ItemTable.COLUMN_ITEM_DELIVERY_DATE + " INTEGER DEFAULT 0000, " +
				Tables.ItemTable.COLUMN_BARCODE_NO + " TEXT," +
				Tables.ItemTable.COLUMN_PIECE_PER_CARTOON + " INTEGER," +
				Tables.ItemTable.COLUMN_ORDERED_QTY + " INTEGER" +
				" ) ";


		String STOCK_TABLE = "CREATE TABLE IF NOT EXISTS " + Tables.StockInformationTable.TABLE_NAME + " ( " + 
				Tables.StockInformationTable.COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
				Tables.StockInformationTable.COLUMN_ITEM_ID + " TEXT UNIQUE," +
				Tables.StockInformationTable.COLUMN_ARTICLE_NO + " TEXT," +
				Tables.StockInformationTable.COLUMN_DESCRIPTION + " TEXT," +
				Tables.StockInformationTable.COLUMN_PACKING + " TEXT," +
				Tables.StockInformationTable.COLUMN_BOOTH_NO + " TEXT," +
				Tables.StockInformationTable.COLUMN_BRAND + " TEXT," +
				Tables.StockInformationTable.COLUMN_COLOUR + " TEXT," +
				Tables.StockInformationTable.COLUMN_SIZE + " TEXT," +
				Tables.StockInformationTable.COLUMN_WEIGHT + " TEXT," +
				Tables.StockInformationTable.COLUMN_MEASUREMENT + " TEXT," +
				Tables.StockInformationTable.COLUMN_ORIGIN + " TEXT," +
				Tables.StockInformationTable.COLUMN_CURRENCY + " TEXT," +
				Tables.StockInformationTable.COLUMN_PURCHASE_PRICE + " TEXT," +
				Tables.StockInformationTable.COLUMN_ORDER_DATE + " TEXT," +
				Tables.StockInformationTable.COLUMN_IMAGE_PATH+ " TEXT," +
				Tables.StockInformationTable.COLUMN_CUSTOMER_CODE + " TEXT," +
				Tables.StockInformationTable.COLUMN_CUSTOMER_NAME + " TEXT," +
				Tables.StockInformationTable.COLUMN_CUSTOMER_COUNTRY + " TEXT," +
				Tables.StockInformationTable.COLUMN_LAST_ARRIAVAL_QUANTITY + " TEXT," +
				Tables.StockInformationTable.COLUMN_LAST_ORDER_DATE + " TEXT," +
				Tables.StockInformationTable.COLUMN_LAST_PURCHASE_DATE + " TEXT," +
				Tables.StockInformationTable.COLUMN_LAST_SELL_DATE + " TEXT," +
				Tables.StockInformationTable.COLUMN_MARK_UP_VALUE + " TEXT," +
				Tables.StockInformationTable.COLUMN_PER_PIECE_PRICE + " TEXT," +
				Tables.StockInformationTable.COLUMN_CREDIT_PRICE + " TEXT," +
				Tables.StockInformationTable.COLUMN_STOCK_AVAILABLE+ " TEXT," +
				Tables.StockInformationTable.COLUMN_WHOLE_SALE_PRICE + " TEXT," +
				Tables.StockInformationTable.COLUMN_BARCODE + " TEXT" +
				" ) ";

		String CUSTOMER_TABLE = "CREATE TABLE IF NOT EXISTS " + Tables.CustomerInformationTable.TABLE_NAME + " ( " + 
				Tables.CustomerInformationTable.COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
				Tables.CustomerInformationTable.COLUMN_CUSTOMER_CODE + " TEXT," +
				Tables.CustomerInformationTable.COLUMN_CUSTOMER_NAME + " TEXT," +
				Tables.CustomerInformationTable.COLUMN_COUNTRY + " TEXT," +
				Tables.CustomerInformationTable.COLUMN_MARK_UP_VALUE + " FLOAT" +
				" ) ";
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		db.execSQL(CreateQuery.ITEM_TABLE);
		db.execSQL(CreateQuery.STOCK_TABLE);
		db.execSQL(CreateQuery.CUSTOMER_TABLE);
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		LogUtility.printInfoMessage(TAG + "onUpgrade :  OldVersion = " + oldVersion + ", NewVersion = " + newVersion);
		
		if (oldVersion < 2) { //support db version 1
			db.execSQL(CreateQuery.STOCK_TABLE);
			db.execSQL(CreateQuery.CUSTOMER_TABLE);
		}
		
		/*if (oldVersion < 3) { //support db version 2
			db.execSQL(ALTER_TABLE_V3.ITEM_TABLE);
		}*/
	}
}
