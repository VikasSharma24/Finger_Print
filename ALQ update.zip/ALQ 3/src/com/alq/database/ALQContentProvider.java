package com.alq.database;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;

public class ALQContentProvider extends ContentProvider {
	private DatabaseHelper databaseHelper;
	public static final String AUTHORITY = "com.alq.database";
	public static final Uri CONTENT_URI = Uri.parse("content://" + AUTHORITY);

	// used for the UriMacher
	private static final int ITEM = 10;
	private static final int STOCK_INFO = 20;
	private static final int CUSTOMER_INFO = 30;

	private static final UriMatcher sURIMatcher = new UriMatcher(UriMatcher.NO_MATCH);

	static {
		sURIMatcher.addURI(AUTHORITY, Tables.PATH_ITEM_TABLE, ITEM);
		sURIMatcher.addURI(AUTHORITY, Tables.PATH_STOCK_INFO_TABLE, STOCK_INFO);
		sURIMatcher.addURI(AUTHORITY, Tables.PATH_CUST_INFO_TABLE, CUSTOMER_INFO);
	}

	@Override
	public boolean onCreate() {
		databaseHelper = new DatabaseHelper(getContext());
		return false;
	}

	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		final int match = sURIMatcher.match(uri);
		String tableName = null;

		// match for which table we need to perform insert operation
		switch (match) {
		case ITEM:
			tableName = Tables.ItemTable.TABLE_NAME;		
			break;
		case STOCK_INFO:
			tableName = Tables.StockInformationTable.TABLE_NAME;		
			break;
		case CUSTOMER_INFO:
			tableName = Tables.CustomerInformationTable.TABLE_NAME;
			break;
		default:
			throw new IllegalArgumentException("Unsupported URI: " + uri);
		}

		// add record to respective table
		int id = databaseHelper.getWritableDatabase().delete(tableName, selection, selectionArgs);
		Uri newUri = uri;
		if (id > 0) {
			newUri = ContentUris.withAppendedId(uri, id);
			getContext().getContentResolver().notifyChange(newUri, null);
		}

		return id;
	}

	@Override
	public String getType(Uri arg0) {
		return null;
	}

	@Override
	public Uri insert(Uri uri, ContentValues values) {
		final int match = sURIMatcher.match(uri);
		String tableName = null;

		// match for which table we need to perform insert operation
		switch (match) {
		case ITEM:
			tableName = Tables.ItemTable.TABLE_NAME;		
			break;
		case STOCK_INFO:
			tableName = Tables.StockInformationTable.TABLE_NAME;		
			break;
		case CUSTOMER_INFO:
			tableName = Tables.CustomerInformationTable.TABLE_NAME;
			break;

		default:
			throw new IllegalArgumentException("Unsupported URI: " + uri);
		}

		// add record to respective table
		long id = databaseHelper.getWritableDatabase().insertWithOnConflict(tableName, null, values, SQLiteDatabase.CONFLICT_REPLACE);
		//long id = databaseHelper.getWritableDatabase().insert(tableName, null, values);
		Uri newUri = uri;
		if (id > 0) {
			newUri = ContentUris.withAppendedId(uri, id);
			getContext().getContentResolver().notifyChange(newUri, null);
		}
		// return uri with inserted record
		return newUri;
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection,
			String[] selectionArgs, String sortOrder) {

		final int match = sURIMatcher.match(uri);
		String groupBy = null;
		String tableName = null;
		SQLiteDatabase db = databaseHelper.getReadableDatabase();
		SQLiteQueryBuilder builder = new SQLiteQueryBuilder();

		// match for which table we need to perform insert operation
		switch (match) {
		case ITEM:
			tableName = Tables.ItemTable.TABLE_NAME;
			break;
		case STOCK_INFO:
			tableName = Tables.StockInformationTable.TABLE_NAME;		
			break;
		case CUSTOMER_INFO:
			tableName = Tables.CustomerInformationTable.TABLE_NAME;
			break;
		default:
			throw new IllegalArgumentException("Unsupported URI: " + uri);
		}

		//select record from respective table
		builder.setTables(tableName);
		Cursor cursor = builder.query(db,projection, selection, selectionArgs, groupBy, null, sortOrder);		
		cursor.setNotificationUri(getContext().getContentResolver(), uri);

		return cursor;
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection,
			String[] selectionArgs) {
		final int match = sURIMatcher.match(uri);
		String tableName = null;

		// match for which table we need to perform insert operation
		switch (match) {
		case ITEM:
			tableName = Tables.ItemTable.TABLE_NAME;   
			break;
		case STOCK_INFO:
			tableName = Tables.StockInformationTable.TABLE_NAME;		
			break;
		case CUSTOMER_INFO:
			tableName = Tables.CustomerInformationTable.TABLE_NAME;
			break;
		default:
			throw new IllegalArgumentException("Unsupported URI: " + uri);
		}

		// update record to respective table
		int id = databaseHelper.getWritableDatabase().update(tableName, values, selection, selectionArgs);

		Uri newUri = uri;
		if (id > 0) {
			newUri = ContentUris.withAppendedId(uri, id);
			getContext().getContentResolver().notifyChange(newUri, null);
		}

		//		getContext().getContentResolver().notifyChange(uri, null);

		// return id of updated record
		return id;
	}
}
